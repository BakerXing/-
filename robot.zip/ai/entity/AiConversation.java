package com.ruoyi.web.ai.entity;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import com.ruoyi.common.core.domain.BaseEntity;

/**
 * AI 会话表 ai_conversation
 */
@TableName("ai_conversation")
public class AiConversation extends BaseEntity {

    /** 会话ID */
    @TableId(type = IdType.AUTO)
    private Long id;

    /** 会话标题 */
    private String title;

    /** 会话类型：chat-智聊, translate-翻译, meeting-会议纪要, writing-辅助写作 */
    private String type;

    /** 是否置顶（0否 1是） */
    private String isPinned;

    /** 用户ID */
    private Long userId;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public String getIsPinned() {
        return isPinned;
    }

    public void setIsPinned(String isPinned) {
        this.isPinned = isPinned;
    }

    public Long getUserId() {
        return userId;
    }

    public void setUserId(Long userId) {
        this.userId = userId;
    }
}
