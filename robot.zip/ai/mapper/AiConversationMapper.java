package com.ruoyi.web.ai.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.ruoyi.web.ai.entity.AiConversation;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.Select;

import java.util.List;

/**
 * AI 会话 Mapper
 */
@Mapper
public interface AiConversationMapper extends BaseMapper<AiConversation> {

    /**
     * 查询用户会话列表（置顶在前，按更新时间倒序）
     */
    @Select("SELECT * FROM ai_conversation WHERE user_id = #{userId} ORDER BY is_pinned DESC, update_time DESC")
    List<AiConversation> selectByUserId(@Param("userId") Long userId);

    /**
     * 查询用户置顶会话数量
     */
    @Select("SELECT COUNT(*) FROM ai_conversation WHERE user_id = #{userId} AND is_pinned = '1'")
    int countPinned(@Param("userId") Long userId);

    /**
     * 查询用户总会话数量
     */
    @Select("SELECT COUNT(*) FROM ai_conversation WHERE user_id = #{userId}")
    int countByUserId(@Param("userId") Long userId);
}
