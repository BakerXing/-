package com.ruoyi.web.ai.controller;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.ruoyi.common.core.controller.BaseController;
import com.ruoyi.common.core.domain.CommonResult;
import com.ruoyi.common.utils.SecurityUtils;
import com.ruoyi.system.domain.SysUser;
import com.ruoyi.system.service.IUserService;
import com.ruoyi.web.ai.dto.ChatRequest;
import com.ruoyi.web.ai.dto.ExampleTemplate;
import com.ruoyi.web.ai.dto.TabConfig;
import com.ruoyi.web.ai.entity.AiConversation;
import com.ruoyi.web.ai.entity.AiMessage;
import com.ruoyi.web.ai.service.AiConversationService;
import com.ruoyi.web.ai.service.AiMessageService;
import com.ruoyi.web.ai.service.AsrService;
import com.ruoyi.web.ai.service.DeepSeekService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.servlet.mvc.method.annotation.SseEmitter;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.util.*;

/**
 * AI 智能问答 Controller
 */
@RestController
@RequestMapping("/ai/chat")
public class AiChatController extends BaseController {

    private static final Logger log = LoggerFactory.getLogger(AiChatController.class);
    private static final ObjectMapper OBJECT_MAPPER = new ObjectMapper();

    @Autowired
    private AiConversationService conversationService;

    @Autowired
    private AiMessageService messageService;

    @Autowired
    private DeepSeekService deepSeekService;

    @Autowired
    private AsrService asrService;

    @Autowired
    private IUserService userService;

    /**
     * 获取当前用户ID
     */
    private Long getCurrentUserId() {
        String username = SecurityUtils.getUsername();
        if (username == null) {
            throw new RuntimeException("用户未登录");
        }
        SysUser user = userService.selectUserByUserName(username);
        if (user == null) {
            throw new RuntimeException("用户不存在");
        }
        return user.getUserId();
    }

    /**
     * SSE 流式聊天接口
     */
    @PreAuthorize("@ss.hasPermi('ai:chat:chat')")
    @GetMapping(value = "/stream", produces = MediaType.TEXT_EVENT_STREAM_VALUE)
    public SseEmitter streamChat(
            @RequestParam String question,
            @RequestParam(required = false) Long conversationId,
            @RequestParam(defaultValue = "chat") String type) {

        Long userId = getCurrentUserId();
        SseEmitter emitter = new SseEmitter(300_000L); // 5 分钟超时

        // 异步处理
        new Thread(() -> {
            try {
                // 1. 获取或创建会话
                AiConversation conv;
                if (conversationId != null) {
                    conv = conversationService.getById(conversationId);
                    if (conv == null || !conv.getUserId().equals(userId)) {
                        sendError(emitter, "会话不存在");
                        emitter.complete();
                        return;
                    }
                    conversationService.updateTitle(conv.getId(),
                            conv.getTitle() == null || conv.getTitle().isBlank() ? question.substring(0, Math.min(20, question.length())) : conv.getTitle());
                } else {
                    conv = conversationService.create(userId,
                            question.substring(0, Math.min(20, question.length())), type);
                    // 通知前端新会话ID
                    String convEvent = OBJECT_MAPPER.writeValueAsString(Map.of(
                            "type", "conversation",
                            "conversationId", conv.getId()
                    ));
                    emitter.send(SseEmitter.event().data(convEvent));
                }

                // 2. 保存用户消息
                AiMessage userMsg = new AiMessage();
                userMsg.setConversationId(conv.getId());
                userMsg.setRole("user");
                userMsg.setContent(question);
                userMsg.setType(type);
                userMsg.setIsComplete("1");
                messageService.save(userMsg);

                // 3. 保存助手消息占位
                AiMessage assistantMsg = new AiMessage();
                assistantMsg.setConversationId(conv.getId());
                assistantMsg.setRole("assistant");
                assistantMsg.setContent("");
                assistantMsg.setType(type);
                assistantMsg.setIsComplete("0");
                Long assistantMsgId = messageService.saveAndReturnId(assistantMsg);

                // 4. 调用 AI 流式接口，获取完整内容
                String fullContent = deepSeekService.streamChat(question, type, emitter);

                // 5. 更新助手消息为完整内容
                if (fullContent != null && !fullContent.isEmpty()) {
                    assistantMsg.setId(assistantMsgId);
                    assistantMsg.setContent(fullContent);
                    assistantMsg.setIsComplete("1");
                    messageService.update(assistantMsg);
                }

                // 6. 完成 SSE 连接
                emitter.complete();

            } catch (Exception e) {
                log.error("流式聊天处理失败", e);
                sendError(emitter, "服务器内部错误: " + e.getMessage());
                emitter.completeWithError(e);
            }
        }).start();

        return emitter;
    }

    /**
     * 获取会话列表
     */
    @PreAuthorize("@ss.hasPermi('ai:chat:list')")
    @GetMapping("/conversations")
    public CommonResult<List<AiConversation>> listConversations() {
        Long userId = getCurrentUserId();
        return CommonResult.success(conversationService.listByUserId(userId));
    }

    /**
     * 获取会话消息
     */
    @PreAuthorize("@ss.hasPermi('ai:chat:list')")
    @GetMapping("/conversations/{id}/messages")
    public CommonResult<List<AiMessage>> getMessages(@PathVariable Long id) {
        Long userId = getCurrentUserId();
        AiConversation conv = conversationService.getById(id);
        if (conv == null || !conv.getUserId().equals(userId)) {
            return CommonResult.error("会话不存在或无权访问");
        }
        return CommonResult.success(messageService.listByConversationId(id));
    }

    /**
     * 创建新会话
     */
    @PreAuthorize("@ss.hasPermi('ai:chat:chat')")
    @PostMapping("/conversations")
    public CommonResult<AiConversation> createConversation(@RequestBody Map<String, String> body) {
        Long userId = getCurrentUserId();
        String title = body.getOrDefault("title", "新对话");
        String type = body.getOrDefault("type", "chat");
        return CommonResult.success(conversationService.create(userId, title, type));
    }

    /**
     * 删除会话
     */
    @PreAuthorize("@ss.hasPermi('ai:chat:remove')")
    @DeleteMapping("/conversations/{id}")
    public CommonResult<Void> deleteConversation(@PathVariable Long id) {
        Long userId = getCurrentUserId();
        AiConversation conv = conversationService.getById(id);
        if (conv == null || !conv.getUserId().equals(userId)) {
            return CommonResult.error("会话不存在或无权操作");
        }
        // 先删除消息
        messageService.deleteByConversationId(id);
        conversationService.delete(id, userId);
        return CommonResult.success();
    }

    /**
     * 切换置顶
     */
    @PreAuthorize("@ss.hasPermi('ai:chat:edit')")
    @PostMapping("/conversations/{id}/pin")
    public CommonResult<Void> togglePin(@PathVariable Long id) {
        Long userId = getCurrentUserId();
        conversationService.togglePin(id, userId);
        return CommonResult.success();
    }

    /**
     * 更新会话标题
     */
    @PreAuthorize("@ss.hasPermi('ai:chat:edit')")
    @PutMapping("/conversations/{id}/title")
    public CommonResult<Void> updateTitle(@PathVariable Long id, @RequestBody Map<String, String> body) {
        String title = body.get("title");
        conversationService.updateTitle(id, title);
        return CommonResult.success();
    }

    /**
     * 上传文件（txt 文本 / 音频），返回转换后的文字
     */
    @PostMapping("/upload")
    public CommonResult<Map<String, String>> uploadFile(@RequestParam("file") MultipartFile file) {
        if (file == null || file.isEmpty()) {
            return CommonResult.error("文件不能为空");
        }
        String fileName = file.getOriginalFilename();
        if (fileName == null) {
            return CommonResult.error("无法获取文件名");
        }
        String lowerName = fileName.toLowerCase();
        try {
            String text;
            if (lowerName.endsWith(".txt")) {
                // 直接读取文本内容
                text = new String(file.getBytes(), StandardCharsets.UTF_8);
                // 去除 BOM
                if (text.startsWith("\uFEFF")) {
                    text = text.substring(1);
                }
            } else if (isAudioFile(lowerName)) {
                // 音频转文字
                text = asrService.recognize(file);
            } else {
                return CommonResult.error("不支持的文件类型，仅支持 .txt 和音频文件（mp3/wav/m4a/aac/ogg/flac）");
            }
            Map<String, String> result = new HashMap<>();
            result.put("fileName", fileName);
            result.put("text", text);
            return CommonResult.success(result);
        } catch (IOException e) {
            log.error("文件读取失败", e);
            return CommonResult.error("文件读取失败：" + e.getMessage());
        }
    }

    private boolean isAudioFile(String lowerName) {
        return lowerName.endsWith(".mp3") || lowerName.endsWith(".wav")
                || lowerName.endsWith(".m4a") || lowerName.endsWith(".aac")
                || lowerName.endsWith(".ogg") || lowerName.endsWith(".flac");
    }

    /**
     * 获取 Tab 配置（示例问题）
     */
    @GetMapping("/tabs")
    public CommonResult<List<TabConfig>> getTabConfigs() {
        List<TabConfig> tabs = List.of(
                new TabConfig("chat", "智聊", "💬", List.of(
                        "解读银行日常业务需要遵守的合规管理要求",
                        "帮我梳理一下最近科技行业的发展趋势",
                        "如何提升团队协作效率？有哪些实用方法"
                )),
                new TabConfig("translate", "翻译", "🌐", List.of(
                        "将这段中文翻译成地道的英文：人工智能正在改变世界",
                        "翻译成日语：这份报告需要在下周五之前完成",
                        "翻译成法语：欢迎来到我们的新产品发布会"
                )),
                new TabConfig("meeting", "会议纪要", "📝",
                        // 默认示例问题（模板1内容）
                        List.of(
                                "生成一份季度董事会会议纪要模板",
                                "帮我整理产品需求评审会的会议纪要",
                                "生成项目启动会的会议纪要框架"
                        ),
                        // 3 套模板，每套包含 3 个专属示例问题
                        List.of(
                                new ExampleTemplate("template1", "模板1", List.of(
                                        "生成一份季度董事会会议纪要模板",
                                        "帮我整理产品需求评审会的会议纪要",
                                        "生成项目启动会的会议纪要框架"
                                )),
                                new ExampleTemplate("template2", "模板2", List.of(
                                        "帮我整理研发周会的会议纪要（含待办与风险）",
                                        "生成客户拜访/销售复盘会议纪要模板",
                                        "基于参会人员自动汇总座谈会纪要与行动项"
                                )),
                                new ExampleTemplate("template3", "模板3", List.of(
                                        "整理敏捷迭代回顾会会议纪要并给出改进建议",
                                        "生成跨部门协作沟通会的纪要与决策清单",
                                        "根据培训课件自动输出培训会议纪要+重点摘要"
                                ))
                        )),
                new TabConfig("writing", "辅助写作", "✍️", List.of(
                        "帮我写一封正式的商务合作邀请函",
                        "撰写一份年终总结报告的大纲",
                        "写一篇关于数字化转型的公众号文章"
                ))
        );
        return CommonResult.success(tabs);
    }

    private void sendError(SseEmitter emitter, String msg) {
        try {
            String event = OBJECT_MAPPER.writeValueAsString(Map.of(
                    "type", "error",
                    "content", msg
            ));
            emitter.send(SseEmitter.event().data(event));
        } catch (Exception ignored) {
        }
    }
}
