package com.ruoyi.web.ai.dto;

import java.util.List;

/**
 * Tab 配置 DTO
 */
public class TabConfig {

    /** Tab 键 */
    private String key;

    /** Tab 名称 */
    private String name;

    /** Tab 图标 */
    private String icon;

    /** 示例问题列表 */
    private List<String> examples;

    /**
     * 模板：用于"会议纪要"等需要多套示例问题的场景。
     * templates 中的每一项都对应一组 examples（3个示例问题），前端会在示例问题上方显示"模板1/2/3"切换按钮，
     * 切换后显示对应模板的 examples。
     */
    private List<ExampleTemplate> templates;

    public TabConfig() {}

    public TabConfig(String key, String name, String icon, List<String> examples) {
        this.key = key;
        this.name = name;
        this.icon = icon;
        this.examples = examples;
    }

    public TabConfig(String key, String name, String icon, List<String> examples, List<ExampleTemplate> templates) {
        this.key = key;
        this.name = name;
        this.icon = icon;
        this.examples = examples;
        this.templates = templates;
    }

    public String getKey() {
        return key;
    }

    public void setKey(String key) {
        this.key = key;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getIcon() {
        return icon;
    }

    public void setIcon(String icon) {
        this.icon = icon;
    }

    public List<String> getExamples() {
        return examples;
    }

    public void setExamples(List<String> examples) {
        this.examples = examples;
    }

    public List<ExampleTemplate> getTemplates() {
        return templates;
    }

    public void setTemplates(List<ExampleTemplate> templates) {
        this.templates = templates;
    }
}
