package com.ruoyi.web.ai.dto;

/**
 * 聊天请求 DTO
 */
public class ChatRequest {

    /** 用户问题 */
    private String question;

    /** 会话ID（可选，新会话时不传） */
    private Long conversationId;

    /** 类型：chat/translate/meeting/writing */
    private String type;

    /** 是否使用模拟数据 */
    private Boolean useMock;

    public String getQuestion() {
        return question;
    }

    public void setQuestion(String question) {
        this.question = question;
    }

    public Long getConversationId() {
        return conversationId;
    }

    public void setConversationId(Long conversationId) {
        this.conversationId = conversationId;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public Boolean getUseMock() {
        return useMock;
    }

    public void setUseMock(Boolean useMock) {
        this.useMock = useMock;
    }
}
