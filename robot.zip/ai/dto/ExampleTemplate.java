package com.ruoyi.web.ai.dto;

import java.util.List;

/**
 * 示例问题模板
 */
public class ExampleTemplate {

    /** 模板键，如 template1 */
    private String key;

    /** 模板名称，如 模板1 */
    private String name;

    /** 该模板下的示例问题（3条） */
    private List<String> examples;

    public ExampleTemplate() {}

    public ExampleTemplate(String key, String name, List<String> examples) {
        this.key = key;
        this.name = name;
        this.examples = examples;
    }

    public String getKey() { return key; }
    public void setKey(String key) { this.key = key; }
    public String getName() { return name; }
    public void setName(String name) { this.name = name; }
    public List<String> getExamples() { return examples; }
    public void setExamples(List<String> examples) { this.examples = examples; }
}
