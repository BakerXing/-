package com.ruoyi.web.ai.service;

import org.springframework.web.servlet.mvc.method.annotation.SseEmitter;

/**
 * DeepSeek AI 服务接口
 */
public interface DeepSeekService {

    /**
     * 流式聊天（通过 SseEmitter 推送）
     *
     * @param question 用户问题
     * @param type     类型（chat/translate/meeting/writing）
     * @param emitter  SSE 发射器
     * @return 完整内容
     */
    String streamChat(String question, String type, SseEmitter emitter);

    /**
     * 获取模拟回答（无 API Key 时降级使用）
     */
    String getMockReply(String question, String type);
}
