package com.ruoyi.web.ai.service.impl;

import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.ruoyi.web.ai.entity.AiConversation;
import com.ruoyi.web.ai.mapper.AiConversationMapper;
import com.ruoyi.web.ai.service.AiConversationService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDateTime;
import java.util.List;

/**
 * AI 会话 Service 实现
 */
@Service
public class AiConversationServiceImpl implements AiConversationService {

    private static final Logger log = LoggerFactory.getLogger(AiConversationServiceImpl.class);

    private static final int MAX_CONVERSATIONS = 20;
    private static final int MAX_PINNED = 15;

    @Autowired
    private AiConversationMapper conversationMapper;

    @Override
    public List<AiConversation> listByUserId(Long userId) {
        return conversationMapper.selectByUserId(userId);
    }

    @Override
    @Transactional
    public AiConversation create(Long userId, String title, String type) {
        AiConversation conv = new AiConversation();
        conv.setUserId(userId);
        conv.setTitle(title);
        conv.setType(type);
        conv.setIsPinned("0");
        conv.setCreateTime(LocalDateTime.now());
        conv.setUpdateTime(LocalDateTime.now());
        conversationMapper.insert(conv);
        enforceLimits(userId);
        return conv;
    }

    @Override
    @Transactional
    public void update(AiConversation conversation) {
        conversation.setUpdateTime(LocalDateTime.now());
        conversationMapper.updateById(conversation);
    }

    @Override
    @Transactional
    public void delete(Long id, Long userId) {
        // 删除会话下的所有消息
        conversationMapper.deleteById(id);
    }

    @Override
    @Transactional
    public void togglePin(Long id, Long userId) {
        AiConversation conv = conversationMapper.selectById(id);
        if (conv == null || !conv.getUserId().equals(userId)) {
            throw new RuntimeException("会话不存在或无权操作");
        }
        if ("1".equals(conv.getIsPinned())) {
            conv.setIsPinned("0");
        } else {
            // 检查置顶数量限制
            int pinnedCount = conversationMapper.countPinned(userId);
            if (pinnedCount >= MAX_PINNED) {
                throw new RuntimeException("置顶数量已达上限（最多" + MAX_PINNED + "条）");
            }
            conv.setIsPinned("1");
        }
        conv.setUpdateTime(LocalDateTime.now());
        conversationMapper.updateById(conv);
    }

    @Override
    @Transactional
    public void updateTitle(Long id, String title) {
        AiConversation conv = conversationMapper.selectById(id);
        if (conv != null) {
            conv.setTitle(title);
            conv.setUpdateTime(LocalDateTime.now());
            conversationMapper.updateById(conv);
        }
    }

    @Override
    @Transactional
    public void enforceLimits(Long userId) {
        int total = conversationMapper.countByUserId(userId);
        if (total > MAX_CONVERSATIONS) {
            // 删除未置顶且最旧的会话
            LambdaQueryWrapper<AiConversation> wrapper = new LambdaQueryWrapper<>();
            wrapper.eq(AiConversation::getUserId, userId)
                    .eq(AiConversation::getIsPinned, "0")
                    .orderByAsc(AiConversation::getUpdateTime)
                    .last("LIMIT " + (total - MAX_CONVERSATIONS));
            List<AiConversation> toDelete = conversationMapper.selectList(wrapper);
            for (AiConversation conv : toDelete) {
                conversationMapper.deleteById(conv.getId());
            }
            log.info("Cleaned up {} conversations for user {}", toDelete.size(), userId);
        }
    }

    @Override
    public AiConversation getById(Long id) {
        return conversationMapper.selectById(id);
    }
}
