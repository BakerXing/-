package com.ruoyi.web.ai.service.impl;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.ruoyi.web.ai.service.DeepSeekService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.web.servlet.mvc.method.annotation.SseEmitter;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.nio.charset.StandardCharsets;
import java.time.Duration;
import java.util.*;

/**
 * DeepSeek 服务实现
 */
@Service
public class DeepSeekServiceImpl implements DeepSeekService {

    private static final Logger log = LoggerFactory.getLogger(DeepSeekServiceImpl.class);
    private static final ObjectMapper OBJECT_MAPPER = new ObjectMapper();

    @Value("${deepseek.api.key:}")
    private String apiKey;

    @Value("${deepseek.api.url:https://api.deepseek.com/v1/chat/completions}")
    private String apiUrl;

    @Value("${deepseek.model:deepseek-chat}")
    private String model;

    private final HttpClient httpClient;

    public DeepSeekServiceImpl() {
        this.httpClient = HttpClient.newBuilder()
                .connectTimeout(Duration.ofSeconds(30))
                .build();
    }

    @Override
    public String streamChat(String question, String type, SseEmitter emitter) {
//        if (apiKey == null || apiKey.isBlank()) {
//            return streamMockReply(question, type, emitter);
//        }
        try {
            return doStreamChat(question, type, emitter);
        } catch (Exception e) {
            log.error("DeepSeek 流式调用失败，降级为模拟回答", e);
            try {
                emitter.send(SseEmitter.event().data("{\"type\":\"error\",\"content\":\"AI 服务暂时不可用，已切换为模拟回答\"}"));
            } catch (Exception ex) {
                log.error("SSE 发送失败", ex);
            }
            return streamMockReply(question, type, emitter);
        }
    }

    private String doStreamChat(String question, String type, SseEmitter emitter) throws Exception {
        List<Map<String, String>> messages = new ArrayList<>();
        // 系统提示词根据类型
        String systemPrompt = getSystemPrompt(type);
        messages.add(Map.of("role", "system", "content", systemPrompt));
        messages.add(Map.of("role", "user", "content", question));

        Map<String, Object> body = new HashMap<>();
        body.put("model", model);
        body.put("messages", messages);
        body.put("stream", true);

        String jsonBody = OBJECT_MAPPER.writeValueAsString(body);

        HttpRequest request = HttpRequest.newBuilder()
                .uri(URI.create(apiUrl))
                .header("Content-Type", "application/json")
                .header("Authorization", "Bearer " + apiKey)
                .timeout(Duration.ofMinutes(5))
                .POST(HttpRequest.BodyPublishers.ofString(jsonBody, StandardCharsets.UTF_8))
                .build();

        HttpResponse<java.io.InputStream> response = httpClient.send(request,
                HttpResponse.BodyHandlers.ofInputStream());

        if (response.statusCode() != 200) {
            String errorBody = new String(response.body().readAllBytes(), StandardCharsets.UTF_8);
            log.error("DeepSeek API 返回错误: status={}, body={}", response.statusCode(), errorBody);
            throw new RuntimeException("AI 服务返回错误: " + response.statusCode());
        }

        StringBuilder fullContent = new StringBuilder();
        try (BufferedReader reader = new BufferedReader(
                new InputStreamReader(response.body(), StandardCharsets.UTF_8))) {
            String line;
            while ((line = reader.readLine()) != null) {
                if (line.isEmpty()) continue;
                if (!line.startsWith("data:")) continue;
                String data = line.substring(5).trim();
                if ("[DONE]".equals(data)) break;

                try {
                    JsonNode node = OBJECT_MAPPER.readTree(data);
                    JsonNode choices = node.get("choices");
                    if (choices != null && choices.isArray() && choices.size() > 0) {
                        JsonNode delta = choices.get(0).get("delta");
                        if (delta != null && delta.has("content")) {
                            String content = delta.get("content").asText();
                            fullContent.append(content);
                            String event = OBJECT_MAPPER.writeValueAsString(Map.of(
                                    "type", "delta",
                                    "content", content,
                                    "fullContent", fullContent.toString()
                            ));
                            emitter.send(SseEmitter.event().data(event));
                        }
                    }
                } catch (Exception e) {
                    log.warn("解析 SSE 数据行失败: {}", data, e);
                }
            }
        }

        // 发送完成事件
        String completeEvent = OBJECT_MAPPER.writeValueAsString(Map.of(
                "type", "complete",
                "content", fullContent.toString()
        ));
        emitter.send(SseEmitter.event().data(completeEvent));
        // 不在此处关闭 emitter，由调用方负责
        return fullContent.toString();
    }

    private String streamMockReply(String question, String type, SseEmitter emitter) {
        try {
            String mock = getMockReply(question, type);
            StringBuilder accumulated = new StringBuilder();
            // 模拟流式输出，逐字推送
            for (int i = 0; i < mock.length(); i += 2) {
                String chunk = mock.substring(i, Math.min(i + 2, mock.length()));
                accumulated.append(chunk);
                String event = OBJECT_MAPPER.writeValueAsString(Map.of(
                        "type", "delta",
                        "content", chunk,
                        "fullContent", accumulated.toString()
                ));
                emitter.send(SseEmitter.event().data(event));
                Thread.sleep(30);
            }
            String completeEvent = OBJECT_MAPPER.writeValueAsString(Map.of(
                    "type", "complete",
                    "content", accumulated.toString()
            ));
            emitter.send(SseEmitter.event().data(completeEvent));
            // 不在此处关闭 emitter，由调用方负责
            return accumulated.toString();
        } catch (Exception e) {
            log.error("模拟流式输出失败", e);
            return "";
        }
    }

    @Override
    public String getMockReply(String question, String type) {
        return switch (type) {
            case "translate" -> buildTranslateMock(question);
            case "meeting" -> buildMeetingMock(question);
            case "writing" -> buildWritingMock(question);
            default -> buildChatMock(question);
        };
    }

    private String buildChatMock(String question) {
        return """
                你好！我是智聊助手，很高兴为你解答问题。

                关于"**%s**"，以下是我的分析：

                1. **核心观点**：这个问题涉及多个方面，需要从不同角度来看待。
                2. **要点梳理**：
                   - 首先，需要明确问题的背景和上下文
                   - 其次，分析关键因素和影响
                   - 最后，提出可行的解决方案
                3. **建议**：建议你根据实际情况，结合以上分析进行决策。

                如果你需要更详细的解释或有其他问题，随时告诉我！
                """.formatted(question);
    }

    private String buildTranslateMock(String question) {
        return """
                ## 翻译结果

                **原文**：%s

                **译文**：

                这是一段模拟的翻译结果。在实际使用中，系统会调用 DeepSeek AI 模型进行高质量的翻译服务，支持多语言互译、专业术语处理、上下文理解等功能。

                ### 翻译说明
                - 支持中、英、日、韩、法、德等主流语言
                - 保留原文格式和标点
                - 专业术语自动识别
                - 可选择直译或意译

                > 💡 提示：配置 API Key 后即可使用真实 AI 翻译
                """.formatted(question);
    }

    private String buildMeetingMock(String question) {
        return """
                ## 会议纪要

                **主题**：%s

                ### 一、会议概况
                - **时间**：%s
                - **地点**：会议室 A
                - **参会人员**：张三、李四、王五

                ### 二、讨论议题
                1. 项目进度汇报
                2. 下周工作计划
                3. 风险与问题讨论

                ### 三、决议事项
                | 序号 | 事项 | 责任人 | 截止日期 |
                |------|------|--------|----------|
                | 1 | 完成需求评审 | 张三 | 本周五 |
                | 2 | 提交设计方案 | 李四 | 下周一 |

                ### 四、待办事项
                - [ ] 整理会议文档并发送
                - [ ] 更新项目计划表

                ---
                *本纪要由 AI 智能生成，如有偏差请以实际记录为准。*
                """.formatted(question, java.time.LocalDate.now());
    }

    private String buildWritingMock(String question) {
        return """
                ## 写作助手

                **主题**：%s

                ### 大纲
                1. 引言
                   - 背景介绍
                   - 问题提出
                2. 主体论述
                   - 论点一：详细阐述
                   - 论点二：案例分析
                   - 论点三：对比讨论
                3. 结论
                   - 总结要点
                   - 展望建议

                ### 正文示例

                随着时代的发展，这一话题越来越受到广泛关注。本文将从多个角度进行深入探讨...

                > 💡 配置 API Key 后，AI 将根据你的需求生成完整的文章内容
                """.formatted(question);
    }

    private String getSystemPrompt(String type) {
        return switch (type) {
            case "translate" -> "你是一个专业的翻译助手，支持多语言互译。请准确、流畅地翻译用户输入的内容，保留原文的格式和语气。";
            case "meeting" -> "你是一个会议纪要助手。请根据用户提供的信息，生成结构清晰、重点突出的会议纪要，包括会议概况、讨论议题、决议事项和待办事项。";
            case "writing" -> "你是一个写作助手。请根据用户的主题要求，生成结构完整、内容充实的文章或文案，包括大纲和正文。";
            default -> "你是一个智能助手，擅长回答各种问题，提供准确、有用的信息。请用中文回答，保持友好和专业的语气。";
        };
    }
}
