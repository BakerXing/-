package com.ruoyi.web.ai.service.impl;

import com.ruoyi.web.ai.service.AsrService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;
import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.nio.charset.StandardCharsets;
import java.time.Duration;
import java.util.Base64;

/**
 * 语音识别服务实现
 * <p>
 * 支持百度智能云语音识别 REST API。
 * 配置 asr.api-key 和 asr.secret-key 后启用真实识别；未配置时返回模拟数据。
 */
@Service
public class AsrServiceImpl implements AsrService {

    private static final Logger log = LoggerFactory.getLogger(AsrServiceImpl.class);

    @Value("${asr.api-key:}")
    private String apiKey;

    @Value("${asr.secret-key:}")
    private String secretKey;

    @Value("${asr.api-url:https://vop.baidu.com/server_api}")
    private String apiUrl;

    private volatile String cachedToken;
    private volatile long tokenExpireAt;

    @Override
    public String recognize(MultipartFile file) {
        if (apiKey == null || apiKey.isBlank() || secretKey == null || secretKey.isBlank()) {
            log.warn("ASR API key 未配置，返回模拟数据");
            return getMockResult(file.getOriginalFilename());
        }
        try {
            String token = getAccessToken();
            byte[] audioBytes = file.getBytes();
            String base64Audio = Base64.getEncoder().encodeToString(audioBytes);
            String fileName = file.getOriginalFilename() != null ? file.getOriginalFilename() : "audio.wav";
            String format = getFormat(fileName);
            int rate = 16000;

            String body = "{" +
                    "\"format\":\"" + format + "\"," +
                    "\"rate\":" + rate + "," +
                    "\"channel\":1," +
                    "\"cuid\":\"ruoyi-asr\"," +
                    "\"token\":\"" + token + "\"," +
                    "\"speech\":\"" + base64Audio + "\"," +
                    "\"len\":" + audioBytes.length +
                    "}";

            HttpClient client = HttpClient.newBuilder().connectTimeout(Duration.ofSeconds(30)).build();
            HttpRequest request = HttpRequest.newBuilder()
                    .uri(URI.create(apiUrl + "?c_net=1"))
                    .header("Content-Type", "application/json")
                    .POST(HttpRequest.BodyPublishers.ofString(body))
                    .build();
            HttpResponse<String> response = client.send(request, HttpResponse.BodyHandlers.ofString());
            String responseBody = response.body();
            log.debug("ASR response: {}", responseBody);
            // 解析百度返回 JSON: {"err_no":0,"result":["识别文字"]}
            if (responseBody.contains("\"err_no\":0") || responseBody.contains("\"err_no\": 0")) {
                int idx = responseBody.indexOf("\"result\"");
                if (idx > -1) {
                    int start = responseBody.indexOf('[', idx);
                    int end = responseBody.indexOf(']', start);
                    if (start > -1 && end > -1) {
                        String arr = responseBody.substring(start + 1, end);
                        // 去掉引号
                        return arr.replace("\"", "").replace("\\n", "\n").trim();
                    }
                }
            }
            return "语音识别失败：" + responseBody;
        } catch (Exception e) {
            log.error("ASR 识别异常", e);
            return "语音识别异常：" + e.getMessage();
        }
    }

    /**
     * 获取百度 access_token
     */
    private String getAccessToken() throws IOException, InterruptedException {
        long now = System.currentTimeMillis();
        if (cachedToken != null && now < tokenExpireAt) {
            return cachedToken;
        }
        String tokenUrl = "https://aip.baidubce.com/oauth/2.0/token?grant_type=client_credentials&client_id="
                + apiKey + "&client_secret=" + secretKey;
        HttpClient client = HttpClient.newBuilder().connectTimeout(Duration.ofSeconds(15)).build();
        HttpRequest request = HttpRequest.newBuilder()
                .uri(URI.create(tokenUrl))
                .header("Content-Type", "application/json")
                .POST(HttpRequest.BodyPublishers.noBody())
                .build();
        HttpResponse<String> response = client.send(request, HttpResponse.BodyHandlers.ofString());
        String body = response.body();
        int idx = body.indexOf("\"access_token\"");
        if (idx > -1) {
            int start = body.indexOf('"', idx + 14);
            int end = body.indexOf('"', start + 1);
            cachedToken = body.substring(start + 1, end);
            tokenExpireAt = now + 2592000_000L; // 30 天
            return cachedToken;
        }
        throw new IOException("获取 access_token 失败：" + body);
    }

    private String getFormat(String fileName) {
        if (fileName == null) return "wav";
        String lower = fileName.toLowerCase();
        if (lower.endsWith(".mp3")) return "mp3";
        if (lower.endsWith(".m4a")) return "m4a";
        if (lower.endsWith(".aac")) return "aac";
        if (lower.endsWith(".ogg")) return "ogg";
        if (lower.endsWith(".flac")) return "flac";
        return "wav";
    }

    private String getMockResult(String fileName) {
        return "【音频转文字 - 模拟结果】\n" +
                "文件：" + (fileName != null ? fileName : "未知") + "\n\n" +
                "本次会议于上午10:00开始，参会人员包括产品经理张三、开发组长李四和测试负责人王五。\n" +
                "会议议程：\n" +
                "1. 回顾上周工作进展：前端完成了4个页面的开发，后端接口已联调通过。\n" +
                "2. 讨论下一版本功能规划：确定新增数据分析模块和用户权限细化两个核心功能。\n" +
                "3. 排期确认：需求评审定于本周五，开发预计两周，测试同步介入编写用例。\n" +
                "4. 风险提示：第三方支付接口文档尚未更新，需要催促供应商尽快提供。\n\n" +
                "（注：当前未配置百度语音识别 API，此为模拟内容。在 application.yml 中配置 asr.api-key 和 asr.secret-key 后可使用真实语音识别。）";
    }
}
