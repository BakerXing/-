package com.ruoyi.web.ai.service.impl;

import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.ruoyi.web.ai.entity.AiMessage;
import com.ruoyi.web.ai.mapper.AiMessageMapper;
import com.ruoyi.web.ai.service.AiMessageService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.List;

/**
 * AI 消息 Service 实现
 */
@Service
public class AiMessageServiceImpl implements AiMessageService {

    @Autowired
    private AiMessageMapper messageMapper;

    @Override
    public List<AiMessage> listByConversationId(Long conversationId) {
        return messageMapper.selectByConversationId(conversationId);
    }

    @Override
    public AiMessage save(AiMessage message) {
        if (message.getCreateTime() == null) {
            message.setCreateTime(LocalDateTime.now());
        }
        if (message.getUpdateTime() == null) {
            message.setUpdateTime(LocalDateTime.now());
        }
        messageMapper.insert(message);
        return message;
    }

    @Override
    public Long saveAndReturnId(AiMessage message) {
        if (message.getCreateTime() == null) {
            message.setCreateTime(LocalDateTime.now());
        }
        if (message.getUpdateTime() == null) {
            message.setUpdateTime(LocalDateTime.now());
        }
        messageMapper.insert(message);
        return message.getId();
    }

    @Override
    public void update(AiMessage message) {
        message.setUpdateTime(LocalDateTime.now());
        messageMapper.updateById(message);
    }

    @Override
    public void deleteByConversationId(Long conversationId) {
        LambdaQueryWrapper<AiMessage> wrapper = new LambdaQueryWrapper<>();
        wrapper.eq(AiMessage::getConversationId, conversationId);
        messageMapper.delete(wrapper);
    }
}
