package com.ruoyi.web.ai.service;

import org.springframework.web.multipart.MultipartFile;

/**
 * 语音识别（ASR）服务接口
 */
public interface AsrService {

    /**
     * 将音频文件转为文字
     *
     * @param file 音频文件
     * @return 识别出的文字
     */
    String recognize(MultipartFile file);
}
