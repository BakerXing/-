package com.ruoyi.web.ai.service;

import com.ruoyi.web.ai.entity.AiConversation;

import java.util.List;

/**
 * AI 会话 Service
 */
public interface AiConversationService {

    /**
     * 查询用户会话列表
     */
    List<AiConversation> listByUserId(Long userId);

    /**
     * 创建会话
     */
    AiConversation create(Long userId, String title, String type);

    /**
     * 更新会话
     */
    void update(AiConversation conversation);

    /**
     * 删除会话
     */
    void delete(Long id, Long userId);

    /**
     * 切换置顶状态
     */
    void togglePin(Long id, Long userId);

    /**
     * 更新会话标题
     */
    void updateTitle(Long id, String title);

    /**
     * 检查并清理超出限制的会话（最多20条，置顶最多15条）
     */
    void enforceLimits(Long userId);

    /**
     * 根据ID查询
     */
    AiConversation getById(Long id);
}
