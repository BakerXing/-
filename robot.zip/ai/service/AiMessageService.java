package com.ruoyi.web.ai.service;

import com.ruoyi.web.ai.entity.AiMessage;

import java.util.List;

/**
 * AI 消息 Service
 */
public interface AiMessageService {

    /**
     * 查询会话消息列表
     */
    List<AiMessage> listByConversationId(Long conversationId);

    /**
     * 保存消息
     */
    AiMessage save(AiMessage message);

    /**
     * 保存并返回ID
     */
    Long saveAndReturnId(AiMessage message);

    /**
     * 更新消息
     */
    void update(AiMessage message);

    /**
     * 删除会话下的所有消息
     */
    void deleteByConversationId(Long conversationId);
}
