import request from '@/utils/request'

export interface AiConversation {
  id: number
  title: string
  type: string
  isPinned: string
  userId: number
  createTime: string
  updateTime: string
}

export interface AiMessage {
  id: number
  conversationId: number
  role: string
  content: string
  type: string
  isComplete: string
  createTime: string
}

export interface ExampleTemplate {
  key: string
  name: string
  examples: string[]
}

export interface TabConfig {
  key: string
  name: string
  icon: string
  examples: string[]
  templates?: ExampleTemplate[]
}

// 获取会话列表
export const listConversations = () => {
  return request.get('/ai/chat/conversations')
}

// 获取会话消息
export const getMessages = (id: number) => {
  return request.get(`/ai/chat/conversations/${id}/messages`)
}

// 创建会话
export const createConversation = (data: { title: string; type: string }) => {
  return request.post('/ai/chat/conversations', data)
}

// 删除会话
export const deleteConversation = (id: number) => {
  return request.delete(`/ai/chat/conversations/${id}`)
}

// 切换置顶
export const togglePin = (id: number) => {
  return request.post(`/ai/chat/conversations/${id}/pin`)
}

// 更新标题
export const updateTitle = (id: number, title: string) => {
  return request.put(`/ai/chat/conversations/${id}/title`, { title })
}

// 获取 Tab 配置
export const getTabConfigs = () => {
  return request.get('/ai/chat/tabs')
}

// 上传文件（txt/音频），返回转换后的文字
export const uploadFile = (file: File) => {
  const formData = new FormData()
  formData.append('file', file)
  return request.post('/ai/chat/upload', formData, {
    headers: { 'Content-Type': 'multipart/form-data' }
  })
}

// 构建 SSE 流式 URL
export const buildStreamUrl = (params: {
  question: string
  conversationId?: number
  type: string
}) => {
  const base = import.meta.env.VITE_APP_BASE_API || ''
  const token = localStorage.getItem('Admin-Token') || ''
  const qs = new URLSearchParams()
  qs.set('question', params.question)
  qs.set('type', params.type)
  qs.set('token', token)
  if (params.conversationId) {
    qs.set('conversationId', String(params.conversationId))
  }
  // 添加 token 作为查询参数（SSE 不支持自定义 header）
  const url = `${base}/ai/chat/stream?${qs.toString()}`
  return { url, token }
}
