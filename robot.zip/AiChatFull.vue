<!--
  ====================================================================================
  组件名称：AiChatFull.vue（大页面 AI 助手组件）
  ====================================================================================
  功能概述：
    本组件是「数智员工」系统的完整版大页面聊天界面，通过路由 /ai/chat 访问。
    相比小窗口（AiWidget.vue），提供更丰富的会话管理能力，包括：
    会话列表展示、置顶、删除、搜索、历史记录加载、新窗口独立打开等功能。
    适用于需要长时间、深入对话的场景。

  主要功能模块：
    1. 侧边栏（sidebar）：品牌标识、新建对话、搜索框、历史会话列表（支持钉住/删除）
    2. 侧边栏折叠：可折叠为 60px 窄边，仅显示会话图标
    3. 顶部选项卡行：主选项卡「小信智聊」+ 三个子选项卡并列，虚线分隔
    4. 内容区：欢迎区（模板 + 示例） / 对话区（多轮消息流式渲染）
    5. 文件上传：仅「会议纪要」选项卡支持，可上传 .txt 和音频文件
    6. 输入区：自适应高度文本框 + 内嵌发送按钮
    7. 消息渲染：用户消息纯文本 / AI 消息 Markdown 渲染
    8. 流式输出：真实 SSE + 模拟打字机效果（3 秒超时回退）
    9. 会话管理：钉住最多 15 个、显示最多 20 条、删除二次确认

  数据流：
    - 会话列表：onMounted 调 listConversations 加载
    - 切换会话：selectConversation → 加载消息列表 → 自动切换选项卡
    - 发送消息：先 push 用户消息 + 空的 AI 消息占位 → SSE/模拟流式更新最后一条 AI 消息
    - 删除会话：两次 ElMessageBox.confirm 二次确认 → 删除 API + 本地同步
    - 选项卡切换：复位 activeConversationId、清空消息（重新回到欢迎页）

  依赖：
    - Vue3 Composition API（ref、computed、onMounted、nextTick）
    - Vue Router（useRouter 用于关闭返回）
    - Element Plus（ElMessage、ElMessageBox、el-input、el-button、el-icon、el-tooltip）
    - @element-plus/icons-vue 图标库
    - @/api/ai/chat 后端 API
  ====================================================================================
-->
<template>
  <div class="ai-chat-full">
    <div class="ai-full">
      <!-- ============ 侧边栏（sidebar） ============ -->
      <!-- 包含：品牌标识、新建对话、搜索框、历史会话列表、折叠/展开按钮 -->
      <!-- 折叠状态通过 sidebarCollapsed 控制，class 加 is-collapsed -->
      <aside class="ai-full__sidebar" :class="{ 'is-collapsed': sidebarCollapsed }">
        <!-- 品牌头部：机器人图标 + 名称（折叠时隐藏名称） -->
        <div class="ai-full__sidebar-header">
          <div class="ai-full__brand">
            <span class="ai-full__brand-icon">🤖</span>
            <span v-if="!sidebarCollapsed" class="ai-full__brand-name">数智员工</span>
          </div>
        </div>

        <!-- 新建对话按钮：清空当前会话和消息列表 -->
        <div v-if="!sidebarCollapsed" class="ai-full__new-chat" @click="handleNewChat">
          <el-icon><Plus /></el-icon>
          <span>新建对话</span>
        </div>

        <!-- 搜索框：实时过滤会话标题 -->
        <div v-if="!sidebarCollapsed" class="ai-full__search">
          <el-icon class="ai-full__search-icon"><Search /></el-icon>
          <input
            v-model="searchKeyword"
            type="text"
            class="ai-full__search-input"
            placeholder="搜索会话..."
          />
        </div>

        <!-- 历史对话标题 -->
        <div v-if="!sidebarCollapsed" class="ai-full__history-title">历史对话</div>

        <!-- 历史会话列表（v-show 控制可见性而非 v-if，保留 DOM） -->
        <div class="ai-full__conversation-list" v-show="!sidebarCollapsed">
          <!-- 单条会话项：类型图标 + 标题 + 时间 + 操作按钮（钉住/删除） -->
          <div
            v-for="conv, idx in displayedConversations"
            :key="conv.id"
            class="ai-full__conversation"
            :class="{ 'is-active': activeConversationId === conv.id, 'is-pinned': conv.isPinned === '1' }"
            @click="selectConversation(conv.id)"
          >
            <!-- 会话类型图标（根据 conv.type 映射 emoji） -->
            <span class="ai-full__conv-type-icon">{{ getTabIcon(conv.type) }}</span>
            <div class="ai-full__conv-info">
              <!-- 会话标题（超长省略号） -->
              <span class="ai-full__conv-title">{{ conv.title }}</span>
            </div>
            <!-- 相对时间显示（刚刚/X 分钟前/X 小时前/具体时间） -->
            <span class="ai-full__conv-time">{{ formatTime(conv.updateTime) }}</span>
            <!-- 操作按钮组：阻止冒泡，避免触发会话点击事件 -->
            <div class="ai-full__conv-actions" @click.stop>
              <!-- 钉住/取消置顶按钮：未钉住显示空心 Star，已钉住显示实心 StarFilled -->
              <el-icon
                class="ai-full__action-btn"
                :title="conv.isPinned === '1' ? '取消置顶' : '置顶'"
                @click="handlePin(conv)"
              >
                <Star v-if="conv.isPinned !== '1'" />
                <StarFilled v-else />
              </el-icon>
              <!-- 删除按钮：触发二次确认流程 -->
              <el-icon class="ai-full__action-btn" title="删除" @click="handleDelete(conv)">
                <Delete />
              </el-icon>
            </div>
          </div>
          <!-- 空状态提示 -->
          <div v-if="displayedConversations.length === 0" class="ai-full__empty">
            暂无对话记录
          </div>
          <!-- 超过 20 条的提示 -->
          <div v-if="conversations.length > 20" class="ai-full__more-hint">
            仅显示最近20条会话
          </div>
        </div>

        <!-- 折叠状态下的会话列表：仅显示前 5 条的图标 -->
        <div v-if="sidebarCollapsed" class="ai-full__collapsed-list">
          <div
            v-for="conv in filteredConversations.slice(0, 5)"
            :key="conv.id"
            class="ai-full__collapsed-item"
            :class="{ 'is-active': activeConversationId === conv.id }"
            :title="conv.title"
            @click="selectConversation(conv.id)"
          >
            {{ getTabIcon(conv.type) }}
          </div>
        </div>

        <!-- 侧边栏底部：折叠/展开按钮（双向双箭头图标） -->
        <div class="ai-full__sidebar-footer">
          <el-icon
            class="ai-full__collapse-btn"
            :title="sidebarCollapsed ? '展开' : '收起'"
            @click="sidebarCollapsed = !sidebarCollapsed"
          >
            <DArrowLeft v-if="!sidebarCollapsed" />
            <DArrowRight v-else />
          </el-icon>
        </div>
      </aside>

      <!-- ============ 聊天区（chat main） ============ -->
      <main class="ai-full__chat">
        <!-- ---------- 顶部选项卡行：所有选项卡并列一行 + 关闭按钮 ---------- -->
        <div class="ai-full__header">
          <div class="ai-full__tab-group">
            <!-- 主选项卡：小信智聊（更大尺寸，蓝色主题） -->
            <div
              class="ai-full__tab-primary"
              :class="{ 'is-active': activeTab === 'chat' }"
              @click="switchTab('chat')"
            >
              <span class="ai-full__tab-primary-icon">💬</span>
              <span class="ai-full__tab-primary-name">小信智聊</span>
            </div>
            <!-- 主选项卡与子选项卡之间的虚线分隔符 -->
            <span class="ai-full__tab-divider"></span>
            <!-- 子选项卡循环：翻译 / 会议纪要 / 辅助写作 -->
            <template v-for="(tab, idx) in subTabs" :key="tab.key">
              <div
                class="ai-full__tab"
                :class="{ 'is-active': activeTab === tab.key }"
                @click="switchTab(tab.key)"
              >
                <!-- 子选项卡图标颜色由 tabIconColors 映射动态设置 -->
                <span class="ai-full__tab-icon" :style="{ color: tabIconColors[tab.key] }">{{ tab.icon }}</span>
                <span class="ai-full__tab-name">{{ tab.name }}</span>
              </div>
              <!-- 子选项卡之间的分隔符（最后一个不显示） -->
             <span v-if="idx < subTabs.length - 1" class="ai-full__tab-divider3"></span>   
            </template>
          </div>
          <!-- 关闭按钮：调用 goBack 返回上一页 -->
          <div class="ai-full__actions">
            <el-tooltip content="关闭" placement="bottom" :show-after="300">
              <el-icon class="ai-full__action-btn-top is-close" @click="goBack" :size="28"><Close /></el-icon>
            </el-tooltip>
          </div>
        </div>

        <!-- ---------- 内容区（body）---------- -->
        <!-- chatBodyRef 用于自动滚动到底部 -->
        <div class="ai-full__body" ref="chatBodyRef">

          <!-- 欢迎区：当前会话无消息时显示模板按钮和示例问题 -->
          <div v-if="currentMessages.length === 0" class="ai-full__welcome">
            <!-- 模板按钮组（如有）：切换示例集 -->
            <div v-if="currentTemplates.length" class="ai-full__templates">
              <div
                v-for="tpl in currentTemplates"
                :key="tpl.key"
                class="ai-full__template"
                :class="{ 'is-active': activeTemplateKey === tpl.key }"
                @click="selectTemplate(tpl.key)"
              >
                {{ tpl.name }}
              </div>
            </div>
            <!-- 示例问题列表：点击直接发送 -->
            <div class="ai-full__examples">
              <div
                v-for="(example, idx) in currentTabExamples"
                :key="idx"
                class="ai-full__example"
                @click="sendExample(example)"
              >
                <span class="ai-full__example-icon">{{ getExampleIcon(idx) }}</span>
                <span class="ai-full__example-text">{{ example }}</span>
              </div>
            </div>
          </div>

          <!-- 对话区：遍历 currentMessages 渲染每条消息 -->
          <template v-else>
            <!-- 每条消息：用户消息靠右 / AI 消息靠左，含头像 + 内容 -->
            <div v-for="(msg, idx) in currentMessages" :key="idx" class="ai-full__msg" :class="`is-${msg.role}`">
              <!-- 头像：用户😊 / AI🤖 -->
              <div class="ai-full__msg-avatar">
                {{ msg.role === 'user' ? '😊' : '🤖' }}
              </div>
              <div class="ai-full__msg-content">
                <!-- AI 消息且有内容：渲染 Markdown -->
                <div v-if="msg.role === 'assistant' && msg.content" class="ai-full__markdown" v-html="renderMarkdown(msg.content)"></div>
                <!-- 其他情况：纯文本 -->
                <div v-else class="ai-full__text">{{ msg.content }}</div>
                <!-- AI 消息、加载中、是最后一条且未完成：显示三点跳动动画 -->
                <div v-if="msg.role === 'assistant' && loading && idx === currentMessages.length - 1 && msg.isComplete === '0'" class="ai-full__typing">
                  <span></span><span></span><span></span>
                </div>
              </div>
            </div>
          </template>

          <!-- 已上传文件卡片列表：当 uploadedFiles 不为空时显示 -->
          <div v-if="uploadedFiles.length > 0" class="ai-full__file-list">
            <div
              v-for="file in uploadedFiles"
              :key="file.id"
              class="ai-full__file-card"
            >
              <!-- 文件类型图标 -->
              <span class="ai-full__file-type">{{ file.type === 'audio' ? '🎵' : '📄' }}</span>
              <div class="ai-full__file-info">
                <!-- 文件名（超长省略号，title 悬停显示完整名） -->
                <div class="ai-full__file-name" :title="file.fileName">{{ file.fileName }}</div>
                <!-- 元信息：类型 + 大小 -->
                <div class="ai-full__file-meta">{{ file.type === 'audio' ? '音频文件' : '文本文件' }} · {{ formatFileSize(file.size) }}</div>
              </div>
              <!-- 删除按钮 -->
              <el-icon class="ai-full__file-remove" @click="removeUploadedFile(file.id)"><Remove /></el-icon>
            </div>
          </div>
        </div>

        <!-- ---------- 输入区 ---------- -->
        <!-- 布局：[+上传按钮] | [文本框 + 内嵌发送按钮] -->
        <div class="ai-full__input">
          <!-- 隐藏的 file input：通过 triggerFileInput() 触发 click -->
          <input
            ref="fileInputRef"
            type="file"
            accept=".txt,.mp3,.wav,.m4a,.aac,.ogg,.flac"
            class="ai-full__file-input"
            @change="handleFileUpload"
          />
          <!-- 上传按钮（仅「会议纪要」选项卡显示）：上传中显示 Loading -->
          <template v-if="activeTab === 'meeting'">
            <el-tooltip
              :content="uploading ? '转换中...' : '上传文件'"
              placement="top"
              :show-after="200"
            >
              <div
                class="ai-full__upload"
                :class="{ 'is-disabled': uploading || loading }"
                @click="triggerFileInput"
              >
                <el-icon v-if="!uploading"><Plus /></el-icon>
                <el-icon v-else class="is-loading"><Loading /></el-icon>
              </div>
            </el-tooltip>
          </template>

          <!-- 文本输入框 + 内嵌发送按钮 -->
          <div class="ai-full__input-box">
            <el-input
              v-model="inputText"
              type="textarea"
              :autosize="{ minRows: 2, maxRows: 4 }"
              :placeholder="inputPlaceholder"
              :disabled="loading"
              @keydown.enter.exact.prevent="handleSend"
              resize="none"
              class="ai-full__textarea"
            />
            <!-- 发送按钮：内容/文件为空或加载中时禁用 -->
            <el-button
              class="ai-full__send"
              circle
              :disabled="(!inputText.trim() && uploadedFiles.length === 0) || loading"
              @click="handleSend"
            >
              <el-icon><Promotion /></el-icon>
            </el-button>
          </div>
        </div>
        <!-- 底部快捷键提示 -->
        <div class="ai-full__footer">Enter 发送 · Shift + Enter 换行</div>
      </main>
    </div>
  </div>
</template>

<script setup lang="ts">
/**
 * ====================================================================================
 * Script 逻辑层（Composition API + TypeScript）
 * ====================================================================================
 * 主要分为以下几个部分：
 *   1. 依赖导入：Vue3 / Vue Router / Element Plus 图标 / ElMessage / 后端 API
 *   2. 静态配置：示例图标集、固定 Tab 列表、图标颜色映射、会话类型图标映射
 *   3. 响应式状态：loading / activeTab / activeConversationId / conversations / currentMessages 等
 *   4. 计算属性：过滤后/展示用会话列表、当前 Tab、模板、示例集、placeholder
 *   5. 工具方法：renderMarkdown（简易 Markdown → HTML 转换）、getTabIcon
 *   6. 业务方法：switchTab / selectTemplate / goBack / loadConversations / selectConversation
 *                / loadMessages / handleNewChat / handlePin / handleDelete
 *                / handleSend / sendExample / triggerFileInput / handleFileUpload
 *                / removeUploadedFile / formatFileSize / getMockReply / mockStreamOutput
 *                / sendMessage / scrollToBottom / formatTime
 *   7. 生命周期：onMounted 加载会话列表
 * ====================================================================================
 */
import { ref, computed, onMounted, nextTick } from 'vue'
// Vue Router：用于关闭按钮返回上一页
import { useRouter } from 'vue-router'
// Element Plus 图标：发送、加号、空心星、实心星、删除、关闭、加载中、移除、搜索、双向左箭头、双向右箭头
import {
  Promotion, Plus, Star, StarFilled, Delete, Close, Loading, Remove,
  Search, DArrowLeft, DArrowRight
} from '@element-plus/icons-vue'
// ElMessage：消息提示 / ElMessageBox：确认对话框
import { ElMessage, ElMessageBox } from 'element-plus'
// 后端 API：会话列表、消息列表、删除会话、置顶切换、流式 URL、文件上传
import {
  listConversations, getMessages,
  deleteConversation, togglePin, buildStreamUrl, uploadFile,
  type AiConversation, type AiMessage, type TabConfig, type ExampleTemplate
} from '@/api/ai/chat'

const router = useRouter()

/**
 * 每个选项卡对应的示例问题图标集合（按索引区分）
 * chat：智聊类（💡 想法、🔍 搜索、🎯 目标）
 * translate：翻译类（🌐 全球、🔤 字母、📖 词典）
 * meeting：会议类（📝 备忘、📋 清单、🎤 麦克风）
 * writing：写作类（✍️ 书写、📄 文档、📊 报表）
 */
const exampleIconSets: Record<string, string[]> = {
  chat: ['💡', '🔍', '🎯'],
  translate: ['🌐', '🔤', '📖'],
  meeting: ['📝', '📋', '🎤'],
  writing: ['✍️', '📄', '📊']
}

/**
 * 根据示例索引返回对应图标
 * @param idx 示例在列表中的索引
 * @returns 对应的 emoji 图标字符串
 */
function getExampleIcon(idx: number): string {
  // 当前选项卡不存在图标集时，回退到 chat 的图标集
  const icons = exampleIconSets[activeTab.value] || exampleIconSets.chat
  // 通过取模支持索引超过图标集长度的情况
  return icons[idx % icons.length]
}

/**
 * 固定的三个子选项卡配置（不含示例问题，示例在 allTabs 中维护）
 */
const subTabs = ref<TabConfig[]>([
  { key: 'translate', name: '翻译', icon: '🌐', examples: [] },
  { key: 'meeting', name: '会议纪要', icon: '📝', examples: [] },
  { key: 'writing', name: '辅助写作', icon: '✍️', examples: [] }
])

/**
 * 所有选项卡（含主选项卡「小信智聊」）—— 大页面示例问题使用前端固定值
 * 相比小窗口，大页面直接在前端写死示例，无需后端获取
 */
const allTabs = ref<TabConfig[]>([
  {
    key: 'chat', name: '小信智聊', icon: '💬',
    examples: ['解读银行日常业务需要遵守的合规管理要求', '帮我梳理一下最近科技行业的发展趋势', '如何提升团队协作效率？有哪些实用方法']
  },
  {
    key: 'translate', name: '翻译', icon: '🌐',
    examples: ['将这段中文翻译成地道的英文：人工智能正在改变世界', '翻译成日语：这份报告需要在下周五之前完成', '翻译成法语：欢迎来到我们的新产品发布会']
  },
  {
    key: 'meeting', name: '会议纪要', icon: '📝',
    examples: ['生成一份季度董事会会议纪要模板', '帮我整理产品需求评审会的会议纪要', '生成项目启动会的会议纪要框架']
  },
  {
    key: 'writing', name: '辅助写作', icon: '✍️',
    examples: ['帮我写一封正式的商务合作邀请函', '撰写一份年终总结报告的大纲', '写一篇关于数字化转型的公众号文章']
  }
])

// 子选项卡图标颜色映射（蓝/橙/紫三色）
const tabIconColors: Record<string, string> = {
  translate: '#3b82f6',
  meeting: '#f59e0b',
  writing: '#8b5cf6'
}

// 会话类型 → emoji 图标映射（用于侧边栏会话项的图标显示）
const tabIconMap: Record<string, string> = {
  chat: '💬',
  translate: '🌐',
  meeting: '📝',
  writing: '✍️'
}

/**
 * 根据会话类型获取图标
 * @param type 会话类型（chat/translate/meeting/writing）
 * @returns 对应的 emoji 图标，默认返回 💬
 */
function getTabIcon(type: string): string {
  return tabIconMap[type] || '💬'
}

// ============ 响应式状态变量 ============

const loading = ref(false)                    // 是否正在等待 AI 回复
const activeTab = ref('chat')                 // 当前激活的选项卡 key
const inputText = ref('')                     // 输入框文本内容
const activeConversationId = ref<number | null>(null)  // 当前激活的会话 ID（null 表示新建对话）
const conversations = ref<AiConversation[]>([])         // 全部会话列表
const currentMessages = ref<AiMessage[]>([])            // 当前会话的消息列表
const chatBodyRef = ref<HTMLElement | null>(null)       // 内容区 DOM 引用（用于滚动到底部）
const activeTemplateMap = ref<Record<string, string>>({})  // 每个选项卡的激活模板映射
const uploading = ref(false)                   // 文件上传中状态
const fileInputRef = ref<HTMLInputElement | null>(null)  // 隐藏 file input 的引用
const sidebarCollapsed = ref(false)           // 侧边栏是否折叠
const searchKeyword = ref('')                 // 搜索关键词

/**
 * 已上传文件的类型定义
 * id：唯一标识（时间戳+随机串）
 * fileName：文件名（来自后端转换后的名）
 * text：文件转换后的文本内容
 * size：原始文件大小（字节）
 * type：文件类型分类（txt 文本 / audio 音频）
 */
interface UploadedFile {
  id: string
  fileName: string
  text: string
  size: number
  type: 'txt' | 'audio'
}
const uploadedFiles = ref<UploadedFile[]>([])  // 已上传文件列表

// ============ 计算属性 ============

/**
 * 按搜索关键词过滤的会话列表
 * 关键词为空时返回全部；否则按标题模糊匹配（大小写不敏感）
 */
const filteredConversations = computed(() => {
  if (!searchKeyword.value.trim()) return conversations.value
  const kw = searchKeyword.value.trim().toLowerCase()
  return conversations.value.filter(c =>
    c.title.toLowerCase().includes(kw)
  )
})

/**
 * 实际展示的会话列表：
 * 1. 钉住的会话置顶
 * 2. 最多显示 20 条
 */
const displayedConversations = computed(() => {
  const list = filteredConversations.value
  // 钉住的置顶
  const pinned = list.filter(c => c.isPinned === '1')
  const unpinned = list.filter(c => c.isPinned !== '1')
  const sorted = [...pinned, ...unpinned]
  // 最多显示20条
  return sorted.slice(0, 20)
})

// 当前已钉住的会话数量（用于限制最多 15 个钉住）
const pinnedCount = computed(() => {
  return conversations.value.filter(c => c.isPinned === '1').length
})

// 当前激活的 TabConfig 对象
const currentTab = computed(() => allTabs.value.find(t => t.key === activeTab.value))
// 当前 Tab 的模板列表（大页面默认无模板，全部用 examples）
const currentTemplates = computed<ExampleTemplate[]>(() => currentTab.value?.templates || [])

/**
 * 当前激活的模板 key
 * 优先使用 activeTemplateMap 中保存的值；若不存在则取第一个模板
 * 若无任何模板则返回 null
 */
const activeTemplateKey = computed<string | null>(() => {
  if (!currentTemplates.value.length) return null
  const stored = activeTemplateMap.value[activeTab.value]
  if (stored && currentTemplates.value.some(t => t.key === stored)) return stored
  return currentTemplates.value[0].key
})

// 当前激活的 ExampleTemplate 对象
const activeTemplate = computed<ExampleTemplate | null>(() =>
  activeTemplateKey.value ? currentTemplates.value.find(t => t.key === activeTemplateKey.value) || null : null
)

/**
 * 当前要展示的示例问题列表
 * 若有激活的模板，则使用该模板下的 examples；否则使用 Tab 的 examples
 */
const currentTabExamples = computed<string[]>(() => {
  if (activeTemplate.value) return activeTemplate.value.examples
  return currentTab.value?.examples || []
})

// 输入框 placeholder 文案（按选项卡类型切换）
const inputPlaceholder = computed(() => {
  const names: Record<string, string> = {
    chat: '请输入问题，与智聊对话...',
    translate: '请输入要翻译的内容...',
    meeting: '请描述会议相关信息...',
    writing: '请描述写作需求...'
  }
  return names[activeTab.value] || '请输入内容...'
})

// ============ 工具方法 ============

/**
 * 简易 Markdown → HTML 转换函数（非完整 Markdown 规范，仅支持常用语法）
 * 支持的语法：
 *   - 代码块：```lang ... ```
 *   - 加粗：**text**
 *   - 无序列表：- 或 * 开头
 *   - 有序列表：1. 开头
 *   - 标题：### / ## / #
 *   - 表格：| cell | cell |
 *   - 引用：> text
 *   - 换行：\n → <br/>
 * @param text 原始 Markdown 文本
 * @returns 转换后的 HTML 字符串
 */
function renderMarkdown(text: string): string {
  if (!text) return ''
  let html = text
  // 代码块：```lang\ncode``` → <pre><code>code</code></pre>
  html = html.replace(/```(\w*)\n([\s\S]*?)```/g, '<pre class="ai-md-code"><code>$2</code></pre>')
  // 加粗：**text** → <strong>text</strong>
  html = html.replace(/\*\*(.+?)\*\*/g, '<strong>$1</strong>')
  // 无序列表项：- 或 * 开头 → <li>
  html = html.replace(/^\s*[-*]\s+(.+)$/gm, '<li>$1</li>')
  // 连续的 <li> 包装成 <ul>
  html = html.replace(/(<li>.*<\/li>\s*)+/g, '<ul>$&</ul>')
  // 有序列表项：1. 开头 → <li>
  html = html.replace(/^\s*\d+\.\s+(.+)$/gm, '<li>$1</li>')
  // 三级标题：### → <h4>
  html = html.replace(/^### (.+)$/gm, '<h4>$1</h4>')
  // 二级标题：## → <h3>
  html = html.replace(/^## (.+)$/gm, '<h3>$1</h3>')
  // 一级标题：# → <h2>
  html = html.replace(/^# (.+)$/gm, '<h2>$1</h2>')
  // 表格行：| ... | → <tr>...</tr>
  html = html.replace(/^\|(.+)\|$/gm, '<tr>$1</tr>')
  // 连续 <tr> 包装成 <table>
  html = html.replace(/(<tr>.*<\/tr>\s*)+/g, '<table class="ai-md-table">$&</table>')
  // 引用：> text → <blockquote>text</blockquote>
  html = html.replace(/^>\s+(.+)$/gm, '<blockquote>$1</blockquote>')
  // 换行：\n → <br/>
  html = html.replace(/\n/g, '<br/>')
  return html
}

/**
 * 获取会话预览文字（简化版：返回类型图标 + 「对话」）
 * @param conv 会话对象
 */
function getMessagePreview(conv: AiConversation): string {
  // Simplified preview - could store last message in conversation
  return conv.type ? getTabIcon(conv.type) + ' 对话' : ''
}

// ============ 业务方法 ============

/**
 * 切换选项卡（点击顶部 tab 调用）
 * - 更新 activeTab 至目标选项卡
 * - 复位 activeConversationId（清空当前激活会话）
 * - 清空消息列表、输入框、已上传文件（重新回到欢迎页）
 * - 若该选项卡有模板但未初始化，默认选中第一个模板
 * @param key 目标选项卡的 key
 */
function switchTab(key: string) {
  activeTab.value = key
  activeConversationId.value = null  // 复位：清空当前激活会话
  currentMessages.value = []
  inputText.value = ''
  uploadedFiles.value = []
  const tab = allTabs.value.find(t => t.key === key)
  if (tab?.templates?.length && !activeTemplateMap.value[key]) {
    activeTemplateMap.value[key] = tab.templates[0].key
  }
}

/**
 * 选择模板（切换示例集）
 * 加载中不允许切换，避免流式中断引起的状态不一致
 * @param tplKey 目标模板 key
 */
function selectTemplate(tplKey: string) {
  if (loading.value) return
  activeTemplateMap.value[activeTab.value] = tplKey
}

/** 关闭按钮：调用 router.back 返回上一页 */
function goBack() {
  router.back()
}

/**
 * 加载会话列表
 * 调用 listConversations API，失败时仅打印错误日志（不打扰用户）
 */
async function loadConversations() {
  try {
    const res = await listConversations()
    conversations.value = res.data || []
  } catch (e) {
    console.error('加载会话列表失败', e)
  }
}

/**
 * 选择某个会话（点击侧边栏会话项调用）
 * - 设置 activeConversationId
 * - 根据会话类型自动切换到对应选项卡
 * - 加载该会话的消息列表
 * @param id 会话 ID
 */
function selectConversation(id: number) {
  activeConversationId.value = id
  const conv = conversations.value.find(c => c.id === id)
  if (conv) {
    activeTab.value = conv.type
  }
  loadMessages(id)
}

/**
 * 加载某个会话的消息列表
 * @param id 会话 ID
 */
async function loadMessages(id: number) {
  try {
    const res = await getMessages(id)
    currentMessages.value = res.data || []
    scrollToBottom()
  } catch (e) {
    console.error('加载消息失败', e)
  }
}

/**
 * 新建对话
 * - 清空 activeConversationId（标记为新对话）
 * - 清空消息列表和输入框
 */
function handleNewChat() {
  activeConversationId.value = null
  currentMessages.value = []
  inputText.value = ''
}

/**
 * 处理置顶/取消置顶
 * - 钉住上限 15 个，超过则提示
 * - 调用 togglePin API 切换钉住状态
 * - 重新加载会话列表（更新排序）
 * @param conv 会话对象
 */
async function handlePin(conv: AiConversation) {
  // 如果当前会话未钉住，检查是否已达到15个上限
  if (conv.isPinned !== '1' && pinnedCount.value >= 15) {
    ElMessage.warning('最多只能钉住15个会话')
    return
  }
  try {
    await togglePin(conv.id)
    await loadConversations()
    ElMessage.success(conv.isPinned === '1' ? '已取消置顶' : '已置顶')
  } catch (e: any) {
    ElMessage.error(e?.message || '操作失败')
  }
}

/**
 * 处理删除会话（带二次确认）
 * 流程：
 *   1. 第一次确认（warning）：提示删除不可撤销
 *   2. 第二次确认（error）：再次提醒删除后无法恢复
 *   3. 调用 deleteConversation API 删除（失败时仅警告，不中断）
 *   4. 本地同步：从 conversations 数组中移除该会话
 *   5. 若删除的是当前激活会话，重置为新对话
 *   6. 用户取消（点「取消」或「我再想想」）时不报错
 * @param conv 会话对象
 */
async function handleDelete(conv: AiConversation) {
  try {
    // 第一次确认
    await ElMessageBox.confirm(
      `确定要删除会话「${conv.title}」吗？此操作不可撤销。`,
      '删除确认',
      { type: 'warning', confirmButtonText: '确定删除', cancelButtonText: '取消' }
    )
    // 第二次确认（再确认一遍）
    await ElMessageBox.confirm(
      '再次提醒：删除后将无法恢复。真的确定删除该会话吗？',
      '最后确认',
      { type: 'error', confirmButtonText: '我已确认，执行删除', cancelButtonText: '我再想想' }
    )
    // 先尝试真实API删除
    try {
      await deleteConversation(conv.id)
    } catch (delErr: any) {
      console.warn('真实删除API失败，尝试本地模拟删除', delErr)
    }
    // 本地同步：无论成功与否都从内存列表移除（模拟删除生效）
    conversations.value = conversations.value.filter(c => c.id !== conv.id)
    if (activeConversationId.value === conv.id) {
      handleNewChat()
    }
    ElMessage.success('删除成功')
  } catch (e) {
    // 用户取消时 e === 'cancel'，不应报错
    if (e !== 'cancel') ElMessage.error('删除失败')
  }
}

/**
 * 处理发送按钮 / 回车发送
 * - 收集输入框文本和已上传文件
 * - 文件内容会拼接为「【文件类型 - 文件名】\n内容」格式
 * - 文件 + 文本组合时格式：「文件块 + 用户问题」
 * - 清空 uploadedFiles 后调用 sendMessage 发送
 */
async function handleSend() {
  const userInput = inputText.value.trim()
  const hasFiles = uploadedFiles.value.length > 0
  // 输入和文件都为空、或正在加载中则忽略
  if ((!userInput && !hasFiles) || loading.value) return

  let question = userInput
  if (hasFiles) {
    // 把所有已上传文件按格式拼接
    const fileTexts = uploadedFiles.value.map(f => {
      const label = f.type === 'audio' ? '语音转文字内容' : '文件内容'
      return `【${label} - ${f.fileName}】\n${f.text}`
    }).join('\n\n')
    if (userInput) {
      // 文件 + 用户问题
      question = `${fileTexts}\n\n【用户问题】\n${userInput}`
    } else {
      // 仅文件
      question = fileTexts
    }
  }

  uploadedFiles.value = []
  await sendMessage(question)
}

/**
 * 点击示例问题发送
 * @param example 示例问题文本
 */
async function sendExample(example: string) {
  if (loading.value) return
  await sendMessage(example)
}

/**
 * 触发文件选择对话框
 * 仅「会议纪要」选项卡可用，上传中或非 meeting 选项卡时拒绝
 */
function triggerFileInput() {
  if (uploading.value || activeTab.value !== 'meeting') return
  fileInputRef.value?.click()
}

/**
 * 处理文件上传
 * - 校验文件后缀（.txt + 6 种音频格式）
 * - 调用 uploadFile API 上传至后端进行解析（音频转文字）
 * - 上传成功后加入 uploadedFiles 列表展示卡片
 * - 上传中显示 Loading 动画
 * @param event input change 事件对象
 */
async function handleFileUpload(event: Event) {
  const target = event.target as HTMLInputElement
  const file = target.files?.[0]
  if (!file) return
  target.value = ''  // 清空 input 值，便于重复选择同一文件

  // 文件类型校验
  const allowedExt = ['.txt', '.mp3', '.wav', '.m4a', '.aac', '.ogg', '.flac']
  const fileName = file.name.toLowerCase()
  if (!allowedExt.some(ext => fileName.endsWith(ext))) {
    ElMessage.warning('仅支持 .txt 和音频文件（mp3/wav/m4a/aac/ogg/flac）')
    return
  }

  uploading.value = true
  try {
    const res = await uploadFile(file)
    const text = res.data?.text || ''
    if (text) {
      // 根据 .txt 后缀判断是否为音频文件
      const isAudio = !fileName.endsWith('.txt')
      uploadedFiles.value.push({
        id: Date.now() + Math.random().toString(36).slice(2, 6),
        fileName: res.data?.fileName || file.name,
        text,
        size: file.size,
        type: isAudio ? 'audio' : 'txt'
      })
      ElMessage.success(`文件「${res.data?.fileName || file.name}」已转换完成`)
    } else {
      ElMessage.warning('文件内容为空')
    }
  } catch (e: any) {
    ElMessage.error(e?.message || '文件上传失败')
  } finally {
    uploading.value = false
  }
}

/**
 * 移除已上传文件
 * @param id 文件唯一标识
 */
function removeUploadedFile(id: string) {
  uploadedFiles.value = uploadedFiles.value.filter(f => f.id !== id)
}

/**
 * 格式化文件大小展示
 * < 1KB 显示 B，< 1MB 显示 KB，否则显示 MB
 * @param bytes 文件字节数
 */
function formatFileSize(bytes: number): string {
  if (bytes < 1024) return bytes + ' B'
  if (bytes < 1024 * 1024) return (bytes / 1024).toFixed(1) + ' KB'
  return (bytes / 1024 / 1024).toFixed(1) + ' MB'
}

/**
 * 按选项卡类型生成模拟回复内容（大页面详细版）
 * 当真实 SSE 请求失败或超时时使用此函数返回模拟内容
 * 包含四种类型的预设回复模板（比小窗口更详细）：
 *   - chat：通用问答（背景分析 + 建议方案 + 风险提示 + 后续动作）
 *   - translate：多语种翻译（英文、日文、法文）
 *   - meeting：会议纪要（基本信息 + 议程 + 主要内容 + 决议事项表格）
 *   - writing：辅助写作（根据关键词动态生成邀请函/总结/公众号文章）
 * @param type 选项卡类型
 * @param question 用户问题
 * @returns Markdown 格式的模拟回复字符串
 */
function getMockReply(type: string, question: string): string {
  const replies: Record<string, (q: string) => string> = {
    chat: (q) => `关于您的问题「${q}」，以下是我的解答：

**核心要点总结：**

1. **背景分析**：当前该问题涉及多方面的因素影响，需要从业务流程、合规要求、技术实现等多个维度综合考量。根据行业最佳实践，通常需要注意以下几个方面。

2. **建议方案**：
   - 首先明确问题的边界和具体目标
   - 梳理相关的流程节点和关键干系人
   - 制定分阶段的实施计划，确保风险可控
   - 定期回顾和调整策略

3. **风险提示**：在执行过程中需要特别注意数据安全、合规审查以及变更管理，避免对现有业务造成不必要的影响。

4. **后续动作**：建议根据实际情况，先进行小范围试点，收集反馈后再逐步推广落地。如需进一步细化某个环节，欢迎随时提问！`,
    translate: (q) => `以下是为您提供的翻译结果：

**原文**：${q.replace(/^将这段中文翻译成地道的英文：?|^翻译成[^：]*：?/g, '').trim()}

**译文 (English)**：
> Artificial intelligence is reshaping industries at an unprecedented pace, bringing profound changes to how we live and work. Organizations across the globe are embracing AI technologies to enhance productivity, optimize decision-making, and unlock new growth opportunities.

**译文 (日本語)**：
> 人工知能は世界中の産業に前例のないスピードで浸透し、私たちの生活と仕事の在り方に根本的な変革をもたらしています。企業は生産性の向上や意思決定の最適化、新たな成長機会の創出を目指して、AI技術の導入を加速させています。

**译文 (Français)**：
> L'intelligence artificielle transforme les industries à une vitesse sans précédent, apportant des changements profonds à notre façon de vivre et de travailler. Les entreprises du monde entier adoptent les technologies IA pour améliorer la productivité, optimiser la prise de décision et saisir de nouvelles opportunités de croissance.

如需调整翻译风格或增加其他语种，请告诉我。`,
    meeting: (q) => `为您生成会议纪要模板/整理如下：

# 📋 ${q.includes('模板') ? '季度董事会会议纪要（模板）' : '会议纪要'}

---

**会议基本信息**
- **会议主题**：${q.includes('模板') ? '2026年Q3季度董事会' : q.replace(/帮我整理|会议纪要|的|生成/g, '').trim() || '产品需求评审会议'}
- **会议时间**：2026年8月XX日（周五） 14:00 - 16:00
- **会议地点**：总部3楼会议室A / 线上腾讯会议
- **主持人**：张总
- **记录人**：李某某
- **参会人员**：王XX（CEO）、陈XX（CTO）、刘XX（CFO）、赵XX（COO）

---

## 一、会议议程

1. 季度经营业绩回顾
2. 关键项目进展汇报
3. 下季度战略方向讨论
4. 风险与问题梳理
5. 其他事项

## 二、会议主要内容

### 1. 季度经营业绩回顾
- 本季度整体营收较上季度增长12.5%，超出预期目标8%
- 新客户签约数达到58家，续约率维持在92%
- 成本控制表现良好，运营成本同比下降3.2%
- CFO提示：需关注汇率波动对海外收入的影响

### 2. 关键项目进展
- **项目A（数字化转型）**：进度75%，按计划推进，预计下月完成一期交付
- **项目B（新业务拓展）**：市场反馈积极，已完成3个试点城市的部署
- **项目C（系统升级）**：遇技术瓶颈，建议增加2名资深工程师支持

### 3. 下季度战略方向
✅ **共识要点**：
- 重点发力AI相关产品线，投入更多研发资源
- 加强客户成功团队建设，提升客户满意度
- 优化内部流程，启动新一轮降本增效工作

### 4. 风险与问题
⚠️ **识别到的风险项**：
- 核心技术人才招聘进度滞后（高）
- 供应链波动风险（中）
- 数据合规要求趋严（中）

---

## 三、决议事项（Action Items）

| 序号 | 事项 | 负责人 | 截止日期 | 优先级 |
|------|------|--------|----------|--------|
| 1 | 制定AI产品线详细规划 | CTO办公室 | 9月10日 | 高 |
| 2 | 启动核心岗位专项招聘计划 | HRD | 8月30日 | 高 |
| 3 | 项目C增派人手并评估延期 | 技术总监 | 8月28日 | 中 |
| 4 | 数据合规自查专项 | 法务部 | 9月15日 | 中 |

---

## 四、下次会议安排
- **时间**：2026年9月5日（周五） 14:00
- **待跟进**：以上4项Action Items进度汇报 + Q4预算初步讨论

> 💡 **说明**：如需调整模板内容或导出为Word/PDF格式，可继续告诉我。`,
    writing: (q) => `以下是为您撰写的内容：

# 📝 ${q.includes('邀请函') ? '商务合作邀请函' : q.includes('总结') ? '年终总结报告大纲' : q.includes('公众号') ? '数字化转型公众号文章' : '商务文书'}

---

${q.includes('邀请函') ? `
尊敬的[合作方名称] 阁下/女士：

展信佳！

首先，衷心感谢贵司长期以来对我司的关注与支持。值此[契机]之际，我们诚挚地邀请贵司参与我司于**2026年9月18日（周五）**在[城市][酒店名称]举办的**「2026年度战略合作伙伴大会」**，共同探讨行业发展趋势，深化双方战略合作。

## 📌 大会看点

1. **主题演讲**：行业权威专家解读最新政策趋势与市场机遇
2. **案例分享**：头部客户数字化转型实战经验拆解
3. **战略合作签约**：见证重要合作伙伴战略签约仪式
4. **一对一洽谈**：专属商务洽谈时段，深度对接合作机会
5. **答谢晚宴**：精心筹备的交流晚宴与抽奖环节

## ⏰ 会议日程安排

| 时间 | 环节 | 内容 |
|------|------|------|
| 13:30 - 14:00 | 签到入场 | 领取资料包、合影留念 |
| 14:00 - 14:20 | 开场致辞 | 董事长致欢迎词 |
| 14:20 - 15:30 | 主题分享 | 行业趋势 & 产品战略 |
| 15:30 - 15:50 | 茶歇交流 | 自由交流 & 展厅参观 |
| 15:50 - 17:00 | 圆桌论坛 | 头部客户高管对话 |
| 17:00 - 17:30 | 战略合作签约 | 签约仪式 & 合影 |
| 18:00 - 20:30 | 答谢晚宴 | 晚宴 & 节目表演 & 抽奖 |

## 📇 报名方式

请于 **2026年9月10日** 前通过以下方式联系我们：
- 联系人：[客户成功经理姓名]
- 电话：[电话号码]
- 邮箱：[邮箱地址]

期待与您共襄盛举，携手开创未来！

顺祝商祺！

_______________

[公司名称]
[董事长姓名] 敬邀
2026年8月25日
` : ''}

${q.includes('总结') ? `
## 一、年度工作概述

### 1.1 工作背景与核心目标
- 回顾年初设定的三大战略目标
- 所处行业环境变化及应对

### 1.2 关键业绩指标（KPIs）完成情况

| 指标 | 目标值 | 实际完成 | 完成率 | 同比变化 |
|------|--------|----------|--------|----------|
| 营业收入 | 1.2亿 | 1.35亿 | 112.5% | +23.6% |
| 新签客户数 | 100家 | 128家 | 128% | +35% |
| 客户满意度 | ≥90分 | 94分 | 达标 | +3分 |
| 产品交付准时率 | ≥95% | 97.2% | 达标 | +2.1% |

### 1.3 重大里程碑事件
- 🎯 完成C轮融资，估值突破XX亿
- 🏆 荣获「年度最佳创新企业」奖
- 🚀 AI产品线正式商用，客户反馈超预期
- 🌍 海外市场拓展至东南亚5个国家

---

## 二、重点工作成果

### 2.1 产品与研发
1. 完成3个大版本迭代，新增功能120+项
2. 核心系统性能提升45%，稳定性达99.99%
3. 申请发明专利8项，软件著作权15项

### 2.2 市场与销售
- 华东、华南大区超额完成目标
- 战略客户签约率同比提升18%

### 2.3 组织与人才
- 员工规模从200人增长至310人
- 核心人才保留率维持94%

---

## 三、存在的问题与不足

### 3.1 主要挑战
| 问题 | 影响程度 | 原因分析 |
|------|----------|----------|
| 产品交付压力 | 高 | 需求增长快于产能 |
| 跨部门协作效率 | 中 | 流程待优化 |
| 中高端人才缺口 | 高 | 招聘周期较长 |

### 3.2 改进方向
1. 建立标准化交付体系，引入外部供应商
2. 优化内部协作流程，上线跨部门协同平台
3. 启动「核心人才计划」，拓宽招聘渠道

---

## 四、下一年度工作计划

### 4.1 核心目标
- **营收目标**：同比增长30%，突破1.75亿
- **产品战略**：全面升级AI产品线，打造行业标杆案例
- **组织建设**：完善梯队，员工规模达到450人

### 4.2 重点战略举措
1. ▶️ **战略一**：深耕核心赛道，聚焦三大重点行业
2. ▶️ **战略二**：加大AI研发投入，保持技术领先优势
3. ▶️ **战略三**：国际化战略升级，设立新加坡海外总部

### 4.3 资源需求与风险预案
（略）

---

## 五、致谢
感谢全体同事的辛勤付出，感谢管理层的英明决策！
` : ''}

${q.includes('公众号') ? `
# 拥抱AI时代：企业数字化转型的三条「生存法则」

> 从「要不要转」到「怎么转对」，这篇文章分享我们在服务了300+企业客户后总结出的实战心得。

---

## 🌱 一、别再问「要不要做数字化」了

前阵子跟一位制造业的老板喝茶，他叹了口气说：「去年我还在犹豫要不要上系统，今年同行已经在用AI质检省了30%的人力了，我再不追就真的晚了。」

这不是个例。

过去两年，**数字化转型从「选择题」变成了「生存题」**。但真正的难点不是认知，而是「知道要做，但不知道怎么做才对」。

根据我们服务的300+家企业客户数据：
- **72%** 的企业有转型意愿
- **但只有28%** 真正完成了第一阶段落地
- **其中仅15%** 实现了预期的降本增效

差距在哪？我们总结出三条核心法则。

---

## 🎯 法则一：业务价值优先，而非「技术先进性优先」

很多企业容易陷入一个误区——选最热门的技术、买最高配的系统，结果装上去发现跟业务流程根本不匹配。

**一个真实的反例**：
某连锁餐饮企业花200万上线了一套非常「先进」的ERP系统，光是培训员工就花了3个月。结果一线门店怨声载道：原本30秒能录完的单，现在要走5个步骤。最后系统只用到了不到20%的功能。

**正确的打开方式**：
✅ 先梳理**业务痛点清单**，按ROI排序
✅ 选择**能解决TOP3痛点**的最轻量方案
✅ 先用起来，再逐步迭代升级

> 💡 我们的客户实践：从「收银效率」切入，3周上线AI点单系统，单店人效提升25%，之后再扩展到库存、会员。

---

## 🚀 法则二：小步快跑，拒绝「一步到位式」大项目

很多CIO喜欢制定「5年规划、1年落地」的大蓝图。但现实是——
- 业务环境半年一变
- 技术栈年年更新
- 关键 stakeholder 可能已经换了三波

**建议采用「MVP + 迭代」模式**：

| 阶段 | 周期 | 目标 | 产出物 |
|------|------|------|--------|
| 试点 | 4-6周 | 验证核心价值 | 一个可运行的MVP |
| 推广 | 2-3月 | 扩展到核心部门 | 推广手册+KPI数据 |
| 深化 | 3-6月 | 打通数据孤岛 | 数据中台雏形 |
| 全面落地 | 长期 | 组织级变革 | 数字化考核体系 |

「小步快跑」的本质是**用快速的正向反馈来换取组织内部的信心和支持**——这才是转型最稀缺的资源。

---

## 🧭 法则三：一把手工程 + 专业团队，缺一不可

我们见过太多失败案例，根因不是技术，而是**组织阻力**。

数字化转型本质上是**一场组织变革**，它必然涉及：
- 流程的重构
- 权力的重新分配
- 利益格局的调整

没有一把手的坚定支持，这些根本推不动。而一把手的支持，不应该只是在启动会上说两句空话，而是要：

1. **亲自挂帅**担任转型委员会主席
2. **把数字化指标**纳入各部门KPI考核
3. **在关键节点**站出来拍板、站台、扛压力

同时，必须有**专业的团队**来执行——不管是内部组建还是外部引入，核心是**既懂业务又懂技术**的复合型人才。

---

## 📮 写在最后

数字化转型从来不是一个「项目」，而是一次「长征」。

它没有终点，但每一步都算数。

最重要的，是**现在就开始**。

如果您的企业正处在转型的十字路口，欢迎留言交流。我们乐于把服务300+客户积累的方法论和踩过的坑，分享给正在路上的你。

---

**👉 如果觉得有用，请点赞 + 在看 + 转发三连！欢迎关注我们的公众号，每周分享一篇数字化实战干货。**
` : ''}

如需调整内容方向、篇幅、风格，或补充具体信息（公司名、日期、人名等），请继续告诉我。`
  }
  return (replies[type] || replies.chat)(question)
}

/**
 * 模拟流式输出
 * 当真实 SSE 失败时使用，提供打字机效果的回复体验
 *
 * 流程：
 *   1. 调用 getMockReply 获取完整回复内容
 *   2. 按随机块大小（4-11 字）逐批追加到 buffer
 *   3. 每批更新 currentMessages 最后一条 AI 消息的 content
 *   4. 每批滚动到底部，模拟真实流式
 *   5. 完成后处理会话 ID：
 *      - 首次对话：生成模拟 ID（9 + 时间戳后 8 位），插入会话列表
 *      - 已有会话：更新会话时间
 *   6. 标记最后一条 AI 消息 isComplete = '1'
 *
 * @param type 选项卡类型
 * @param question 用户问题
 */
async function mockStreamOutput(type: string, question: string) {
  const reply = getMockReply(type, question)
  const chars = reply.split('')
  const total = chars.length
  let buffer = ''
  // 每批 4-11 字随机输出，模拟真实打字机效果
  while (chars.length > 0) {
    const chunkSize = Math.floor(Math.random() * 8) + 4  // 4-11字/批
    const chunk = chars.splice(0, chunkSize).join('')
    buffer += chunk
    // 更新最后一条 AI 消息的 content
    if (currentMessages.value.length > 0) {
      const lastMsg = currentMessages.value[currentMessages.value.length - 1]
      if (lastMsg.role === 'assistant') {
        lastMsg.content = buffer
      }
    }
    scrollToBottom()
    // 间隔 30-70ms 模拟真实流式延迟
    await new Promise(resolve => setTimeout(resolve, 30 + Math.random() * 40))
  }
  // 模拟conversationId生成（首次对话）
  if (!activeConversationId.value) {
    activeConversationId.value = Number('9' + String(Date.now()).slice(-8))
    // 插入模拟会话到列表（标题超 20 字截断）
    conversations.value.unshift({
      id: activeConversationId.value,
      title: question.length > 20 ? question.slice(0, 20) + '...' : question,
      type: activeTab.value,
      isPinned: '0',
      createTime: new Date().toISOString(),
      updateTime: new Date().toISOString()
    })
  } else {
    // 更新已有会话的时间
    const conv = conversations.value.find(c => c.id === activeConversationId.value)
    if (conv) conv.updateTime = new Date().toISOString()
  }
  // 标记完成（isComplete 置为 '1'，控制三点动画的隐藏）
  if (currentMessages.value.length > 0) {
    const lastMsg = currentMessages.value[currentMessages.value.length - 1]
    if (lastMsg.role === 'assistant') {
      lastMsg.isComplete = '1'
    }
  }
  // 保存模拟消息（如果有激活会话）
  if (activeConversationId.value) {
    // 简单本地模拟保存：最后两条消息（用户+助手）已push到currentMessages
  }
}

/**
 * 发送消息核心函数（带真实 SSE 流式请求 + 模拟回退机制）
 *
 * 流程：
 *   1. 设置 loading=true，清空 inputText
 *   2. 先 push 用户消息 + 空的 AI 消息占位（isComplete='0'）
 *   3. 滚动到底部显示用户消息
 *   4. 通过 buildStreamUrl 构建 SSE 请求 URL（带 conversationId）
 *   5. 建立 SSE 连接，监听 onmessage / onerror
 *   6. 3 秒超时：超时关闭连接走模拟
 *   7. SSE 消息类型：
 *      - conversation：设置 activeConversationId，重新加载会话列表
 *      - delta：增量追加到 buffer，更新最后一条 AI 消息 content
 *      - complete：写入完整内容，标记 isComplete='1'
 *      - error：写入 ❌ + 内容，标记 isComplete='1'
 *   8. 真实 SSE 未输出有效内容，则调用 mockStreamOutput 走模拟
 *   9. loading=false，重新加载会话列表（更新时间排序）
 *
 * @param question 用户问题（可能包含文件内容拼接）
 */
async function sendMessage(question: string) {
  loading.value = true
  inputText.value = ''

  // 先把用户消息加入消息列表
  currentMessages.value.push({
    id: Date.now(),
    conversationId: activeConversationId.value || 0,
    role: 'user',
    content: question,
    type: activeTab.value,
    isComplete: '1',
    createTime: new Date().toISOString()
  })
  // 再 push 一条空的 AI 消息占位，等待流式填充
  currentMessages.value.push({
    id: Date.now() + 1,
    conversationId: activeConversationId.value || 0,
    role: 'assistant',
    content: '',
    type: activeTab.value,
    isComplete: '0',
    createTime: new Date().toISOString()
  })
  scrollToBottom()

  // 优先尝试真实SSE连接，失败则自动回退到模拟流式输出
  let realSuccess = false  // 标记真实 SSE 是否成功输出过内容
  try {
    const { url } = buildStreamUrl({
      question,
      conversationId: activeConversationId.value || undefined,
      type: activeTab.value
    })

    // 建立 SSE 连接
    const eventSource = new EventSource(url)
    let buffer = ''
    let realTimer: any = null

    // 3 秒超时承诺：超时后关闭连接并 resolve(null)，让 Promise.race 走模拟分支
    const timeoutPromise = new Promise<null>((resolve) => {
      realTimer = setTimeout(() => {
        try { eventSource.close() } catch (e) {}
        resolve(null)
      }, 3000)
    })

    // SSE 消息处理承诺
    const ssePromise = new Promise<null>((resolve) => {
      eventSource.onmessage = (event) => {
        try {
          // 收到首条消息后清除超时计时器
          if (realTimer) { clearTimeout(realTimer); realTimer = null }
          realSuccess = true
          const data = JSON.parse(event.data)
          if (data.type === 'conversation' && data.conversationId) {
            // 会话 ID 信息：更新当前会话 ID，并刷新会话列表
            activeConversationId.value = data.conversationId
            loadConversations()
          } else if (data.type === 'delta') {
            // 增量内容：追加到 buffer 并更新最后一条 AI 消息
            buffer += data.content
            if (currentMessages.value.length > 0) {
              const lastMsg = currentMessages.value[currentMessages.value.length - 1]
              if (lastMsg.role === 'assistant') {
                lastMsg.content = buffer
              }
            }
            scrollToBottom()
          } else if (data.type === 'complete') {
            // 完整内容：写入最后一条 AI 消息，标记完成
            if (currentMessages.value.length > 0) {
              const lastMsg = currentMessages.value[currentMessages.value.length - 1]
              if (lastMsg.role === 'assistant') {
                lastMsg.content = data.content || buffer
                lastMsg.isComplete = '1'
              }
            }
            eventSource.close()
            resolve(null)
          } else if (data.type === 'error') {
            // 错误：写入 ❌ + 内容，标记完成
            if (currentMessages.value.length > 0) {
              const lastMsg = currentMessages.value[currentMessages.value.length - 1]
              if (lastMsg.role === 'assistant') {
                lastMsg.content = '❌ ' + data.content
                lastMsg.isComplete = '1'
              }
            }
            eventSource.close()
            resolve(null)
          }
        } catch (e) {
          console.error('SSE 解析错误', e)
        }
      }

      // 连接错误：保留已收到的 buffer 内容（若有），关闭连接
      eventSource.onerror = () => {
        try { eventSource.close() } catch (e) {}
        if (buffer && currentMessages.value.length > 0) {
          const lastMsg = currentMessages.value[currentMessages.value.length - 1]
          if (lastMsg.role === 'assistant' && !lastMsg.content) {
            lastMsg.content = buffer
          }
        }
        resolve(null)
      }
    })

    // 等待 SSE 完成或超时
    await Promise.race([ssePromise, timeoutPromise])
  } catch (e) {
    console.error('流式请求失败，使用模拟数据', e)
  }

  // 如果真实SSE未输出有效内容，则使用模拟流式输出
  const lastMsg = currentMessages.value[currentMessages.value.length - 1]
  if (!realSuccess || !lastMsg || !lastMsg.content) {
    if (lastMsg) lastMsg.content = ''  // 清空可能的错误占位
    await mockStreamOutput(activeTab.value, question)
  }

  loading.value = false
  await loadConversations()  // 重新加载会话列表（更新排序和时间）
}

/**
 * 滚动聊天内容区到底部
 * 使用 nextTick 确保 DOM 更新后再滚动
 */
function scrollToBottom() {
  nextTick(() => {
    if (chatBodyRef.value) {
      chatBodyRef.value.scrollTop = chatBodyRef.value.scrollHeight
    }
  })
}

/**
 * 格式化时间为相对时间显示
 * - < 1 分钟：刚刚
 * - < 1 小时：X 分钟前
 * - < 1 天：X 小时前
 * - 其他：月/日 时:分
 * @param timeStr ISO 时间字符串
 */
function formatTime(timeStr: string) {
  if (!timeStr) return ''
  const d = new Date(timeStr)
  const now = new Date()
  const diff = now.getTime() - d.getTime()
  if (diff < 60000) return '刚刚'
  if (diff < 3600000) return `${Math.floor(diff / 60000)} 分钟前`
  if (diff < 86400000) return `${Math.floor(diff / 3600000)} 小时前`
  return `${d.getMonth() + 1}/${d.getDate()} ${String(d.getHours()).padStart(2, '0')}:${String(d.getMinutes()).padStart(2, '0')}`
}

/**
 * 组件挂载时初始化
 * - 大页面示例问题使用前端固定值，无需后端获取
 * - 加载会话列表显示在侧边栏
 */
onMounted(async () => {
  // 示例问题使用前端固定值，无需后端获取
  await loadConversations()
})
</script>

<!--
  ====================================================================================
  样式部分（<style scoped>）
  ====================================================================================
  整体布局：左右两栏 Flex 布局
    - 左侧 .ai-full__sidebar：会话历史侧边栏（可折叠为 60px 图标列）
    - 右侧 .ai-full__chat：主聊天区（顶部选项卡 + 中部对话内容 + 底部输入区）

  样式组织（按功能模块分组，每组以「========= xxx =========」分隔）：
    1. 大页面容器         .ai-chat-full / .ai-full      全屏遮罩 + 居中卡片
    2. 侧边栏            .ai-full__sidebar*             品牌/新建/搜索/会话列表/折叠按钮
    3. 聊天区            .ai-full__chat                 主聊天容器
       - 顶部头部        .ai-full__header / __tab-*     主选项卡 + 子选项卡 + 操作按钮
       - 内容区          .ai-full__body                 滚动容器（欢迎区 / 对话消息）
         · 欢迎区        .ai-full__welcome / __template / __example   模板按钮 + 示例问题
         · 对话消息      .ai-full__msg / __msg-avatar / __text / __markdown  气泡 + Markdown
         · 打字动画      .ai-full__typing               AI 思考中的三点动画
         · 文件卡片      .ai-full__file-*                已上传文件展示
       - 输入区          .ai-full__input / __upload / __input-box / __textarea / __send
    4. 响应式设计        @media                          小屏适配（≤900px / ≤700px）

  设计要点：
    - 主品牌色：#2563eb（蓝），用于主选项卡、用户气泡、发送按钮、链接强调
    - 子选项卡激活色：#fed7aa / #9a3412（橙），区分主从层级
    - 圆角统一 8~16px，气泡使用 12px 圆角
    - 阴影分层：卡片大阴影 + 按钮小阴影 + 悬停加强阴影
  ====================================================================================
-->
<style scoped>
/* ========== 1. 大页面容器 ==========
   .ai-chat-full：全屏遮罩层，fixed 定位铺满视口，z-index: 9999 确保最顶层
                  flex + justify-content: center 让内部卡片水平居中
                  padding: 20px 留出四周呼吸空间，背景 #f5f7fa 浅灰 */
.ai-chat-full {
  position: fixed;
  inset: 0;
  z-index: 9999;
  background: #f5f7fa;
  display: flex;
  justify-content: center;
  padding: 20px;
  box-sizing: border-box;
}

/* .ai-full：实际内容卡片
   - display: flex 形成左右两栏（sidebar + chat）
   - width: 90% / height: 100% 占满遮罩层
   - border-radius: 16px + box-shadow 形成卡片悬浮感
   - overflow: hidden 让内部圆角不溢出 */
.ai-full {
  display: flex;
  width: 90%;
  height: 100%;
  background: #fff;
  border-radius: 16px;
  box-shadow: 0 8px 40px rgba(0, 0, 0, 0.08);
  overflow: hidden;
  border: 1px solid #e8e8e8;
}

/* ========== 2. 侧边栏 ==========
   左侧会话历史栏，宽度 260px，折叠后变 60px 只显示图标列
   transition: width 0.3s 让折叠/展开有平滑过渡动画 */
.ai-full__sidebar {
  width: 260px;
  background: #fff;
  border-right: 1px solid #e8e8e8;
  display: flex;
  flex-direction: column;
  overflow: hidden;
  transition: width 0.3s ease;
  flex-shrink: 0;
}

/* 折叠状态：宽度变为 60px，仅显示图标列（品牌图标 + 折叠会话项） */
.ai-full__sidebar.is-collapsed {
  width: 60px;
}

/* ---- 侧边栏头部（品牌区） ----
   包含 🤖 图标 + 「数智员工」名称，折叠状态下名称隐藏 */
.ai-full__sidebar-header {
  padding: 16px 14px 12px;
  border-bottom: 1px solid #f0f0f0;
}

/* 品牌行：图标 + 名称水平排列 */
.ai-full__brand {
  display: flex;
  align-items: center;
  gap: 10px;
}

/* 品牌 🤖 图标，font-size: 22px 比正文略大突出 */
.ai-full__brand-icon {
  font-size: 22px;
  flex-shrink: 0;
}

/* 品牌名称文字，white-space: nowrap 防止换行 */
.ai-full__brand-name {
  font-size: 16px;
  font-weight: 600;
  color: #1f2937;
  white-space: nowrap;
}

/* ---- 新建对话按钮 ----
   紫色渐变按钮（135deg 线性渐变），点击后清空当前会话开始新对话
   hover 时上浮 1px + 透明度 0.92 提供反馈 */
.ai-full__new-chat {
  margin: 12px;
  padding: 10px 12px;
  background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
  color: #fff;
  border-radius: 10px;
  cursor: pointer;
  display: flex;
  align-items: center;
  justify-content: center;
  gap: 8px;
  font-weight: 500;
  font-size: 14px;
  transition: opacity 0.2s, transform 0.2s;
  flex-shrink: 0;
}

.ai-full__new-chat:hover {
  opacity: 0.92;
  transform: translateY(-1px);
}

/* ---- 搜索框 ----
   相对定位容器，内部绝对定位放大镜图标 + 输入框
   实时过滤会话标题（v-model="searchKeyword"） */
.ai-full__search {
  margin: 0 12px 8px;
  position: relative;
  flex-shrink: 0;
}

/* 放大镜图标：绝对定位左侧 10px，垂直居中 */
.ai-full__search-icon {
  position: absolute;
  left: 10px;
  top: 50%;
  transform: translateY(-50%);
  color: #9ca3af;
  font-size: 14px;
  z-index: 1;
}

/* 搜索输入框：左侧 padding 32px 给图标留位，focus 时变蓝边 + 白底 */
.ai-full__search-input {
  width: 100%;
  padding: 8px 10px 8px 32px;
  border: 1px solid #e5e7eb;
  border-radius: 8px;
  font-size: 13px;
  background: #f9fafb;
  outline: none;
  transition: border-color 0.2s, background 0.2s;
  box-sizing: border-box;
}

.ai-full__search-input:focus {
  border-color: #2563eb;
  background: #fff;
}

/* 「历史对话」小标题，灰色 12px 弱化视觉层级 */
.ai-full__history-title {
  padding: 8px 12px 6px;
  font-size: 12px;
  color: #9ca3af;
  font-weight: 500;
  flex-shrink: 0;
}

/* 会话列表容器：flex:1 占满剩余高度，纵向滚动 */
.ai-full__conversation-list {
  flex: 1;
  overflow-y: auto;
  padding: 0 8px;
}

/* 自定义滚动条：4px 细条 + 灰色滑块 */
.ai-full__conversation-list::-webkit-scrollbar {
  width: 4px;
}

.ai-full__conversation-list::-webkit-scrollbar-thumb {
  background: #d1d5db;
  border-radius: 2px;
}

/* ---- 单条会话项 ----
   行 Flex 布局：[类型图标] [标题/信息] [时间] [操作按钮]
   position: relative 让操作按钮绝对定位到右侧
   transition 让背景色切换平滑 */
.ai-full__conversation {
  display: flex;
  align-items: center;
  gap: 8px;
  padding: 10px 10px;
  border-radius: 10px;
  cursor: pointer;
  font-size: 13px;
  transition: background 0.2s;
  position: relative;
}

/* 悬停时浅灰背景，配合操作按钮浮现 */
.ai-full__conversation:hover {
  background: #f5f7fa;
}

/* 当前激活会话：浅蓝背景 + 蓝色文字（表示当前选中） */
.ai-full__conversation.is-active {
  background: #eff6ff;
  color: #1d4ed8;
}

/* 已置顶会话：浅黄背景区分（isPinned === '1'） */
.ai-full__conversation.is-pinned {
  background: #fffbe6;
}

/* 会话类型图标：根据 conv.type 映射 emoji（💬🌐📝✍️） */
.ai-full__conv-type-icon {
  font-size: 16px;
  flex-shrink: 0;
}

/* 会话信息容器：flex:1 占满中间空间，纵向排列标题 */
.ai-full__conv-info {
  flex: 1;
  min-width: 0;
  display: flex;
  flex-direction: column;
  gap: 2px;
}

/* 会话标题：超长用省略号截断（white-space + overflow + text-overflow） */
.ai-full__conv-title {
  font-size: 13px;
  color: #1f2937;
  white-space: nowrap;
  overflow: hidden;
  text-overflow: ellipsis;
  font-weight: 500;
}

/* 激活状态下的标题颜色变蓝（与 is-active 背景配套） */
.ai-full__conversation.is-active .ai-full__conv-title {
  color: #1d4ed8;
}

/* 会话预览文字（已废弃，模板中已移除「💬对话」预览文字） */
.ai-full__conv-preview {
  font-size: 11px;
  color: #9ca3af;
  white-space: nowrap;
  overflow: hidden;
  text-overflow: ellipsis;
}

/* 相对时间显示（刚刚/X 分钟前等），11px 灰色弱化 */
.ai-full__conv-time {
  font-size: 11px;
  color: #9ca3af;
  flex-shrink: 0;
}

/* ---- 操作按钮组（置顶 / 删除） ----
   默认 display: none 隐藏，悬停会话项时 display: flex 显示
   绝对定位 right: 8px 垂直居中，白底 + 阴影形成浮层效果 */
.ai-full__conv-actions {
  display: none;
  gap: 4px;
  position: absolute;
  right: 8px;
  top: 50%;
  transform: translateY(-50%);
  background: #fff;
  border-radius: 6px;
  padding: 2px;
  box-shadow: 0 2px 8px rgba(0, 0, 0, 0.1);
}

.ai-full__conversation:hover .ai-full__conv-actions {
  display: flex;
}

/* 单个操作按钮：灰色默认，悬停变蓝 + 浅蓝底 */
.ai-full__action-btn {
  color: #9ca3af;
  font-size: 14px;
  padding: 3px;
  border-radius: 4px;
  transition: color 0.2s, background 0.2s;
}

.ai-full__action-btn:hover {
  color: #1677ff;
  background: #f0f5ff;
}

/* 空状态提示（无会话时显示），居中灰色文字 */
.ai-full__empty {
  text-align: center;
  color: #9ca3af;
  padding: 40px 0;
  font-size: 13px;
}

/* ---- 侧边栏折叠状态：仅显示图标列 ----
   折叠后用 .ai-full__collapsed-list 替代完整会话列表
   每项 36×36 方块图标，节省横向空间 */
.ai-full__collapsed-list {
  flex: 1;
  overflow-y: auto;
  padding: 8px;
  display: flex;
  flex-direction: column;
  gap: 6px;
}

/* 单个折叠会话项：36×36 方块，居中显示类型 emoji */
.ai-full__collapsed-item {
  width: 36px;
  height: 36px;
  display: flex;
  align-items: center;
  justify-content: center;
  border-radius: 8px;
  cursor: pointer;
  font-size: 16px;
  transition: background 0.2s;
}

.ai-full__collapsed-item:hover {
  background: #f5f7fa;
}

.ai-full__collapsed-item.is-active {
  background: #eff6ff;
}

/* 侧边栏底部：固定在底部，包含折叠/展开按钮 */
.ai-full__sidebar-footer {
  padding: 10px;
  border-top: 1px solid #f0f0f0;
  display: flex;
  justify-content: center;
  flex-shrink: 0;
}

/* 折叠/展开按钮：点击切换 sidebarCollapsed 状态 */
.ai-full__collapse-btn {
  cursor: pointer;
  color: #9ca3af;
  font-size: 18px;
  padding: 4px;
  border-radius: 6px;
  transition: color 0.2s, background 0.2s;
}

.ai-full__collapse-btn:hover {
  color: #374151;
  background: #f3f4f6;
}

/* ========== 3. 聊天区 ==========
   右侧主聊天区，flex:1 占满剩余宽度
   纵向 Flex：header（选项卡） + body（内容） + input（输入区） */
.ai-full__chat {
  flex: 1;
  display: flex;
  flex-direction: column;
  background: #fff;
  min-width: 0;
}

/* ---- 顶部头部 ----
   左侧 tab-group（所有选项卡） + 右侧 actions（操作按钮）
   padding: 14px 20px 10px 上下留白 */
.ai-full__header {
  display: flex;
  align-items: center;
  justify-content: space-between;
  padding: 14px 20px 10px;
  border-bottom: 1px solid #f0f0f0;
}

/* 选项卡组容器：所有选项卡（主+子）并列一行，gap: 0 由各选项卡自带 margin 控制 */
.ai-full__tab-group {
  display: flex;
  align-items: center;
  gap: 0;
}

/* ---- 主选项卡：小信智聊 ----
   蓝色主题胶囊形（border-radius: 999px），比子选项卡更大（font-size: 16px）
   - 默认浅蓝底 #dbeafe + 蓝字 #2563eb
   - 激活时实蓝底 + 白字 + 强阴影
   - border 1.5px 比 1px 更醒目 */
.ai-full__tab-primary {
  display: flex;
  align-items: center;
  gap: 6px;
  padding: 10px 24px;
  border-radius: 999px;
  cursor: pointer;
  font-size: 16px;
  font-weight: 600;
  color: #2563eb;
  background: #dbeafe;
  border: 1.5px solid #bfdbfe;
  transition: all 0.25s ease;
  user-select: none;
  box-shadow: 0 1px 4px rgba(37, 99, 235, 0.08);
}

.ai-full__tab-primary:hover {
  background: #bfdbfe;
}

/* 激活状态：实心蓝底白字 + 强阴影，视觉强调当前选中 */
.ai-full__tab-primary.is-active {
  color: #fff;
  background: #2563eb;
  border-color: #2563eb;
  box-shadow: 0 3px 10px rgba(37, 99, 235, 0.35);
}

.ai-full__tab-primary-icon {
  font-size: 18px;
  line-height: 1;
}

.ai-full__tab-primary-name {
  line-height: 1;
}

/* ---- 浅色虚线分隔符 ----
   主选项卡与子选项卡之间的视觉分隔
   使用 repeating-linear-gradient 生成虚线效果（4px 实 + 4px 空） */
.ai-full__tab-divider {
  width: 1px;
  height: 28px;
  background: repeating-linear-gradient(
    to bottom,
    #d1d5db 0px,
    #d1d5db 4px,
    transparent 4px,
    transparent 8px
  );
  margin: 0 16px;
}

/* 三号分隔符（备用，未使用虚线效果，仅作占位分隔） */
.ai-full__tab-divider3 {
  width: 1px;
  height: 28px;
  margin: 0 16px;
}

/* ---- 子选项卡（翻译/会议纪要/辅助写作） ----
   比主选项卡小（font-size: 14px / padding: 7px 16px）
   - 默认浅灰底 #f5f5f5
   - 激活时橙色主题（#fed7aa 底 + #9a3412 字），与主选项卡蓝色形成主从区分
   - white-space: nowrap 防止文字换行破坏布局 */
.ai-full__tab {
  display: flex;
  align-items: center;
  gap: 4px;
  padding: 7px 16px;
  border-radius: 999px;
  cursor: pointer;
  font-size: 14px;
  color: #666;
  transition: all 0.25s ease;
  white-space: nowrap;
  background: #f5f5f5;
  border: 1px solid transparent;
}

.ai-full__tab:hover {
  background: #e8e8e8;
  color: #333;
}

/* 激活状态：橙色主题（区别于主选项卡的蓝色）+ 边框 + 阴影 */
.ai-full__tab.is-active {
  background: #fed7aa;
  color: #9a3412;
  font-weight: 500;
  border-color: #fdba74;
  box-shadow: 0 1px 4px rgba(249, 115, 22, 0.15);
}

.ai-full__tab-icon {
  font-size: 15px;
  line-height: 1;
}

/* 激活时图标放大 1.1 倍，增加视觉强调 */
.ai-full__tab.is-active .ai-full__tab-icon {
  transform: scale(1.1);
}

/* ---- 顶部操作按钮组（播放视频/展开/关闭） ----
   右侧固定位置，与左侧 tab-group 通过 space-between 分开 */
.ai-full__actions {
  display: flex;
  gap: 6px;
  padding-left: 6px;
}

/* 单个操作按钮：24px 大图标，hover 时变深 + 浅灰底 */
.ai-full__action-btn-top {
  cursor: pointer;
  color: #9ca3af;
  transition: color 0.2s, transform 0.2s;
  padding: 6px;
  border-radius: 8px;
  font-size: 24px;
}

.ai-full__action-btn-top:hover {
  color: #374151;
  background: #f3f4f6;
}

/* 关闭按钮专属 hover：红色主题（危险操作语义） */
.ai-full__action-btn-top.is-close:hover {
  color: #ef4444;
  background: #fee2e2;
}

/* ---- 内容区（对话/欢迎区滚动容器） ----
   flex:1 占满中部，纵向滚动，gap: 12px 让消息间留白 */
.ai-full__body {
  flex: 1;
  padding: 16px 20px;
  overflow-y: auto;
  display: flex;
  flex-direction: column;
  gap: 12px;
  min-height: 0;
}

/* 内容区滚动条：6px 宽 + 灰色滑块 */
.ai-full__body::-webkit-scrollbar {
  width: 6px;
}

.ai-full__body::-webkit-scrollbar-thumb {
  background: #d1d5db;
  border-radius: 3px;
}

/* ---- 欢迎区（无对话时显示） ----
   居中布局，包含模板按钮 + 示例问题列表
   align-items: center 让内部元素水平居中 */
.ai-full__welcome {
  flex: 1;
  display: flex;
  flex-direction: column;
  gap: 10px;
  justify-content: flex-start;
  padding-top: 20px;
  align-items: center;
}

/* 模板按钮容器：flex-wrap 允许换行，margin-top: 100px 让模板下移避开顶部 */
.ai-full__templates {
  display: flex;
  gap: 8px;
  width: 100%;
  flex-wrap: wrap;
  justify-content: center;
  margin-top: 100px;
}

/* 单个模板按钮：胶囊形小按钮，hover 时变蓝边 + 蓝字 */
.ai-full__template {
  padding: 6px 14px;
  font-size: 13px;
  border-radius: 999px;
  border: 1px solid #e0e6ef;
  background: #fff;
  color: #555;
  cursor: pointer;
  text-align: center;
  transition: all 0.2s;
  user-select: none;
}

.ai-full__template:hover {
  border-color: #2563eb;
  color: #2563eb;
}

/* 激活模板：紫色渐变实心 + 白字，区别于普通模板的胶囊样式 */
.ai-full__template.is-active {
  background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
  border-color: transparent;
  color: #fff;
  font-weight: 500;
  box-shadow: 0 2px 8px rgba(102, 126, 234, 0.25);
}

/* 示例问题列表容器：纵向排列，align-items: center 让每项水平居中 */
.ai-full__examples {
  display: flex;
  flex-direction: column;
  gap: 8px;
  width: 100%;
  align-items: center;
}

/* ---- 单个示例问题 ----
   行 Flex：[图标] [文字] 紧挨居中
   - gap: 4px 让图标和文字紧挨（满足「图标和文字紧挨」需求）
   - justify-content + align-items: center 整体水平垂直居中
   - max-width: 540px 限制最大宽度，避免过宽 */
.ai-full__example {
  display: flex;
  align-items: center;
  justify-content: center;
  gap: 4px;
  padding: 11px 16px;
  background: #f5f7fa;
  border-radius: 12px;
  cursor: pointer;
  transition: all 0.2s;
  font-size: 14px;
  color: #333;
  width: 100%;
  max-width: 540px;
}

/* 悬停：浅蓝底 + 上浮 1px + 阴影，提供交互反馈 */
.ai-full__example:hover {
  background: #e8f0ff;
  transform: translateY(-1px);
  box-shadow: 0 4px 12px rgba(37, 99, 235, 0.08);
}

/* 示例问题图标：16px，flex-shrink: 0 不被压缩 */
.ai-full__example-icon {
  font-size: 16px;
  flex-shrink: 0;
}

/* 示例问题文字：左对齐（与图标紧挨后整体居中） */
.ai-full__example-text {
  text-align: left;
}

/* ---- 对话消息项 ----
   行 Flex：[头像] [消息内容]
   is-user 状态下 flex-direction: row-reverse 反转为 [内容] [头像] 靠右 */
.ai-full__msg {
  display: flex;
  gap: 10px;
  margin-bottom: 16px;
}

/* 用户消息：反转方向，让头像和气泡靠右显示 */
.ai-full__msg.is-user {
  flex-direction: row-reverse;
}

/* 消息头像：34×34 圆形，AI 头像白底，用户头像蓝色背景 */
.ai-full__msg-avatar {
  width: 34px;
  height: 34px;
  border-radius: 50%;
  background: #fff;
  display: flex;
  align-items: center;
  justify-content: center;
  font-size: 18px;
  flex-shrink: 0;
  box-shadow: 0 2px 8px rgba(0, 0, 0, 0.06);
}

/* 用户头像：蓝色背景区分 */
.ai-full__msg.is-user .ai-full__msg-avatar {
  background: #2563eb;
}

/* 消息内容容器：max-width: 75% 防止气泡占满整行 */
.ai-full__msg-content {
  max-width: 75%;
}

/* 用户消息内容：右对齐（配合 row-reverse） */
.ai-full__msg.is-user .ai-full__msg-content {
  display: flex;
  flex-direction: column;
  align-items: flex-end;
}

/* ---- 纯文本消息气泡 ----
   浅灰底 + 12px 圆角 + 1.6 行高
   word-break: break-word 长 URL 自动换行
   white-space: pre-wrap 保留换行符 */
.ai-full__text {
  background: #f5f7fa;
  padding: 10px 14px;
  border-radius: 12px;
  line-height: 1.6;
  word-break: break-word;
  font-size: 14px;
  white-space: pre-wrap;
}

/* 用户气泡：蓝色背景 + 白字 */
.ai-full__msg.is-user .ai-full__text {
  background: #2563eb;
  color: #fff;
}

/* ---- AI Markdown 回复气泡 ----
   非对称圆角（4px 12px 12px 12px）让左上角尖角暗示消息来源
   line-height: 1.7 比纯文本略宽，适合 Markdown 长内容阅读 */
.ai-full__markdown {
  background: #f5f7fa;
  padding: 12px 16px;
  border-radius: 4px 12px 12px 12px;
  line-height: 1.7;
  font-size: 14px;
  color: #333;
  word-break: break-word;
}

/* :deep() 穿透 scoped 限制，渲染 Markdown 生成的 HTML 标签 */
/* 标题 h2/h3/h4：上下边距 */
.ai-full__markdown :deep(h2),
.ai-full__markdown :deep(h3),
.ai-full__markdown :deep(h4) {
  margin: 10px 0 6px;
}

/* 列表 ul/ol：左侧缩进 20px */
.ai-full__markdown :deep(ul),
.ai-full__markdown :deep(ol) {
  padding-left: 20px;
  margin: 4px 0;
}

/* 行内 code：浅灰底 + 小圆角，区别于正文 */
.ai-full__markdown :deep(code) {
  background: #e8e8e8;
  padding: 2px 6px;
  border-radius: 4px;
  font-size: 13px;
}

/* 代码块 pre：深色主题（VS Code 风格 #1e1e1e 底 + #d4d4d4 字） */
.ai-full__markdown :deep(pre) {
  background: #1e1e1e;
  color: #d4d4d4;
  padding: 14px;
  border-radius: 8px;
  overflow-x: auto;
  margin: 8px 0;
}

/* 引用块 blockquote：左侧蓝色竖线 + 灰色文字，仿照邮件引用样式 */
.ai-full__markdown :deep(blockquote) {
  border-left: 3px solid #2563eb;
  padding-left: 10px;
  color: #666;
  margin: 6px 0;
}

/* 表格：宽度 100% + 边框合并（border-collapse: collapse） */
.ai-full__markdown :deep(table) {
  width: 100%;
  border-collapse: collapse;
  margin: 8px 0;
}

/* 表格单元格 td/th：1px 灰色边框 + 6px 10px 内边距 */
.ai-full__markdown :deep(td),
.ai-full__markdown :deep(th) {
  border: 1px solid #ddd;
  padding: 6px 10px;
}

/* 加粗 strong：蓝色突出（与主品牌色一致） */
.ai-full__markdown :deep(strong) {
  color: #2563eb;
}

/* ---- AI 思考中的打字动画 ----
   三个圆点轮流弹跳，表示 AI 正在生成回复
   - .ai-full__typing 容器：横向 flex 排列三个 span
   - 每个 span 8×8 灰色圆点，应用 bounce 动画
   - 通过 animation-delay 让三点错开节奏（-0.32s / -0.16s / 0s） */
.ai-full__typing {
  display: flex;
  gap: 4px;
  padding: 10px 14px;
}

.ai-full__typing span {
  width: 8px;
  height: 8px;
  background: #ccc;
  border-radius: 50%;
  animation: bounce 1.4s infinite ease-in-out both;
}

/* 前两个点提前延迟，形成波浪式弹跳 */
.ai-full__typing span:nth-child(1) { animation-delay: -0.32s; }
.ai-full__typing span:nth-child(2) { animation-delay: -0.16s; }

/* 弹跳关键帧：0% 缩小 → 40% 放大 → 80%/100% 再缩小 */
@keyframes bounce {
  0%, 80%, 100% { transform: scale(0); }
  40% { transform: scale(1); }
}

/* ---- 文件卡片（已上传文件展示区） ----
   仅在「会议纪要」选项卡下显示，支持 .txt 和音频文件
   - 外层 .ai-full__file-list 浅蓝底容器
   - 内层 .ai-full__file-card 白底卡片，每张卡片代表一个已上传文件 */
.ai-full__file-list {
  display: flex;
  flex-direction: column;
  gap: 6px;
  padding: 8px 12px;
  background: #f0f9ff;
  border: 1px solid #bae6fd;
  border-radius: 10px;
}

/* 单个文件卡片：[类型图标] [文件名/元信息] [删除按钮] 行 Flex */
.ai-full__file-card {
  display: flex;
  align-items: center;
  gap: 10px;
  padding: 8px 12px;
  background: #fff;
  border: 1px solid #e0f2fe;
  border-radius: 8px;
  font-size: 13px;
}

/* 文件类型图标（📄/🎵 等） */
.ai-full__file-type {
  font-size: 16px;
  flex-shrink: 0;
}

/* 文件信息容器：flex:1 占满中间，overflow: hidden 配合省略号 */
.ai-full__file-info {
  flex: 1;
  min-width: 0;
  overflow: hidden;
}

/* 文件名：深蓝色（#0c4a6e）+ 超长省略号 */
.ai-full__file-name {
  font-weight: 500;
  color: #0c4a6e;
  white-space: nowrap;
  overflow: hidden;
  text-overflow: ellipsis;
}

/* 文件元信息（大小/格式）：灰色 12px 弱化 */
.ai-full__file-meta {
  color: #64748b;
  font-size: 12px;
  margin-top: 2px;
}

/* 文件删除按钮：灰色默认，hover 变红色（危险操作） */
.ai-full__file-remove {
  cursor: pointer;
  color: #94a3b8;
  flex-shrink: 0;
  font-size: 15px;
  transition: color 0.2s;
}

.ai-full__file-remove:hover {
  color: #ef4444;
}

/* ---- 输入区（底部固定区域） ----
   行 Flex：[+ 上传按钮] [输入框容器] [发送按钮]
   - height: 340px 加高对话框（满足「对话框加高」需求）
   - align-items: flex-end 让元素底部对齐（输入框增高时按钮不漂移） */
.ai-full__input {
  padding: 10px 16px;
  border-top: 1px solid #f0f0f0;
  display: flex;
  gap: 10px;
  align-items: flex-end;
  height: 340px;
}

/* 隐藏的 file input：通过 .ai-full__upload 按钮触发点击 */
.ai-full__file-input {
  display: none;
}

/* ---- + 上传按钮 ----
   34×34 方形图标按钮，浅蓝底 + 蓝色 +
   hover 时放大 1.05 倍 + 深蓝底
   is-disabled 状态下变灰不可点击
   .is-loading 状态下旋转（spin 动画） */
.ai-full__upload {
  display: flex;
  align-items: center;
  justify-content: center;
  width: 34px;
  height: 34px;
  border-radius: 8px;
  background: #f0f5ff;
  color: #2563eb;
  font-size: 18px;
  cursor: pointer;
  flex-shrink: 0;
  transition: all 0.2s;
  user-select: none;
}

.ai-full__upload:hover:not(.is-disabled) {
  background: #dbeafe;
  transform: scale(1.05);
}

.ai-full__upload.is-disabled {
  opacity: 0.4;
  cursor: not-allowed;
}

/* 上传中旋转动画 */
.ai-full__upload .is-loading {
  animation: spin 1s linear infinite;
}

/* 旋转关键帧：0° → 360° 循环 */
@keyframes spin {
  from { transform: rotate(0deg); }
  to { transform: rotate(360deg); }
}

/* ---- 输入框容器 ----
   flex:1 占满中间，相对定位
   focus-within 状态下变蓝边 + 蓝色光晕（表示当前焦点） */
.ai-full__input-box {
  flex: 1;
  position: relative;
  display: flex;
  align-items: flex-end;
  border: 1px solid #e0e0e0;
  border-radius: 10px;
  background: #fff;
  transition: border-color 0.2s;
  padding: 2px 4px 2px 0;
}

.ai-full__input-box:focus-within {
  border-color: #2563eb;
  box-shadow: 0 0 0 2px rgba(37, 99, 235, 0.1);
}

/* textarea 容器：height: 100px 加高输入框 */
.ai-full__textarea {
  flex: 1;
  padding: 6px 8px;
  height: 100px;
}

/* 穿透 scoped 重写 Element Plus textarea 样式：去除边框，融合到外层容器 */
.ai-full__textarea :deep(textarea) {
  font-size: 14px;
  line-height: 1.5;
  padding: 4px 6px;
  background: transparent;
  border: none !important;
  box-shadow: none !important;
}

.ai-full__textarea :deep(.el-textarea__inner) {
  border: none !important;
  box-shadow: none !important;
}

/* ---- 发送按钮 ----
   32×32 蓝色圆形图标按钮
   - !important 覆盖 Element Plus 默认样式
   - hover 时放大 1.08 倍 + 强阴影
   - :disabled 状态变灰（无内容时禁用） */
.ai-full__send {
  flex-shrink: 0;
  width: 32px;
  height: 32px;
  background: #2563eb !important;
  border: none !important;
  box-shadow: 0 2px 6px rgba(37, 99, 235, 0.3);
  transition: all 0.2s ease;
  margin: 0;
}

.ai-full__send:hover:not(:disabled) {
  transform: scale(1.08);
  box-shadow: 0 3px 10px rgba(37, 99, 235, 0.45);
}

.ai-full__send:disabled {
  background: #d1d5db !important;
  box-shadow: none;
}

/* 底部脚注：左对齐灰色小字，显示提示信息（如「回车发送」） */
.ai-full__footer {
  text-align: left;
  padding: 4px 16px 10px;
  font-size: 12px;
  color: #9ca3af;
}

/* ========== 4. 响应式设计 ==========
   大屏（>900px）：完整布局
   中屏（≤900px）：去除卡片外边距和圆角，侧边栏收窄到 200px，主选项卡缩小
   小屏（≤700px）：侧边栏强制折叠为 60px 图标列，隐藏搜索/历史标题/会话列表，显示折叠列表 */
@media (max-width: 900px) {
  .ai-chat-full {
    padding: 0;
  }

  .ai-full {
    border-radius: 0;
    border: none;
    box-shadow: none;
  }

  .ai-full__sidebar {
    width: 200px;
  }

  .ai-full__tab-primary {
    padding: 6px 14px;
    font-size: 14px;
  }

  .ai-full__tab-primary-icon {
    font-size: 15px;
  }
}

/* 小屏断点（≤700px）：侧边栏强制折叠为图标列
   - 侧边栏宽度变 60px
   - 隐藏品牌头部/新建对话/搜索/历史标题/完整会话列表
   - 显示折叠列表 .ai-full__collapsed-list（仅图标） */
@media (max-width: 700px) {
  .ai-full__sidebar {
    width: 60px;
  }

  .ai-full__sidebar-header,
  .ai-full__new-chat,
  .ai-full__search,
  .ai-full__history-title,
  .ai-full__conversation-list {
    display: none;
  }

  .ai-full__collapsed-list {
    display: flex;
  }
}
</style>
