<template>
  <div class="ai-chat-full">
    <div class="ai-full">
      <!-- 侧边栏 -->
      <div class="ai-full__sidebar">
        <div class="ai-full__new-chat" @click="handleNewChat">
          <el-icon><Plus /></el-icon>
          <span>新建对话</span>
        </div>
        <div class="ai-full__tabs">
          <div
            v-for="tab in tabs"
            :key="tab.key"
            class="ai-full__tab"
            :class="{ 'is-active': activeTab === tab.key }"
            @click="switchTab(tab.key)"
          >
            <span class="ai-full__tab-icon">{{ tab.icon }}</span>
            <span>{{ tab.name }}</span>
          </div>
        </div>
        <div class="ai-full__divider"></div>
        <div class="ai-full__history">
          <div class="ai-full__history-title">历史对话</div>
          <div class="ai-full__conversation-list">
            <div
              v-for="conv in conversations"
              :key="conv.id"
              class="ai-full__conversation"
              :class="{ 'is-active': activeConversationId === conv.id, 'is-pinned': conv.isPinned === '1' }"
              @click="selectConversation(conv.id)"
            >
              <span v-if="conv.isPinned === '1'" class="ai-full__pin-icon">📌</span>
              <span class="ai-full__conv-title">{{ conv.title }}</span>
              <span class="ai-full__conv-time">{{ formatTime(conv.updateTime) }}</span>
              <div class="ai-full__conv-actions" @click.stop>
                <el-icon
                  class="ai-full__action-btn"
                  :title="conv.isPinned === '1' ? '取消置顶' : '置顶'"
                  @click="handlePin(conv)"
                >
                  <Star v-if="conv.isPinned !== '1'" />
                  <StarFilled v-else />
                </el-icon>
                <el-icon class="ai-full__action-btn" title="删除" @click="handleDelete(conv)">
                  <Delete />
                </el-icon>
              </div>
            </div>
            <div v-if="conversations.length === 0" class="ai-full__empty">
              暂无对话记录
            </div>
          </div>
        </div>
      </div>

      <!-- 聊天区 -->
      <div class="ai-full__chat">
        <div class="ai-full__chat-header">
          <span class="ai-full__chat-title">{{ currentTabName }}</span>
          <el-icon class="ai-full__close" @click="goBack"><Close /></el-icon>
        </div>
        <div class="ai-full__chat-body" ref="chatBodyRef">
          <div v-if="currentMessages.length === 0" class="ai-full__welcome">
            <div class="ai-full__welcome-title">{{ currentTabName }} · {{ currentTabExamples[0] }}</div>
            <div v-if="currentTemplates.length" class="ai-full__templates">
              <div
                v-for="tpl in currentTemplates"
                :key="tpl.key"
                class="ai-full__template"
                :class="{ 'is-active': activeTemplateKey === tpl.key }"
                @click="selectTemplate(tpl.key)"
              >
                {{ tpl.name }}
              </div>
            </div>
            <div class="ai-full__examples">
              <div
                v-for="(example, idx) in currentTabExamples"
                :key="idx"
                class="ai-full__example"
                @click="sendExample(example)"
              >
                <span class="ai-full__example-icon">{{ exampleIcons[idx] }}</span>
                <span>{{ example }}</span>
              </div>
            </div>
          </div>
          <div v-for="(msg, idx) in currentMessages" :key="idx" class="ai-full__msg" :class="`is-${msg.role}`">
            <div class="ai-full__msg-avatar">
              {{ msg.role === 'user' ? '😊' : '🤖' }}
            </div>
            <div class="ai-full__msg-content">
              <div v-if="msg.role === 'assistant' && msg.content" class="ai-full__markdown" v-html="renderMarkdown(msg.content)"></div>
              <div v-else class="ai-full__text">{{ msg.content }}</div>
              <div v-if="msg.role === 'assistant' && loading && idx === currentMessages.length - 1 && msg.isComplete === '0'" class="ai-full__typing">
                <span></span><span></span><span></span>
              </div>
            </div>
          </div>
          <!-- 已上传文件卡片 -->
          <div v-if="uploadedFiles.length > 0" class="ai-full__file-list">
            <div
              v-for="file in uploadedFiles"
              :key="file.id"
              class="ai-full__file-card"
            >
              <span class="ai-full__file-type">{{ file.type === 'audio' ? '🎵' : '📄' }}</span>
              <div class="ai-full__file-info">
                <div class="ai-full__file-name" :title="file.fileName">{{ file.fileName }}</div>
                <div class="ai-full__file-meta">{{ file.type === 'audio' ? '音频文件' : '文本文件' }} · {{ formatFileSize(file.size) }}</div>
              </div>
              <el-icon class="ai-full__file-remove" @click="removeUploadedFile(file.id)"><Remove /></el-icon>
            </div>
          </div>
        </div>
        <div class="ai-full__input-area">
          <input
            v-show="activeTab === 'meeting'"
            ref="fileInputRef"
            type="file"
            accept=".txt,.mp3,.wav,.m4a,.aac,.ogg,.flac"
            class="ai-full__file-input"
            @change="handleFileUpload"
          />
          <div
            v-if="activeTab === 'meeting'"
            class="ai-full__upload-btn"
            :class="{ 'is-disabled': uploading || loading }"
            @click="triggerFileInput"
          >
            <el-icon v-if="!uploading"><Upload /></el-icon>
            <el-icon v-else class="is-loading"><Loading /></el-icon>
            <span>{{ uploading ? '转换中' : '上传文件' }}</span>
          </div>
          <el-input
            v-model="inputText"
            type="textarea"
            :autosize="{ minRows: 2, maxRows: 5 }"
            :placeholder="inputPlaceholder"
            :disabled="loading"
            @keydown.enter.exact.prevent="handleSend"
            resize="none"
            class="ai-full__input"
          />
          <el-button
            type="primary"
            :disabled="(!inputText.trim() && uploadedFiles.length === 0) || loading"
            @click="handleSend"
          >
            发送
          </el-button>
        </div>
        <div class="ai-full__footer">Enter 发送 · Shift + Enter 换行</div>
      </div>
    </div>
  </div>
</template>

<script setup lang="ts">
import { ref, computed, onMounted, nextTick } from 'vue'
import { useRouter } from 'vue-router'
import {
  Promotion, Plus, Star, StarFilled, Delete, Close, Upload, Loading, Remove
} from '@element-plus/icons-vue'
import { ElMessage, ElMessageBox } from 'element-plus'
import {
  listConversations, getMessages,
  deleteConversation, togglePin, getTabConfigs, buildStreamUrl, uploadFile,
  type AiConversation, type AiMessage, type TabConfig, type ExampleTemplate
} from '@/api/ai/chat'

const router = useRouter()

const exampleIcons: string[] = ['💡', '📋', '🎯']

const loading = ref(false)
const activeTab = ref('chat')
const tabs = ref<TabConfig[]>([])
const inputText = ref('')
const activeConversationId = ref<number | null>(null)
const conversations = ref<AiConversation[]>([])
const currentMessages = ref<AiMessage[]>([])
const chatBodyRef = ref<HTMLElement | null>(null)
const activeTemplateMap = ref<Record<string, string>>({})
const uploading = ref(false)
const fileInputRef = ref<HTMLInputElement | null>(null)

interface UploadedFile {
  id: string
  fileName: string
  text: string
  size: number
  type: 'txt' | 'audio'
}
const uploadedFiles = ref<UploadedFile[]>([])

const currentTab = computed(() => tabs.value.find(t => t.key === activeTab.value))
const currentTemplates = computed<ExampleTemplate[]>(() => currentTab.value?.templates || [])
const activeTemplateKey = computed<string | null>(() => {
  if (!currentTemplates.value.length) return null
  const stored = activeTemplateMap.value[activeTab.value]
  if (stored && currentTemplates.value.some(t => t.key === stored)) return stored
  return currentTemplates.value[0].key
})
const activeTemplate = computed<ExampleTemplate | null>(() =>
  activeTemplateKey.value ? currentTemplates.value.find(t => t.key === activeTemplateKey.value) || null : null
)
const currentTabExamples = computed<string[]>(() => {
  if (activeTemplate.value) return activeTemplate.value.examples
  return currentTab.value?.examples || []
})
const currentTabName = computed(() => currentTab.value?.name || '智聊')
const inputPlaceholder = computed(() => {
  const names: Record<string, string> = {
    chat: '请输入问题，与智聊对话...',
    translate: '请输入要翻译的内容...',
    meeting: '请描述会议相关信息...',
    writing: '请描述写作需求...'
  }
  return names[activeTab.value] || '请输入内容...'
})

function renderMarkdown(text: string): string {
  if (!text) return ''
  let html = text
  html = html.replace(/```(\w*)\n([\s\S]*?)```/g, '<pre class="ai-md-code"><code>$2</code></pre>')
  html = html.replace(/\*\*(.+?)\*\*/g, '<strong>$1</strong>')
  html = html.replace(/^\s*[-*]\s+(.+)$/gm, '<li>$1</li>')
  html = html.replace(/(<li>.*<\/li>\s*)+/g, '<ul>$&</ul>')
  html = html.replace(/^\s*\d+\.\s+(.+)$/gm, '<li>$1</li>')
  html = html.replace(/^### (.+)$/gm, '<h4>$1</h4>')
  html = html.replace(/^## (.+)$/gm, '<h3>$1</h3>')
  html = html.replace(/^# (.+)$/gm, '<h2>$1</h2>')
  html = html.replace(/^\|(.+)\|$/gm, '<tr>$1</tr>')
  html = html.replace(/(<tr>.*<\/tr>\s*)+/g, '<table class="ai-md-table">$&</table>')
  html = html.replace(/^>\s+(.+)$/gm, '<blockquote>$1</blockquote>')
  html = html.replace(/\n/g, '<br/>')
  return html
}

function switchTab(key: string) {
  activeTab.value = key
  activeConversationId.value = null
  currentMessages.value = []
  const tab = tabs.value.find(t => t.key === key)
  if (tab?.templates?.length && !activeTemplateMap.value[key]) {
    activeTemplateMap.value[key] = tab.templates[0].key
  }
}

function selectTemplate(tplKey: string) {
  if (loading.value) return
  activeTemplateMap.value[activeTab.value] = tplKey
}

function goBack() {
  router.back()
}

async function loadConversations() {
  try {
    const res = await listConversations()
    conversations.value = res.data || []
  } catch (e) {
    console.error('加载会话列表失败', e)
  }
}

function selectConversation(id: number) {
  activeConversationId.value = id
  const conv = conversations.value.find(c => c.id === id)
  if (conv) {
    activeTab.value = conv.type
  }
  loadMessages(id)
}

async function loadMessages(id: number) {
  try {
    const res = await getMessages(id)
    currentMessages.value = res.data || []
    scrollToBottom()
  } catch (e) {
    console.error('加载消息失败', e)
  }
}

function handleNewChat() {
  activeConversationId.value = null
  currentMessages.value = []
  inputText.value = ''
}

async function handlePin(conv: AiConversation) {
  try {
    await togglePin(conv.id)
    await loadConversations()
    ElMessage.success(conv.isPinned === '1' ? '已取消置顶' : '已置顶')
  } catch (e: any) {
    ElMessage.error(e?.message || '操作失败')
  }
}

async function handleDelete(conv: AiConversation) {
  try {
    await ElMessageBox.confirm('确定删除该会话？', '提示', { type: 'warning' })
    await deleteConversation(conv.id)
    await loadConversations()
    if (activeConversationId.value === conv.id) {
      handleNewChat()
    }
    ElMessage.success('删除成功')
  } catch (e) {
    if (e !== 'cancel') ElMessage.error('删除失败')
  }
}

async function handleSend() {
  const userInput = inputText.value.trim()
  const hasFiles = uploadedFiles.value.length > 0
  if ((!userInput && !hasFiles) || loading.value) return

  let question = userInput
  if (hasFiles) {
    const fileTexts = uploadedFiles.value.map(f => {
      const label = f.type === 'audio' ? '语音转文字内容' : '文件内容'
      return `【${label} - ${f.fileName}】\n${f.text}`
    }).join('\n\n')
    if (userInput) {
      question = `${fileTexts}\n\n【用户问题】\n${userInput}`
    } else {
      question = fileTexts
    }
  }

  uploadedFiles.value = []
  await sendMessage(question)
}

async function sendExample(example: string) {
  if (loading.value) return
  await sendMessage(example)
}

function triggerFileInput() {
  if (uploading.value) return
  fileInputRef.value?.click()
}

async function handleFileUpload(event: Event) {
  const target = event.target as HTMLInputElement
  const file = target.files?.[0]
  if (!file) return
  target.value = ''

  const allowedExt = ['.txt', '.mp3', '.wav', '.m4a', '.aac', '.ogg', '.flac']
  const fileName = file.name.toLowerCase()
  if (!allowedExt.some(ext => fileName.endsWith(ext))) {
    ElMessage.warning('仅支持 .txt 和音频文件（mp3/wav/m4a/aac/ogg/flac）')
    return
  }

  uploading.value = true
  try {
    const res = await uploadFile(file)
    const text = res.data?.text || ''
    if (text) {
      const isAudio = !fileName.endsWith('.txt')
      uploadedFiles.value.push({
        id: Date.now() + Math.random().toString(36).slice(2, 6),
        fileName: res.data?.fileName || file.name,
        text,
        size: file.size,
        type: isAudio ? 'audio' : 'txt'
      })
      ElMessage.success(`文件「${res.data?.fileName || file.name}」已转换完成，可继续输入内容后发送`)
    } else {
      ElMessage.warning('文件内容为空')
    }
  } catch (e: any) {
    ElMessage.error(e?.message || '文件上传失败')
  } finally {
    uploading.value = false
  }
}

function removeUploadedFile(id: string) {
  uploadedFiles.value = uploadedFiles.value.filter(f => f.id !== id)
}

function formatFileSize(bytes: number): string {
  if (bytes < 1024) return bytes + ' B'
  if (bytes < 1024 * 1024) return (bytes / 1024).toFixed(1) + ' KB'
  return (bytes / 1024 / 1024).toFixed(1) + ' MB'
}

async function sendMessage(question: string) {
  loading.value = true
  inputText.value = ''

  currentMessages.value.push({
    id: Date.now(),
    conversationId: activeConversationId.value || 0,
    role: 'user',
    content: question,
    type: activeTab.value,
    isComplete: '1',
    createTime: new Date().toISOString()
  })
  currentMessages.value.push({
    id: Date.now() + 1,
    conversationId: activeConversationId.value || 0,
    role: 'assistant',
    content: '',
    type: activeTab.value,
    isComplete: '0',
    createTime: new Date().toISOString()
  })
  scrollToBottom()

  try {
    const { url } = buildStreamUrl({
      question,
      conversationId: activeConversationId.value || undefined,
      type: activeTab.value
    })

    const eventSource = new EventSource(url)
    let buffer = ''

    eventSource.onmessage = (event) => {
      try {
        const data = JSON.parse(event.data)
        if (data.type === 'conversation' && data.conversationId) {
          activeConversationId.value = data.conversationId
          loadConversations()
        } else if (data.type === 'delta') {
          buffer += data.content
          if (currentMessages.value.length > 0) {
            const lastMsg = currentMessages.value[currentMessages.value.length - 1]
            if (lastMsg.role === 'assistant') {
              lastMsg.content = buffer
            }
          }
          scrollToBottom()
        } else if (data.type === 'complete') {
          if (currentMessages.value.length > 0) {
            const lastMsg = currentMessages.value[currentMessages.value.length - 1]
            if (lastMsg.role === 'assistant') {
              lastMsg.content = data.content || buffer
              lastMsg.isComplete = '1'
            }
          }
          eventSource.close()
        } else if (data.type === 'error') {
          if (currentMessages.value.length > 0) {
            const lastMsg = currentMessages.value[currentMessages.value.length - 1]
            if (lastMsg.role === 'assistant') {
              lastMsg.content = '❌ ' + data.content
              lastMsg.isComplete = '1'
            }
          }
          eventSource.close()
        }
      } catch (e) {
        console.error('SSE 解析错误', e)
      }
    }

    eventSource.onerror = () => {
      if (currentMessages.value.length > 0) {
        const lastMsg = currentMessages.value[currentMessages.value.length - 1]
        if (lastMsg.role === 'assistant') {
          if (!buffer) {
            lastMsg.content = '❌ 连接失败，请重试'
          }
          lastMsg.isComplete = '1'
        }
      }
      eventSource.close()
      loading.value = false
    }

    await new Promise<void>((resolve) => {
      const check = setInterval(() => {
        if (eventSource.readyState === EventSource.CLOSED) {
          clearInterval(check)
          resolve()
        }
      }, 500)
      setTimeout(() => { clearInterval(check); resolve() }, 300000)
    })
  } catch (e) {
    console.error('流式请求失败', e)
  } finally {
    loading.value = false
    await loadConversations()
  }
}

function scrollToBottom() {
  nextTick(() => {
    if (chatBodyRef.value) {
      chatBodyRef.value.scrollTop = chatBodyRef.value.scrollHeight
    }
  })
}

function formatTime(timeStr: string) {
  if (!timeStr) return ''
  const d = new Date(timeStr)
  const now = new Date()
  const diff = now.getTime() - d.getTime()
  if (diff < 60000) return '刚刚'
  if (diff < 3600000) return `${Math.floor(diff / 60000)} 分钟前`
  if (diff < 86400000) return `${Math.floor(diff / 3600000)} 小时前`
  return `${d.getMonth() + 1}/${d.getDate()} ${String(d.getHours()).padStart(2, '0')}:${String(d.getMinutes()).padStart(2, '0')}`
}

onMounted(async () => {
  try {
    const res = await getTabConfigs()
    tabs.value = res.data || []
  } catch (e) {
    console.error('加载 Tab 配置失败', e)
    tabs.value = [
      { key: 'chat', name: '智聊', icon: '💬', examples: ['解读银行日常业务需要遵守的合规管理要求', '帮我梳理一下最近科技行业的发展趋势', '如何提升团队协作效率？有哪些实用方法'] },
      { key: 'translate', name: '翻译', icon: '🌐', examples: ['将这段中文翻译成地道的英文：人工智能正在改变世界', '翻译成日语：这份报告需要在下周五之前完成', '翻译成法语：欢迎来到我们的新产品发布会'] },
      { key: 'meeting', name: '会议纪要', icon: '📝', examples: ['生成一份季度董事会会议纪要模板', '帮我整理产品需求评审会的会议纪要', '生成项目启动会的会议纪要框架'] },
      { key: 'writing', name: '辅助写作', icon: '✍️', examples: ['帮我写一封正式的商务合作邀请函', '撰写一篇关于人工智能在医疗领域应用的文章', '生成一份项目年度总结报告大纲'] }
    ]
  }
  await loadConversations()
})
</script>

<style scoped>
.ai-chat-full {
  position: fixed;
  inset: 0;
  z-index: 9999;
  background: #f5f7fa;
}

.ai-full {
  display: flex;
  width: 100%;
  height: 100%;
}

.ai-full__sidebar {
  width: 260px;
  background: #fff;
  border-right: 1px solid #e8e8e8;
  display: flex;
  flex-direction: column;
  overflow: hidden;
}

.ai-full__new-chat {
  margin: 12px;
  padding: 10px 12px;
  background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
  color: #fff;
  border-radius: 10px;
  cursor: pointer;
  display: flex;
  align-items: center;
  gap: 8px;
  font-weight: 500;
  transition: opacity 0.2s;
}

.ai-full__new-chat:hover {
  opacity: 0.9;
}

.ai-full__tabs {
  display: flex;
  padding: 0 12px;
  gap: 4px;
  flex-wrap: wrap;
}

.ai-full__tab {
  display: flex;
  align-items: center;
  gap: 4px;
  padding: 6px 10px;
  border-radius: 8px;
  cursor: pointer;
  font-size: 12px;
  color: #666;
  transition: all 0.2s;
}

.ai-full__tab:hover {
  background: #f5f5f5;
}

.ai-full__tab.is-active {
  background: #f0f5ff;
  color: #1677ff;
}

.ai-full__tab-icon {
  font-size: 14px;
}

.ai-full__divider {
  height: 1px;
  background: #f0f0f0;
  margin: 12px;
}

.ai-full__history {
  flex: 1;
  overflow: hidden;
  display: flex;
  flex-direction: column;
}

.ai-full__history-title {
  padding: 0 12px 8px;
  font-size: 12px;
  color: #999;
}

.ai-full__conversation-list {
  flex: 1;
  overflow-y: auto;
  padding: 0 8px;
}

.ai-full__conversation {
  display: flex;
  align-items: center;
  gap: 6px;
  padding: 10px 8px;
  border-radius: 8px;
  cursor: pointer;
  font-size: 13px;
  transition: background 0.2s;
  position: relative;
}

.ai-full__conversation:hover {
  background: #f5f5f5;
}

.ai-full__conversation.is-active {
  background: #e8f0ff;
  color: #1677ff;
}

.ai-full__conversation.is-pinned {
  background: #fffbe6;
}

.ai-full__pin-icon {
  font-size: 12px;
}

.ai-full__conv-title {
  flex: 1;
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
}

.ai-full__conv-time {
  font-size: 11px;
  color: #999;
  flex-shrink: 0;
}

.ai-full__conv-actions {
  display: none;
  gap: 4px;
}

.ai-full__conversation:hover .ai-full__conv-actions {
  display: flex;
}

.ai-full__action-btn {
  color: #999;
  font-size: 14px;
}

.ai-full__action-btn:hover {
  color: #1677ff;
}

.ai-full__empty {
  text-align: center;
  color: #ccc;
  padding: 40px 0;
  font-size: 13px;
}

.ai-full__chat {
  flex: 1;
  display: flex;
  flex-direction: column;
  background: #f5f7fa;
}

.ai-full__chat-header {
  display: flex;
  align-items: center;
  justify-content: space-between;
  padding: 16px 24px;
  background: #fff;
  border-bottom: 1px solid #e8e8e8;
}

.ai-full__chat-title {
  font-size: 16px;
  font-weight: 500;
}

.ai-full__close {
  cursor: pointer;
  color: #999;
  font-size: 20px;
}

.ai-full__close:hover {
  color: #333;
}

.ai-full__chat-body {
  flex: 1;
  overflow-y: auto;
  padding: 24px;
  display: flex;
  flex-direction: column;
  gap: 16px;
}

.ai-full__file-list {
  display: flex;
  flex-direction: column;
  gap: 8px;
  padding: 12px 16px;
  background: #f0f9ff;
  border: 1px solid #bae6fd;
  border-radius: 12px;
  margin-top: auto;
}

.ai-full__file-card {
  display: flex;
  align-items: center;
  gap: 10px;
  padding: 10px 14px;
  background: #fff;
  border: 1px solid #e0f2fe;
  border-radius: 10px;
  font-size: 13px;
  box-shadow: 0 1px 2px rgba(0, 0, 0, 0.03);
}

.ai-full__file-type {
  font-size: 18px;
  flex-shrink: 0;
}

.ai-full__file-info {
  flex: 1;
  min-width: 0;
  overflow: hidden;
}

.ai-full__file-name {
  font-weight: 500;
  color: #0c4a6e;
  white-space: nowrap;
  overflow: hidden;
  text-overflow: ellipsis;
}

.ai-full__file-meta {
  color: #64748b;
  font-size: 12px;
  margin-top: 2px;
}

.ai-full__file-remove {
  cursor: pointer;
  color: #94a3b8;
  flex-shrink: 0;
  font-size: 16px;
  transition: color 0.2s;
}

.ai-full__file-remove:hover {
  color: #ef4444;
}

.ai-full__welcome {
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: center;
  height: 100%;
  text-align: center;
}

.ai-full__welcome-title {
  font-size: 18px;
  color: #666;
  margin-bottom: 20px;
}

.ai-full__templates {
  display: flex;
  gap: 12px;
  margin-bottom: 20px;
  max-width: 700px;
  width: 100%;
  justify-content: center;
}

.ai-full__template {
  min-width: 110px;
  padding: 8px 20px;
  font-size: 13px;
  border-radius: 999px;
  border: 1px solid #e0e6ef;
  background: #fff;
  color: #555;
  cursor: pointer;
  text-align: center;
  transition: all 0.2s;
  user-select: none;
  box-shadow: 0 2px 6px rgba(0, 0, 0, 0.04);
}

.ai-full__template:hover {
  border-color: #1677ff;
  color: #1677ff;
  transform: translateY(-1px);
}

.ai-full__template.is-active {
  background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
  border-color: transparent;
  color: #fff;
  font-weight: 500;
  box-shadow: 0 4px 14px rgba(102, 126, 234, 0.3);
}

.ai-full__examples {
  display: grid;
  grid-template-columns: repeat(auto-fit, minmax(280px, 1fr));
  gap: 12px;
  max-width: 700px;
  width: 100%;
}

.ai-full__example {
  display: flex;
  align-items: center;
  gap: 10px;
  padding: 14px 16px;
  background: #fff;
  border-radius: 12px;
  cursor: pointer;
  transition: all 0.2s;
  font-size: 14px;
  color: #333;
  box-shadow: 0 2px 8px rgba(0, 0, 0, 0.04);
}

.ai-full__example:hover {
  background: #f0f5ff;
  transform: translateY(-2px);
  box-shadow: 0 4px 16px rgba(22, 119, 255, 0.12);
}

.ai-full__example-icon {
  font-size: 18px;
}

.ai-full__msg {
  display: flex;
  gap: 12px;
  margin-bottom: 20px;
}

.ai-full__msg.is-user {
  flex-direction: row-reverse;
}

.ai-full__msg-avatar {
  width: 36px;
  height: 36px;
  border-radius: 50%;
  background: #fff;
  display: flex;
  align-items: center;
  justify-content: center;
  font-size: 18px;
  flex-shrink: 0;
  box-shadow: 0 2px 8px rgba(0, 0, 0, 0.06);
}

.ai-full__msg.is-user .ai-full__msg-avatar {
  background: #1677ff;
}

.ai-full__msg-content {
  max-width: 70%;
}

.ai-full__msg.is-user .ai-full__msg-content {
  display: flex;
  flex-direction: column;
  align-items: flex-end;
}

.ai-full__text {
  background: #fff;
  padding: 10px 14px;
  border-radius: 12px;
  box-shadow: 0 2px 8px rgba(0, 0, 0, 0.04);
  line-height: 1.6;
  word-break: break-word;
  font-size: 14px;
  white-space: pre-wrap;
}

.ai-full__msg.is-user .ai-full__text {
  background: #1677ff;
  color: #fff;
}

.ai-full__markdown {
  background: #fff;
  padding: 14px 18px;
  border-radius: 12px;
  box-shadow: 0 2px 8px rgba(0, 0, 0, 0.04);
  line-height: 1.7;
  font-size: 14px;
  color: #333;
  word-break: break-word;
}

.ai-full__markdown :deep(h2) { font-size: 16px; margin: 12px 0 8px; }
.ai-full__markdown :deep(h3) { font-size: 15px; margin: 10px 0 6px; }
.ai-full__markdown :deep(h4) { font-size: 14px; margin: 8px 0 4px; }
.ai-full__markdown :deep(ul), .ai-full__markdown :deep(ol) { padding-left: 20px; margin: 6px 0; }
.ai-full__markdown :deep(li) { margin: 2px 0; }
.ai-full__markdown :deep(p) { margin: 6px 0; }
.ai-full__markdown :deep(code) { background: #f0f0f0; padding: 2px 6px; border-radius: 4px; font-size: 13px; }
.ai-full__markdown :deep(pre) { background: #1e1e1e; color: #d4d4d4; padding: 14px; border-radius: 8px; overflow-x: auto; margin: 8px 0; }
.ai-full__markdown :deep(pre code) { background: transparent; color: inherit; padding: 0; }
.ai-full__markdown :deep(blockquote) { border-left: 3px solid #1677ff; padding-left: 12px; color: #666; margin: 8px 0; }
.ai-full__markdown :deep(table) { width: 100%; border-collapse: collapse; margin: 8px 0; }
.ai-full__markdown :deep(td), .ai-full__markdown :deep(th) { border: 1px solid #e0e0e0; padding: 8px 12px; text-align: left; }
.ai-full__markdown :deep(th) { background: #f5f5f5; }
.ai-full__markdown :deep(strong) { color: #1677ff; }

.ai-full__typing {
  display: flex;
  gap: 4px;
  padding: 10px 14px;
}

.ai-full__typing span {
  width: 8px;
  height: 8px;
  background: #ccc;
  border-radius: 50%;
  animation: bounce 1.4s infinite ease-in-out both;
}

.ai-full__typing span:nth-child(1) { animation-delay: -0.32s; }
.ai-full__typing span:nth-child(2) { animation-delay: -0.16s; }

@keyframes bounce {
  0%, 80%, 100% { transform: scale(0); }
  40% { transform: scale(1); }
}

.ai-full__file-input {
  display: none;
}

.ai-full__input-area {
  padding: 16px 24px;
  background: #fff;
  border-top: 1px solid #e8e8e8;
  display: flex;
  gap: 12px;
  align-items: flex-end;
}

.ai-full__upload-btn {
  display: flex;
  align-items: center;
  gap: 6px;
  padding: 8px 14px;
  border-radius: 8px;
  background: #f0f5ff;
  color: #1677ff;
  font-size: 13px;
  cursor: pointer;
  flex-shrink: 0;
  transition: all 0.2s;
  user-select: none;
  white-space: nowrap;
  height: 40px;
}

.ai-full__upload-btn:hover {
  background: #e0ebff;
  transform: translateY(-1px);
}

.ai-full__upload-btn.is-disabled {
  opacity: 0.5;
  cursor: not-allowed;
  transform: none;
}

.ai-full__input {
  flex: 1;
}

.ai-full__footer {
  text-align: center;
  padding: 8px 0 16px;
  font-size: 12px;
  color: #999;
  background: #fff;
}
</style>
