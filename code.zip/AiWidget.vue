<template>
  <div class="ai-widget">
    <!-- 悬浮入口按钮 -->
    <div v-if="!showMini" class="ai-widget__fab" @click="openMini">
      <div class="ai-widget__fab-icon">🤖</div>
      <div class="ai-widget__fab-pulse"></div>
    </div>

    <!-- 小窗口模式 -->
    <div v-if="showMini" class="ai-widget__mini">
      <div class="ai-widget__header">
        <div class="ai-widget__tabs">
          <div
            v-for="tab in tabs"
            :key="tab.key"
            class="ai-widget__tab"
            :class="{ 'is-active': activeTab === tab.key }"
            @click="switchTab(tab.key)"
          >
            <span class="ai-widget__tab-icon">{{ tab.icon }}</span>
            <span class="ai-widget__tab-name">{{ tab.name }}</span>
          </div>
        </div>
        <div class="ai-widget__actions">
          <el-icon class="ai-widget__expand" @click="openFullPage" :size="18" title="打开大页面">
            <FullScreen />
          </el-icon>
          <el-icon class="ai-widget__close-mini" @click="closeMini" :size="18" title="关闭">
            <Close />
          </el-icon>
        </div>
      </div>

      <div class="ai-widget__body">
        <div v-if="!currentAnswer && !loading" class="ai-widget__welcome">
          <div class="ai-widget__bubble">
            <div class="ai-widget__typing">
              <span></span><span></span><span></span>
            </div>
          </div>
          <p class="ai-widget__welcome-text">你好，我是智聊助手，有什么可以帮您？</p>
          <div v-if="currentTemplates.length" class="ai-widget__templates">
            <div
              v-for="tpl in currentTemplates"
              :key="tpl.key"
              class="ai-widget__template"
              :class="{ 'is-active': activeTemplateKey === tpl.key }"
              @click="selectTemplate(tpl.key)"
            >
              {{ tpl.name }}
            </div>
          </div>
          <div class="ai-widget__examples">
            <div
              v-for="(example, idx) in currentTabExamples"
              :key="idx"
              class="ai-widget__example"
              @click="sendExample(example)"
            >
              <span class="ai-widget__example-icon">{{ exampleIcons[idx] }}</span>
              <span class="ai-widget__example-text">{{ example }}</span>
            </div>
          </div>
        </div>

        <div v-else class="ai-widget__chat">
          <div v-if="lastUserQuestion" class="ai-widget__user-msg">
            <span class="ai-widget__user-icon">😊</span>
            <span class="ai-widget__user-text">{{ lastUserQuestion }}</span>
          </div>
          <div class="ai-widget__assistant-msg">
            <span class="ai-widget__ai-icon">🤖</span>
            <div class="ai-widget__ai-content">
              <div v-if="loading && !currentAnswer" class="ai-widget__typing">
                <span></span><span></span><span></span>
              </div>
              <div v-else class="ai-widget__markdown" v-html="renderedAnswer"></div>
            </div>
          </div>
        </div>
      </div>

      <!-- 已上传文件卡片（小页面，显示在对话框下方、输入框上方） -->
      <div v-if="uploadedFiles.length > 0" class="ai-widget__file-list">
        <div
          v-for="file in uploadedFiles"
          :key="file.id"
          class="ai-widget__file-card"
        >
          <span class="ai-widget__file-type">{{ file.type === 'audio' ? '🎵' : '📄' }}</span>
          <div class="ai-widget__file-info">
            <div class="ai-widget__file-name" :title="file.fileName">{{ file.fileName }}</div>
            <div class="ai-widget__file-meta">{{ file.type === 'audio' ? '音频文件' : '文本文件' }} · {{ formatFileSize(file.size) }}</div>
          </div>
          <el-icon class="ai-widget__file-remove" @click="removeUploadedFile(file.id)"><Remove /></el-icon>
        </div>
      </div>

      <div class="ai-widget__input">
        <input
          v-show="activeTab === 'meeting'"
          ref="fileInputRef"
          type="file"
          accept=".txt,.mp3,.wav,.m4a,.aac,.ogg,.flac"
          class="ai-widget__file-input"
          @change="handleFileUpload"
        />
        <div
          v-if="activeTab === 'meeting'"
          class="ai-widget__upload-btn"
          :class="{ 'is-disabled': uploading || loading }"
          @click="triggerFileInput"
        >
          <el-icon v-if="!uploading"><Upload /></el-icon>
          <el-icon v-else class="is-loading"><Loading /></el-icon>
          <span>{{ uploading ? '转换中' : '上传文件' }}</span>
        </div>
        <el-input
          v-model="inputText"
          type="textarea"
          :autosize="{ minRows: 1, maxRows: 3 }"
          :placeholder="inputPlaceholder"
          :disabled="loading"
          @keydown.enter.exact.prevent="handleSend"
          resize="none"
        />
        <el-button
          class="ai-widget__send"
          type="primary"
          circle
          :disabled="(!inputText.trim() && uploadedFiles.length === 0) || loading"
          @click="handleSend"
        >
          <el-icon><Promotion /></el-icon>
        </el-button>
      </div>
      <div class="ai-widget__footer">Enter 发送 · Shift + Enter 换行</div>
    </div>
  </div>
</template>

<script setup lang="ts">
import { ref, computed, onMounted } from 'vue'
import {
  FullScreen, Promotion, Close, Upload, Loading, Remove
} from '@element-plus/icons-vue'
import { ElMessage } from 'element-plus'
import {
  getTabConfigs, buildStreamUrl, uploadFile,
  type TabConfig, type ExampleTemplate
} from '@/api/ai/chat'

// 示例问题图标
const exampleIcons: string[] = ['💡', '📋', '🎯']

// 状态
const showMini = ref(false)
const loading = ref(false)
const activeTab = ref('chat')
const tabs = ref<TabConfig[]>([])
const inputText = ref('')
const lastUserQuestion = ref('')
const currentAnswer = ref('')
// 每个 tab 激活的模板 key（会议纪要等支持模板切换的 tab 使用）
const activeTemplateMap = ref<Record<string, string>>({})
// 文件上传状态
const uploading = ref(false)
const fileInputRef = ref<HTMLInputElement | null>(null)

// 已上传文件列表（会议纪要 Tab 使用）
interface UploadedFile {
  id: string
  fileName: string
  text: string
  size: number
  type: 'txt' | 'audio'
}
const uploadedFiles = ref<UploadedFile[]>([])

// 计算属性
const currentTab = computed(() => tabs.value.find(t => t.key === activeTab.value))
const currentTemplates = computed<ExampleTemplate[]>(() => currentTab.value?.templates || [])
const activeTemplateKey = computed<string | null>(() => {
  if (!currentTemplates.value.length) return null
  const stored = activeTemplateMap.value[activeTab.value]
  if (stored && currentTemplates.value.some(t => t.key === stored)) return stored
  return currentTemplates.value[0].key
})
const activeTemplate = computed<ExampleTemplate | null>(() =>
  activeTemplateKey.value ? currentTemplates.value.find(t => t.key === activeTemplateKey.value) || null : null
)
const currentTabExamples = computed<string[]>(() => {
  if (activeTemplate.value) return activeTemplate.value.examples
  return currentTab.value?.examples || []
})
const inputPlaceholder = computed(() => {
  const names: Record<string, string> = {
    chat: '请输入问题，与智聊对话...',
    translate: '请输入要翻译的内容...',
    meeting: '请描述会议相关信息...',
    writing: '请描述写作需求...'
  }
  return names[activeTab.value] || '请输入内容...'
})

const renderedAnswer = computed(() => renderMarkdown(currentAnswer.value))

// 方法
function renderMarkdown(text: string): string {
  if (!text) return ''
  // 简单 Markdown 渲染
  let html = text
  // 代码块
  html = html.replace(/```(\w*)\n([\s\S]*?)```/g, '<pre class="ai-md-code"><code>$2</code></pre>')
  // 粗体
  html = html.replace(/\*\*(.+?)\*\*/g, '<strong>$1</strong>')
  // 列表
  html = html.replace(/^\s*[-*]\s+(.+)$/gm, '<li>$1</li>')
  html = html.replace(/(<li>.*<\/li>\s*)+/g, '<ul>$&</ul>')
  // 有序列表
  html = html.replace(/^\s*\d+\.\s+(.+)$/gm, '<li>$1</li>')
  // 标题
  html = html.replace(/^### (.+)$/gm, '<h4>$1</h4>')
  html = html.replace(/^## (.+)$/gm, '<h3>$1</h3>')
  html = html.replace(/^# (.+)$/gm, '<h2>$1</h2>')
  // 表格
  html = html.replace(/^\|(.+)\|$/gm, '<tr>$1</tr>')
  html = html.replace(/(<tr>.*<\/tr>\s*)+/g, '<table class="ai-md-table">$&</table>')
  // 引用
  html = html.replace(/^>\s+(.+)$/gm, '<blockquote>$1</blockquote>')
  // 换行
  html = html.replace(/\n/g, '<br/>')
  return html
}

function switchTab(key: string) {
  activeTab.value = key
  // 切换 Tab 时清空当前对话
  lastUserQuestion.value = ''
  currentAnswer.value = ''
  // 如果新 Tab 支持模板且没有已记录的激活模板，默认选中第一个
  const tab = tabs.value.find(t => t.key === key)
  if (tab?.templates?.length && !activeTemplateMap.value[key]) {
    activeTemplateMap.value[key] = tab.templates[0].key
  }
}

function selectTemplate(tplKey: string) {
  if (loading.value) return
  activeTemplateMap.value[activeTab.value] = tplKey
}

function openMini() {
  showMini.value = true
}

function closeMini() {
  showMini.value = false
}

function openFullPage() {
  const routeData = window.location.origin + '/ai/chat'
  window.open(routeData, '_blank')
}

async function handleSend() {
  const userInput = inputText.value.trim()
  const hasFiles = uploadedFiles.value.length > 0
  if ((!userInput && !hasFiles) || loading.value) return

  // 拼接文件内容 + 用户输入
  let question = userInput
  if (hasFiles) {
    const fileTexts = uploadedFiles.value.map(f => {
      const label = f.type === 'audio' ? '语音转文字内容' : '文件内容'
      return `【${label} - ${f.fileName}】\n${f.text}`
    }).join('\n\n')
    if (userInput) {
      question = `${fileTexts}\n\n【用户问题】\n${userInput}`
    } else {
      question = fileTexts
    }
  }

  // 清空已上传文件
  uploadedFiles.value = []
  await sendMessage(question)
}

async function sendExample(example: string) {
  if (loading.value) return
  await sendMessage(example)
}

// 触发文件选择
function triggerFileInput() {
  if (uploading.value) return
  fileInputRef.value?.click()
}

// 处理文件上传
async function handleFileUpload(event: Event) {
  const target = event.target as HTMLInputElement
  const file = target.files?.[0]
  if (!file) return
  // 重置 input，允许重复选择同一文件
  target.value = ''

  const allowedExt = ['.txt', '.mp3', '.wav', '.m4a', '.aac', '.ogg', '.flac']
  const fileName = file.name.toLowerCase()
  if (!allowedExt.some(ext => fileName.endsWith(ext))) {
    ElMessage.warning('仅支持 .txt 和音频文件（mp3/wav/m4a/aac/ogg/flac）')
    return
  }

  uploading.value = true
  try {
    const res = await uploadFile(file)
    const text = res.data?.text || ''
    if (text) {
      const isAudio = !fileName.endsWith('.txt')
      uploadedFiles.value.push({
        id: Date.now() + Math.random().toString(36).slice(2, 6),
        fileName: res.data?.fileName || file.name,
        text,
        size: file.size,
        type: isAudio ? 'audio' : 'txt'
      })
      ElMessage.success(`文件「${res.data?.fileName || file.name}」已转换完成，可继续输入内容后发送`)
    } else {
      ElMessage.warning('文件内容为空')
    }
  } catch (e: any) {
    ElMessage.error(e?.message || '文件上传失败')
  } finally {
    uploading.value = false
  }
}

// 移除已上传的文件
function removeUploadedFile(id: string) {
  uploadedFiles.value = uploadedFiles.value.filter(f => f.id !== id)
}

// 格式化文件大小
function formatFileSize(bytes: number): string {
  if (bytes < 1024) return bytes + ' B'
  if (bytes < 1024 * 1024) return (bytes / 1024).toFixed(1) + ' KB'
  return (bytes / 1024 / 1024).toFixed(1) + ' MB'
}

async function sendMessage(question: string) {
  loading.value = true
  lastUserQuestion.value = question
  currentAnswer.value = ''
  inputText.value = ''

  try {
    const { url } = buildStreamUrl({
      question,
      type: activeTab.value
    })

    const eventSource = new EventSource(url)
    let buffer = ''

    eventSource.onmessage = (event) => {
      try {
        const data = JSON.parse(event.data)
        if (data.type === 'conversation' && data.conversationId) {
          // 小窗口不需要管理会话列表
        } else if (data.type === 'delta') {
          buffer += data.content
          currentAnswer.value = buffer
        } else if (data.type === 'complete') {
          currentAnswer.value = data.content || buffer
          eventSource.close()
        } else if (data.type === 'error') {
          currentAnswer.value = '❌ ' + data.content
          eventSource.close()
        }
      } catch (e) {
        console.error('SSE 解析错误', e)
      }
    }

    eventSource.onerror = () => {
      if (!currentAnswer.value && !buffer) {
        currentAnswer.value = '❌ 连接失败，请重试'
      }
      eventSource.close()
      loading.value = false
    }

    // 等待 5 分钟或直到关闭
    await new Promise<void>((resolve) => {
      const check = setInterval(() => {
        if (eventSource.readyState === EventSource.CLOSED) {
          clearInterval(check)
          resolve()
        }
      }, 500)
      setTimeout(() => { clearInterval(check); resolve() }, 300000)
    })
  } catch (e) {
    console.error('流式请求失败', e)
    currentAnswer.value = '❌ 请求失败，请检查网络后重试'
  } finally {
    loading.value = false
  }
}

// 初始化
onMounted(async () => {
  try {
    const res = await getTabConfigs()
    tabs.value = res.data || []
  } catch (e) {
    console.error('加载 Tab 配置失败', e)
    // 默认配置
    tabs.value = [
      { key: 'chat', name: '智聊', icon: '💬', examples: ['解读银行日常业务需要遵守的合规管理要求', '帮我梳理一下最近科技行业的发展趋势', '如何提升团队协作效率？有哪些实用方法'] },
      { key: 'translate', name: '翻译', icon: '🌐', examples: ['将这段中文翻译成地道的英文：人工智能正在改变世界', '翻译成日语：这份报告需要在下周五之前完成', '翻译成法语：欢迎来到我们的新产品发布会'] },
      { key: 'meeting', name: '会议纪要', icon: '📝', examples: ['生成一份季度董事会会议纪要模板', '帮我整理产品需求评审会的会议纪要', '生成项目启动会的会议纪要框架'] },
      { key: 'writing', name: '辅助写作', icon: '✍️', examples: ['帮我写一封正式的商务合作邀请函', '撰写一份年终总结报告的大纲', '写一篇关于数字化转型的公众号文章'] }
    ]
  }
})
</script>

<style scoped>
/* 小窗口样式 */
.ai-widget {
  position: fixed;
  bottom: 20px;
  right: 20px;
  z-index: 9999;
  font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
}

/* 悬浮入口按钮 */
.ai-widget__fab {
  position: fixed;
  bottom: 32px;
  right: 32px;
  width: 56px;
  height: 56px;
  border-radius: 50%;
  background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
  box-shadow: 0 4px 20px rgba(102, 126, 234, 0.4);
  display: flex;
  align-items: center;
  justify-content: center;
  cursor: pointer;
  transition: transform 0.3s ease, box-shadow 0.3s ease;
  z-index: 9999;
}

.ai-widget__fab:hover {
  transform: scale(1.1);
  box-shadow: 0 6px 28px rgba(102, 126, 234, 0.55);
}

.ai-widget__fab:active {
  transform: scale(0.95);
}

.ai-widget__fab-icon {
  font-size: 28px;
  line-height: 1;
  user-select: none;
}

.ai-widget__fab-pulse {
  position: absolute;
  top: 0;
  left: 0;
  width: 56px;
  height: 56px;
  border-radius: 50%;
  border: 2px solid rgba(102, 126, 234, 0.4);
  animation: fab-pulse 2s infinite;
  pointer-events: none;
}

@keyframes fab-pulse {
  0% {
    transform: scale(1);
    opacity: 0.8;
  }
  100% {
    transform: scale(1.6);
    opacity: 0;
  }
}

.ai-widget__mini {
  width: 420px;
  height: 520px;
  max-height: 80vh;
  background: #fff;
  border-radius: 16px;
  box-shadow: 0 8px 40px rgba(0, 0, 0, 0.12);
  overflow: hidden;
  border: 1px solid #e8e8e8;
  display: flex;
  flex-direction: column;
}

.ai-widget__header {
  display: flex;
  align-items: center;
  padding: 12px 16px 0;
  border-bottom: 1px solid #f0f0f0;
}

.ai-widget__tabs {
  display: flex;
  gap: 4px;
  flex: 1;
  overflow-x: auto;
}

.ai-widget__tab {
  display: flex;
  align-items: center;
  gap: 4px;
  padding: 8px 12px;
  border-radius: 8px 8px 0 0;
  cursor: pointer;
  font-size: 13px;
  color: #666;
  transition: all 0.2s;
  white-space: nowrap;
}

.ai-widget__tab:hover {
  background: #f5f5f5;
}

.ai-widget__tab.is-active {
  background: #f0f5ff;
  color: #1677ff;
  font-weight: 500;
}

.ai-widget__tab-icon {
  font-size: 14px;
}

.ai-widget__actions {
  display: flex;
  gap: 8px;
  padding-left: 8px;
}

.ai-widget__expand {
  cursor: pointer;
  color: #999;
  transition: color 0.2s;
}

.ai-widget__expand:hover {
  color: #1677ff;
}

.ai-widget__close-mini {
  cursor: pointer;
  color: #999;
  transition: color 0.2s;
}

.ai-widget__close-mini:hover {
  color: #f56c6c;
}

.ai-widget__body {
  flex: 1;
  padding: 16px;
  overflow-y: auto;
  display: flex;
  flex-direction: column;
  gap: 10px;
  min-height: 0;
}

.ai-widget__welcome {
  flex: 1;
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: center;
  min-height: 0;
}

.ai-widget__bubble {
  margin-bottom: 12px;
}

.ai-widget__typing {
  display: flex;
  gap: 4px;
}

.ai-widget__typing span {
  width: 8px;
  height: 8px;
  background: #ccc;
  border-radius: 50%;
  animation: bounce 1.4s infinite ease-in-out both;
}

.ai-widget__typing span:nth-child(1) { animation-delay: -0.32s; }
.ai-widget__typing span:nth-child(2) { animation-delay: -0.16s; }

@keyframes bounce {
  0%, 80%, 100% { transform: scale(0); }
  40% { transform: scale(1); }
}

.ai-widget__welcome-text {
  color: #666;
  font-size: 14px;
  margin-bottom: 16px;
}

.ai-widget__templates {
  display: flex;
  gap: 8px;
  margin-bottom: 14px;
  width: 100%;
}

.ai-widget__template {
  flex: 1;
  padding: 6px 10px;
  font-size: 12px;
  border-radius: 999px;
  border: 1px solid #e0e6ef;
  background: #fff;
  color: #555;
  cursor: pointer;
  text-align: center;
  transition: all 0.2s;
  user-select: none;
}

.ai-widget__template:hover {
  border-color: #1677ff;
  color: #1677ff;
}

.ai-widget__template.is-active {
  background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
  border-color: transparent;
  color: #fff;
  font-weight: 500;
  box-shadow: 0 2px 8px rgba(102, 126, 234, 0.25);
}

.ai-widget__examples {
  display: flex;
  flex-direction: column;
  gap: 8px;
  width: 100%;
}

.ai-widget__example {
  display: flex;
  align-items: center;
  gap: 8px;
  padding: 10px 12px;
  background: #f5f7fa;
  border-radius: 10px;
  cursor: pointer;
  transition: all 0.2s;
  font-size: 13px;
  color: #333;
}

.ai-widget__example:hover {
  background: #e8f0ff;
  transform: translateY(-1px);
}

.ai-widget__example-icon {
  font-size: 16px;
}

.ai-widget__chat {
  display: flex;
  flex-direction: column;
  gap: 12px;
}

.ai-widget__user-msg {
  display: flex;
  align-items: flex-start;
  gap: 8px;
  flex-direction: row-reverse;
}

.ai-widget__user-icon {
  font-size: 18px;
}

.ai-widget__user-text {
  background: #1677ff;
  color: #fff;
  padding: 8px 12px;
  border-radius: 12px 12px 2px 12px;
  max-width: 80%;
  word-break: break-word;
  font-size: 13px;
}

.ai-widget__assistant-msg {
  display: flex;
  align-items: flex-start;
  gap: 8px;
}

.ai-widget__ai-icon {
  font-size: 18px;
  flex-shrink: 0;
}

.ai-widget__ai-content {
  flex: 1;
  min-width: 0;
}

.ai-widget__markdown {
  background: #f5f7fa;
  padding: 10px 14px;
  border-radius: 4px 12px 12px 12px;
  font-size: 13px;
  line-height: 1.6;
  color: #333;
  word-break: break-word;
}

.ai-widget__markdown :deep(h2),
.ai-widget__markdown :deep(h3),
.ai-widget__markdown :deep(h4) {
  margin: 8px 0 4px;
  font-size: 14px;
}

.ai-widget__markdown :deep(ul),
.ai-widget__markdown :deep(ol) {
  padding-left: 20px;
  margin: 4px 0;
}

.ai-widget__markdown :deep(code) {
  background: #e8e8e8;
  padding: 2px 4px;
  border-radius: 4px;
  font-size: 12px;
}

.ai-widget__markdown :deep(blockquote) {
  border-left: 3px solid #1677ff;
  padding-left: 8px;
  color: #666;
  margin: 4px 0;
}

.ai-widget__markdown :deep(table) {
  width: 100%;
  border-collapse: collapse;
  margin: 8px 0;
}

.ai-widget__markdown :deep(td),
.ai-widget__markdown :deep(th) {
  border: 1px solid #ddd;
  padding: 6px 8px;
}

.ai-widget__input {
  padding: 12px 16px;
  border-top: 1px solid #f0f0f0;
  display: flex;
  gap: 8px;
  align-items: flex-end;
}

.ai-widget__file-input {
  display: none;
}

.ai-widget__upload-btn {
  display: flex;
  align-items: center;
  gap: 4px;
  padding: 6px 10px;
  border-radius: 8px;
  background: #f0f5ff;
  color: #1677ff;
  font-size: 12px;
  cursor: pointer;
  flex-shrink: 0;
  transition: all 0.2s;
  user-select: none;
  white-space: nowrap;
  height: 32px;
}

.ai-widget__upload-btn:hover {
  background: #e0ebff;
}

.ai-widget__upload-btn.is-disabled {
  opacity: 0.5;
  cursor: not-allowed;
}

/* 小窗口文件卡片 */
.ai-widget__file-list {
  display: flex;
  flex-direction: column;
  gap: 6px;
  padding: 8px 16px 4px;
  width: 100%;
  box-sizing: border-box;
  background: #fff;
  border-top: 1px solid #f0f0f0;
}

.ai-widget__file-card {
  display: flex;
  align-items: center;
  gap: 8px;
  padding: 8px 10px;
  background: #f0f9ff;
  border: 1px solid #bae6fd;
  border-radius: 8px;
  font-size: 12px;
  position: relative;
}

.ai-widget__file-type {
  font-size: 16px;
  flex-shrink: 0;
}

.ai-widget__file-info {
  flex: 1;
  min-width: 0;
  overflow: hidden;
}

.ai-widget__file-name {
  font-weight: 500;
  color: #0c4a6e;
  white-space: nowrap;
  overflow: hidden;
  text-overflow: ellipsis;
}

.ai-widget__file-meta {
  color: #64748b;
  font-size: 11px;
  margin-top: 2px;
}

.ai-widget__file-remove {
  cursor: pointer;
  color: #94a3b8;
  flex-shrink: 0;
  font-size: 14px;
  transition: color 0.2s;
}

.ai-widget__file-remove:hover {
  color: #ef4444;
}

.ai-widget__send {
  flex-shrink: 0;
}

.ai-widget__footer {
  text-align: center;
  padding: 4px 0 8px;
  font-size: 11px;
  color: #999;
}
</style>
