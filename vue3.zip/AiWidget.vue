<template>
  <div class="ai-widget">
    <!-- 悬浮入口按钮 -->
    <div v-if="!showMini" class="ai-widget__fab" @click="openMini">
      <div class="ai-widget__fab-icon">🤖</div>
      <div class="ai-widget__fab-pulse"></div>
    </div>

    <!-- 小窗口模式 -->
    <div v-if="showMini" class="ai-widget__mini">
      <!-- 顶部：主选项卡 + 三操作按钮 -->
      <div class="ai-widget__header">
        <div
          class="ai-widget__tab-primary"
          :class="{ 'is-active': activeTab === 'chat' }"
          @click="switchTab('chat')"
        >
          <span class="ai-widget__tab-primary-icon">💬</span>
          <span class="ai-widget__tab-primary-name">小信智聊</span>
        </div>
        <div class="ai-widget__actions">
          <el-tooltip content="播放视频" placement="bottom" :show-after="900">
            <el-icon class="ai-widget__action-btn" @click="handlePlayVideo" :size="20"><VideoPlay /></el-icon>
          </el-tooltip>
          <el-tooltip content="展开详情" placement="bottom" :show-after="300">
            <el-icon class="ai-widget__action-btn" @click="openFullPage" :size="20"><FullScreen /></el-icon>
          </el-tooltip>
          <el-tooltip content="关闭" placement="bottom" :show-after="300">
            <el-icon class="ai-widget__action-btn is-close" @click="closeMini" :size="20"><Close /></el-icon>
          </el-tooltip>
        </div>
      </div>

      <!-- 子选项卡行 -->
      <div class="ai-widget__tab-bar">
        <div
          v-for="tab in subTabs"
          :key="tab.key"
          class="ai-widget__tab"
          :class="{ 'is-active': activeTab === tab.key }"
          @click="switchTab(tab.key)"
        >
          <span class="ai-widget__tab-icon" :style="{ color: tabIconColors[tab.key] }">{{ tab.icon }}</span>
          <span class="ai-widget__tab-name">{{ tab.name }}</span>
        </div>
      </div>

      <div class="ai-widget__body">
        <!-- 欢迎区（无对话时显示） -->
        <div v-if="!currentAnswer && !loading" class="ai-widget__welcome">
          <div v-if="currentTemplates.length" class="ai-widget__templates">
            <div
              v-for="tpl in currentTemplates"
              :key="tpl.key"
              class="ai-widget__template"
              :class="{ 'is-active': activeTemplateKey === tpl.key }"
              @click="selectTemplate(tpl.key)"
            >
              {{ tpl.name }}
            </div>
          </div>
          <div class="ai-widget__examples">
            <div
              v-for="(example, idx) in currentTabExamples"
              :key="idx"
              class="ai-widget__example"
              @click="sendExample(example)"
            >
              <span class="ai-widget__example-icon">{{ getExampleIcon(idx) }}</span>
              <span class="ai-widget__example-text">{{ example }}</span>
            </div>
          </div>
        </div>

        <!-- 对话区 -->
        <div v-else class="ai-widget__chat">
          <div v-if="lastUserQuestion" class="ai-widget__user-msg">
            <span class="ai-widget__user-icon">😊</span>
            <span class="ai-widget__user-text">{{ lastUserQuestion }}</span>
          </div>
          <div class="ai-widget__assistant-msg">
            <span class="ai-widget__ai-icon">🤖</span>
            <div class="ai-widget__ai-content">
              <div v-if="loading && !currentAnswer" class="ai-widget__typing">
                <span></span><span></span><span></span>
              </div>
              <div v-else class="ai-widget__markdown" v-html="renderedAnswer"></div>
            </div>
          </div>
        </div>
      </div>

      <!-- 已上传文件卡片 -->
      <div v-if="uploadedFiles.length > 0" class="ai-widget__file-list">
        <div
          v-for="file in uploadedFiles"
          :key="file.id"
          class="ai-widget__file-card"
        >
          <span class="ai-widget__file-type">{{ file.type === 'audio' ? '🎵' : '📄' }}</span>
          <div class="ai-widget__file-info">
            <div class="ai-widget__file-name" :title="file.fileName">{{ file.fileName }}</div>
            <div class="ai-widget__file-meta">{{ file.type === 'audio' ? '音频文件' : '文本文件' }} · {{ formatFileSize(file.size) }}</div>
          </div>
          <el-icon class="ai-widget__file-remove" @click="removeUploadedFile(file.id)"><Remove /></el-icon>
        </div>
      </div>

      <!-- 输入区：+ 上传 | 文本框 + 发送按钮内嵌 -->
      <div class="ai-widget__input">
        <!-- 隐藏的文件选择 -->
        <input
          ref="fileInputRef"
          type="file"
          accept=".txt,.mp3,.wav,.m4a,.aac,.ogg,.flac"
          class="ai-widget__file-input"
          @change="handleFileUpload"
        />
        <!-- 上传按钮（仅会议纪要时显示） -->
        <el-tooltip
          v-if="activeTab === 'meeting'"
          :content="uploading ? '转换中...' : '上传文件'"
          placement="top"
          :show-after="200"
        >
          <div
            class="ai-widget__upload"
            :class="{ 'is-disabled': uploading || loading }"
            @click="triggerFileInput"
          >
            <el-icon v-if="!uploading"><Plus /></el-icon>
            <el-icon v-else class="is-loading"><Loading /></el-icon>
          </div>
        </el-tooltip>

        <!-- 文本框 + 内嵌发送按钮 -->
        <div class="ai-widget__input-box">
          <el-input
            v-model="inputText"
            type="textarea"
            :autosize="{ minRows: 2, maxRows: 4 }"
            :placeholder="inputPlaceholder"
            :disabled="loading"
            @keydown.enter.exact.prevent="handleSend"
            resize="none"
            class="ai-widget__textarea"
          />
          <el-button
            class="ai-widget__send"
            circle
            :disabled="(!inputText.trim() && uploadedFiles.length === 0) || loading"
            @click="handleSend"
          >
            <el-icon><Promotion /></el-icon>
          </el-button>
        </div>
      </div>
      <div class="ai-widget__footer">Enter 发送 · Shift + Enter 换行</div>
    </div>
  </div>
</template>

<script setup lang="ts">
import { ref, computed, onMounted } from 'vue'
import {
  FullScreen, Promotion, Close, Loading, Remove, Plus, VideoPlay
} from '@element-plus/icons-vue'
import { ElMessage } from 'element-plus'
import {
  getTabConfigs, buildStreamUrl, uploadFile,
  type TabConfig, type ExampleTemplate
} from '@/api/ai/chat'

// 每个选项卡的示例问题图标（按索引区分）
const exampleIconSets: Record<string, string[]> = {
  chat: ['💡', '🔍', '🎯'],
  translate: ['🌐', '🔤', '📖'],
  meeting: ['📝', '📋', '🎤'],
  writing: ['✍️', '📄', '📊']
}

function getExampleIcon(idx: number): string {
  const icons = exampleIconSets[activeTab.value] || exampleIconSets.chat
  return icons[idx % icons.length]
}

// 固定选项卡配置（名称不可变）
const subTabs = ref<TabConfig[]>([
  { key: 'translate', name: '翻译', icon: '🌐', examples: [] },
  { key: 'meeting', name: '会议纪要', icon: '📝', examples: [] },
  { key: 'writing', name: '辅助写作', icon: '✍️', examples: [] }
])

// 所有选项卡（含主选项卡小信智聊，用于后端数据匹配）
const allTabs = ref<TabConfig[]>([
  { key: 'chat', name: '小信智聊', icon: '💬', examples: [] },
  ...subTabs.value
])

// 选项卡图标颜色映射
const tabIconColors: Record<string, string> = {
  translate: '#3b82f6', // 蓝色
  meeting: '#f59e0b',   // 橙色
  writing: '#8b5cf6'    // 紫色
}

// 状态
const showMini = ref(false)
const loading = ref(false)
const activeTab = ref('chat')
const inputText = ref('')
const lastUserQuestion = ref('')
const currentAnswer = ref('')
// 每个 tab 激活的模板 key
const activeTemplateMap = ref<Record<string, string>>({})
// 文件上传状态
const uploading = ref(false)
const fileInputRef = ref<HTMLInputElement | null>(null)

// 已上传文件列表
interface UploadedFile {
  id: string
  fileName: string
  text: string
  size: number
  type: 'txt' | 'audio'
}
const uploadedFiles = ref<UploadedFile[]>([])

// 计算属性
const currentTab = computed(() => allTabs.value.find(t => t.key === activeTab.value))
const currentTemplates = computed<ExampleTemplate[]>(() => currentTab.value?.templates || [])
const activeTemplateKey = computed<string | null>(() => {
  if (!currentTemplates.value.length) return null
  const stored = activeTemplateMap.value[activeTab.value]
  if (stored && currentTemplates.value.some(t => t.key === stored)) return stored
  return currentTemplates.value[0].key
})
const activeTemplate = computed<ExampleTemplate | null>(() =>
  activeTemplateKey.value ? currentTemplates.value.find(t => t.key === activeTemplateKey.value) || null : null
)
const currentTabExamples = computed<string[]>(() => {
  if (activeTemplate.value) return activeTemplate.value.examples
  return currentTab.value?.examples || []
})
const inputPlaceholder = computed(() => {
  const names: Record<string, string> = {
    chat: '请输入问题，与智聊对话...',
    translate: '请输入要翻译的内容...',
    meeting: '请描述会议相关信息...',
    writing: '请描述写作需求...'
  }
  return names[activeTab.value] || '请输入内容...'
})

const renderedAnswer = computed(() => renderMarkdown(currentAnswer.value))

// 方法
function renderMarkdown(text: string): string {
  if (!text) return ''
  let html = text
  html = html.replace(/```(\w*)\n([\s\S]*?)```/g, '<pre class="ai-md-code"><code>$2</code></pre>')
  html = html.replace(/\*\*(.+?)\*\*/g, '<strong>$1</strong>')
  html = html.replace(/^\s*[-*]\s+(.+)$/gm, '<li>$1</li>')
  html = html.replace(/(<li>.*<\/li>\s*)+/g, '<ul>$&</ul>')
  html = html.replace(/^\s*\d+\.\s+(.+)$/gm, '<li>$1</li>')
  html = html.replace(/^### (.+)$/gm, '<h4>$1</h4>')
  html = html.replace(/^## (.+)$/gm, '<h3>$1</h3>')
  html = html.replace(/^# (.+)$/gm, '<h2>$1</h2>')
  html = html.replace(/^\|(.+)\|$/gm, '<tr>$1</tr>')
  html = html.replace(/(<tr>.*<\/tr>\s*)+/g, '<table class="ai-md-table">$&</table>')
  html = html.replace(/^>\s+(.+)$/gm, '<blockquote>$1</blockquote>')
  html = html.replace(/\n/g, '<br/>')
  return html
}

function switchTab(key: string) {
  activeTab.value = key
  lastUserQuestion.value = ''
  currentAnswer.value = ''
  const tab = allTabs.value.find(t => t.key === key)
  if (tab?.templates?.length && !activeTemplateMap.value[key]) {
    activeTemplateMap.value[key] = tab.templates[0].key
  }
}

function selectTemplate(tplKey: string) {
  if (loading.value) return
  activeTemplateMap.value[activeTab.value] = tplKey
}

function openMini() {
  showMini.value = true
}

function closeMini() {
  showMini.value = false
}

function openFullPage() {
  const routeData = window.location.origin + '/ai/chat'
  window.open(routeData, '_blank')
}

function handlePlayVideo() {
  ElMessage.info('播放视频功能待开发')
}

async function handleSend() {
  const userInput = inputText.value.trim()
  const hasFiles = uploadedFiles.value.length > 0
  if ((!userInput && !hasFiles) || loading.value) return

  let question = userInput
  if (hasFiles) {
    const fileTexts = uploadedFiles.value.map(f => {
      const label = f.type === 'audio' ? '语音转文字内容' : '文件内容'
      return `【${label} - ${f.fileName}】\n${f.text}`
    }).join('\n\n')
    if (userInput) {
      question = `${fileTexts}\n\n【用户问题】\n${userInput}`
    } else {
      question = fileTexts
    }
  }

  uploadedFiles.value = []
  await sendMessage(question)
}

async function sendExample(example: string) {
  if (loading.value) return
  await sendMessage(example)
}

function triggerFileInput() {
  if (uploading.value || activeTab.value !== 'meeting') return
  fileInputRef.value?.click()
}

async function handleFileUpload(event: Event) {
  const target = event.target as HTMLInputElement
  const file = target.files?.[0]
  if (!file) return
  target.value = ''

  const allowedExt = ['.txt', '.mp3', '.wav', '.m4a', '.aac', '.ogg', '.flac']
  const fileName = file.name.toLowerCase()
  if (!allowedExt.some(ext => fileName.endsWith(ext))) {
    ElMessage.warning('仅支持 .txt 和音频文件（mp3/wav/m4a/aac/ogg/flac）')
    return
  }

  uploading.value = true
  try {
    const res = await uploadFile(file)
    const text = res.data?.text || ''
    if (text) {
      const isAudio = !fileName.endsWith('.txt')
      uploadedFiles.value.push({
        id: Date.now() + Math.random().toString(36).slice(2, 6),
        fileName: res.data?.fileName || file.name,
        text,
        size: file.size,
        type: isAudio ? 'audio' : 'txt'
      })
      ElMessage.success(`文件「${res.data?.fileName || file.name}」已转换完成`)
    } else {
      ElMessage.warning('文件内容为空')
    }
  } catch (e: any) {
    ElMessage.error(e?.message || '文件上传失败')
  } finally {
    uploading.value = false
  }
}

function removeUploadedFile(id: string) {
  uploadedFiles.value = uploadedFiles.value.filter(f => f.id !== id)
}

function formatFileSize(bytes: number): string {
  if (bytes < 1024) return bytes + ' B'
  if (bytes < 1024 * 1024) return (bytes / 1024).toFixed(1) + ' KB'
  return (bytes / 1024 / 1024).toFixed(1) + ' MB'
}

// 按选项卡类型生成模拟回复（复用大页面相同内容逻辑，简化版）
function getMockReplySmall(type: string, question: string): string {
  const replies: Record<string, (q: string) => string> = {
    chat: (q) => `关于您的问题「${q}」，以下是我的解答：

**核心要点总结：**

1. **背景分析**：该问题涉及业务流程、合规要求、技术实现等多个维度，需要综合考量。
2. **建议方案**：
   - 明确问题边界和具体目标
   - 梳理流程节点和关键干系人
   - 制定分阶段的实施计划，确保风险可控
   - 定期回顾和调整策略
3. **风险提示**：注意数据安全、合规审查以及变更管理。
4. **后续动作**：建议先进行小范围试点，收集反馈后再逐步推广落地。

如需进一步细化某个环节，欢迎随时提问！`,
    translate: (q) => `以下是为您提供的翻译结果：

**原文**：${q.replace(/^将这段中文翻译成地道的英文：?|^翻译成[^：]*：?/g, '').trim()}

**译文 (English)**：
> Artificial intelligence is reshaping industries at an unprecedented pace, bringing profound changes to how we live and work.

**译文 (日本語)**：
> 人工知能は世界中の産業に前例のないスピードで浸透し、私たちの生活と仕事の在り方に根本的な変革をもたらしています。

如需调整翻译风格或增加其他语种，请告诉我。`,
    meeting: (q) => `📋 会议纪要整理如下：

**会议基本信息**
- 主题：${q.includes('模板') ? '季度董事会会议' : q.replace(/帮我整理|会议纪要|的|生成/g, '').trim() || '产品需求评审会议'}
- 时间：2026年8月XX日 14:00 - 16:00
- 参会：王XX（CEO）、陈XX（CTO）、刘XX（CFO）等

**主要内容**
1. 经营业绩回顾：营收增长12.5%，超预期
2. 关键项目进展：A项目进度75%，按计划推进
3. 下季度方向：重点发力AI产品线，加强客户成功
4. 风险提示：核心人才招聘进度滞后

**决议事项（Action Items）**
| 事项 | 负责人 | 截止日期 |
|------|--------|----------|
| 制定AI产品线规划 | CTO | 9月10日 |
| 启动专项招聘计划 | HRD | 8月30日 |
| 数据合规自查专项 | 法务部 | 9月15日 |

下次会议：9月5日跟进以上事项进度。`,
    writing: (q) => `以下是为您撰写的内容：

# ${q.includes('邀请函') ? '商务合作邀请函' : q.includes('总结') ? '年终总结报告' : q.includes('公众号') ? '数字化转型公众号文章' : '商务文书'}

${q.includes('邀请函') ? `
尊敬的[合作方名称]：

展信佳！诚挚邀请贵司参与我司于2026年9月18日（周五）举办的**「2026年度战略合作伙伴大会」**。

📌 **大会议程**：
- 14:00 主题演讲：行业趋势与市场机遇
- 15:30 战略合作签约仪式
- 18:00 答谢晚宴

📇 请于9月10日前联系客户成功经理报名。

期待与您携手，共创未来！

顺祝商祺！
[公司名称] 敬邀
` : ''}

${q.includes('总结') ? `
**一、年度业绩完成情况**
| 指标 | 目标 | 实际 | 完成率 |
|------|------|------|--------|
| 营收 | 1.2亿 | 1.35亿 | 112.5% |
| 新签客户 | 100家 | 128家 | 128% |

**二、重点成果**：完成C轮融资；荣获「最佳创新企业」奖。

**三、下年度计划**：营收同比增长30%；加大AI研发投入。

感谢全体同事的辛勤付出！
` : ''}

${q.includes('公众号') ? `
## 拥抱AI时代：企业数字化转型的三条法则

过去两年，数字化转型从「选择题」变成了「生存题」。我们服务300+客户后总结出三条法则：

🎯 **法则一**：业务价值优先，不要盲目追求技术先进性。
🚀 **法则二**：小步快跑，MVP+迭代，拒绝「一步到位」的大项目。
🧭 **法则三**：一把手工程 + 专业团队，缺一不可。

数字化转型是长征，没有终点，但每一步都算数。最重要的是——现在就开始。
` : ''}

如需调整方向、篇幅或补充具体信息，请告诉我。`
  }
  return (replies[type] || replies.chat)(question)
}

async function sendMessage(question: string) {
  loading.value = true
  lastUserQuestion.value = question
  currentAnswer.value = ''
  inputText.value = ''

  let realSuccess = false
  try {
    const { url } = buildStreamUrl({
      question,
      type: activeTab.value
    })

    const eventSource = new EventSource(url)
    let buffer = ''
    let realTimer: any = null

    // 设置3秒超时，无响应则走模拟
    const timeoutPromise = new Promise<null>((resolve) => {
      realTimer = setTimeout(() => {
        try { eventSource.close() } catch (e) {}
        resolve(null)
      }, 3000)
    })

    const ssePromise = new Promise<null>((resolve) => {
      eventSource.onmessage = (event) => {
        try {
          if (realTimer) { clearTimeout(realTimer); realTimer = null }
          realSuccess = true
          const data = JSON.parse(event.data)
          if (data.type === 'conversation' && data.conversationId) {
            // ignore
          } else if (data.type === 'delta') {
            buffer += data.content
            currentAnswer.value = buffer
          } else if (data.type === 'complete') {
            currentAnswer.value = data.content || buffer
            eventSource.close()
            resolve(null)
          } else if (data.type === 'error') {
            currentAnswer.value = '❌ ' + data.content
            eventSource.close()
            resolve(null)
          }
        } catch (e) {
          console.error('SSE 解析错误', e)
        }
      }

      eventSource.onerror = () => {
        try { eventSource.close() } catch (e) {}
        if (buffer && !currentAnswer.value) {
          currentAnswer.value = buffer
        }
        resolve(null)
      }
    })

    await Promise.race([ssePromise, timeoutPromise])
  } catch (e) {
    console.error('流式请求失败，使用模拟数据', e)
  }

  // 回退到模拟流式输出
  if (!realSuccess || !currentAnswer.value) {
    currentAnswer.value = ''
    const reply = getMockReplySmall(activeTab.value, question)
    const chars = reply.split('')
    let buf = ''
    while (chars.length > 0) {
      const chunkSize = Math.floor(Math.random() * 8) + 4
      const chunk = chars.splice(0, chunkSize).join('')
      buf += chunk
      currentAnswer.value = buf
      await new Promise(resolve => setTimeout(resolve, 30 + Math.random() * 40))
    }
  }

  loading.value = false
}

// 初始化
onMounted(async () => {
  try {
    const res = await getTabConfigs()
    const backendTabs = res.data || []
    backendTabs.forEach((bt: TabConfig) => {
      const tab = allTabs.value.find(t => t.key === bt.key)
      if (tab) {
        if (bt.examples?.length) tab.examples = bt.examples
        if (bt.templates?.length) tab.templates = bt.templates
      }
    })
  } catch (e) {
    console.error('加载 Tab 配置失败', e)
    const defaults: Record<string, string[]> = {
      chat: ['解读银行日常业务需要遵守的合规管理要求', '帮我梳理一下最近科技行业的发展趋势', '如何提升团队协作效率？有哪些实用方法'],
      translate: ['将这段中文翻译成地道的英文：人工智能正在改变世界', '翻译成日语：这份报告需要在下周五之前完成', '翻译成法语：欢迎来到我们的新产品发布会'],
      meeting: ['生成一份季度董事会会议纪要模板', '帮我整理产品需求评审会的会议纪要', '生成项目启动会的会议纪要框架'],
      writing: ['帮我写一封正式的商务合作邀请函', '撰写一份年终总结报告的大纲', '写一篇关于数字化转型的公众号文章']
    }
    allTabs.value.forEach(t => {
      if (!t.examples?.length) {
        t.examples = defaults[t.key] || []
      }
    })
  }
})
</script>

<style scoped>
/* 小窗口样式 */
.ai-widget {
  position: fixed;
  bottom: 20px;
  right: 20px;
  z-index: 9999;
  font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
}

/* 悬浮入口按钮 */
.ai-widget__fab {
  position: fixed;
  bottom: 32px;
  right: 32px;
  width: 56px;
  height: 56px;
  border-radius: 50%;
  background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
  box-shadow: 0 4px 20px rgba(102, 126, 234, 0.4);
  display: flex;
  align-items: center;
  justify-content: center;
  cursor: pointer;
  transition: transform 0.3s ease, box-shadow 0.3s ease;
  z-index: 9999;
}

.ai-widget__fab:hover {
  transform: scale(1.1);
  box-shadow: 0 6px 28px rgba(102, 126, 234, 0.55);
}

.ai-widget__fab:active {
  transform: scale(0.95);
}

.ai-widget__fab-icon {
  font-size: 28px;
  line-height: 1;
  user-select: none;
}

.ai-widget__fab-pulse {
  position: absolute;
  top: 0;
  left: 0;
  width: 56px;
  height: 56px;
  border-radius: 50%;
  border: 2px solid rgba(102, 126, 234, 0.4);
  animation: fab-pulse 2s infinite;
  pointer-events: none;
}

@keyframes fab-pulse {
  0% { transform: scale(1); opacity: 0.8; }
  100% { transform: scale(1.6); opacity: 0; }
}

.ai-widget__mini {
  width: 430px;
  height: 600px;
  max-height: 88vh;
  background: #fff;
  border-radius: 16px;
  box-shadow: 0 8px 40px rgba(0, 0, 0, 0.12);
  overflow: hidden;
  border: 1px solid #e8e8e8;
  display: flex;
  flex-direction: column;
}

/* ========== 顶部头部 ========== */
.ai-widget__header {
  display: flex;
  align-items: center;
  justify-content: space-between;
  padding: 10px 14px 8px;
  border-bottom: 1px solid #f0f0f0;
}

/* 主选项卡：小信智聊 */
.ai-widget__tab-primary {
  display: flex;
  align-items: center;
  gap: 6px;
  padding: 8px 18px;
  border-radius: 999px;
  cursor: pointer;
  font-size: 15px;
  font-weight: 600;
  color: #2563eb;
  background: #dbeafe;
  border: 1.5px solid #bfdbfe;
  transition: all 0.25s ease;
  user-select: none;
  box-shadow: 0 1px 4px rgba(37, 99, 235, 0.08);
}

.ai-widget__tab-primary:hover {
  background: #bfdbfe;
}

.ai-widget__tab-primary.is-active {
  color: #fff;
  background: #2563eb;
  border-color: #2563eb;
  box-shadow: 0 3px 10px rgba(37, 99, 235, 0.35);
}

.ai-widget__tab-primary-icon {
  font-size: 17px;
  line-height: 1;
}

.ai-widget__tab-primary-name {
  line-height: 1;
}

/* 操作按钮组 */
.ai-widget__actions {
  display: flex;
  gap: 6px;
  padding-left: 6px;
}

.ai-widget__action-btn {
  cursor: pointer;
  color: #9ca3af;
  transition: color 0.2s, transform 0.2s;
  padding: 6px;
  border-radius: 8px;
}

.ai-widget__action-btn:hover {
  color: #374151;
  background: #f3f4f6;
}

.ai-widget__action-btn.is-close:hover {
  color: #ef4444;
  background: #fee2e2;
}

/* ========== 子选项卡行 ========== */
.ai-widget__tab-bar {
  display: flex;
  padding: 8px 12px 6px;
  border-bottom: 1px solid #f0f0f0;
  gap: 6px;
}

.ai-widget__tab {
  display: flex;
  align-items: center;
  gap: 4px;
  padding: 5px 10px;
  border-radius: 999px;
  cursor: pointer;
  font-size: 12px;
  color: #666;
  transition: all 0.25s ease;
  white-space: nowrap;
  flex: 1;
  justify-content: center;
  background: #f5f5f5;
  border: 1px solid transparent;
}

.ai-widget__tab:hover {
  background: #e8e8e8;
  color: #333;
}

.ai-widget__tab.is-active {
  background: #fed7aa;
  color: #9a3412;
  font-weight: 500;
  border-color: #fdba74;
  box-shadow: 0 1px 4px rgba(249, 115, 22, 0.15);
}

.ai-widget__tab-icon {
  font-size: 14px;
  line-height: 1;
}

.ai-widget__tab.is-active .ai-widget__tab-icon {
  transform: scale(1.1);
}

/* ========== 内容区 ========== */
.ai-widget__body {
  flex: 1;
  padding: 8px 14px;
  overflow-y: auto;
  display: flex;
  flex-direction: column;
  gap: 6px;
  min-height: 0;
}

.ai-widget__welcome {
  flex: 1;
  display: flex;
  flex-direction: column;
  gap: 6px;
}

.ai-widget__templates {
  display: flex;
  gap: 8px;
  width: 100%;
  justify-content: center;
}

.ai-widget__template {
  flex: 1;
  padding: 5px 10px;
  font-size: 12px;
  border-radius: 999px;
  border: 1px solid #e0e6ef;
  background: #fff;
  color: #555;
  cursor: pointer;
  text-align: center;
  transition: all 0.2s;
  user-select: none;
  max-width: 160px;
}

.ai-widget__template:hover {
  border-color: #2563eb;
  color: #2563eb;
}

.ai-widget__template.is-active {
  background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
  border-color: transparent;
  color: #fff;
  font-weight: 500;
  box-shadow: 0 2px 8px rgba(102, 126, 234, 0.25);
}

.ai-widget__examples {
  display: flex;
  flex-direction: column;
  gap: 6px;
  width: 100%;
  align-items: center;
  margin-top: 80px;
}

.ai-widget__example {
  display: flex;
  align-items: center;
  justify-content: center;
  gap: 4px;
  padding: 10px 14px;
  background: #f5f7fa;
  border-radius: 10px;
  cursor: pointer;
  transition: all 0.2s;
  font-size: 13px;
  color: #333;
  width: 100%;
}

.ai-widget__example-text {
  text-align: left;
}

.ai-widget__example:hover {
  background: #e8f0ff;
  transform: translateY(-1px);
}

.ai-widget__example-icon {
  font-size: 15px;
  flex-shrink: 0;
}

/* ========== 对话区 ========== */
.ai-widget__chat {
  display: flex;
  flex-direction: column;
  gap: 12px;
}

.ai-widget__user-msg {
  display: flex;
  align-items: flex-start;
  gap: 8px;
  flex-direction: row-reverse;
}

.ai-widget__user-icon {
  font-size: 18px;
}

.ai-widget__user-text {
  background: #2563eb;
  color: #fff;
  padding: 8px 12px;
  border-radius: 12px 12px 2px 12px;
  max-width: 80%;
  word-break: break-word;
  font-size: 13px;
}

.ai-widget__assistant-msg {
  display: flex;
  align-items: flex-start;
  gap: 8px;
}

.ai-widget__ai-icon {
  font-size: 18px;
  flex-shrink: 0;
}

.ai-widget__ai-content {
  flex: 1;
  min-width: 0;
}

.ai-widget__markdown {
  background: #f5f7fa;
  padding: 10px 14px;
  border-radius: 4px 12px 12px 12px;
  font-size: 13px;
  line-height: 1.6;
  color: #333;
  word-break: break-word;
}

.ai-widget__markdown :deep(h2),
.ai-widget__markdown :deep(h3),
.ai-widget__markdown :deep(h4) {
  margin: 8px 0 4px;
  font-size: 14px;
}

.ai-widget__markdown :deep(ul),
.ai-widget__markdown :deep(ol) {
  padding-left: 20px;
  margin: 4px 0;
}

.ai-widget__markdown :deep(code) {
  background: #e8e8e8;
  padding: 2px 4px;
  border-radius: 4px;
  font-size: 12px;
}

.ai-widget__markdown :deep(blockquote) {
  border-left: 3px solid #2563eb;
  padding-left: 8px;
  color: #666;
  margin: 4px 0;
}

.ai-widget__markdown :deep(table) {
  width: 100%;
  border-collapse: collapse;
  margin: 8px 0;
}

.ai-widget__markdown :deep(td),
.ai-widget__markdown :deep(th) {
  border: 1px solid #ddd;
  padding: 6px 8px;
}

/* 打字动画 */
.ai-widget__typing {
  display: flex;
  gap: 4px;
}

.ai-widget__typing span {
  width: 8px;
  height: 8px;
  background: #ccc;
  border-radius: 50%;
  animation: bounce 1.4s infinite ease-in-out both;
}

.ai-widget__typing span:nth-child(1) { animation-delay: -0.32s; }
.ai-widget__typing span:nth-child(2) { animation-delay: -0.16s; }

@keyframes bounce {
  0%, 80%, 100% { transform: scale(0); }
  40% { transform: scale(1); }
}

/* ========== 文件卡片 ========== */
.ai-widget__file-list {
  display: flex;
  flex-direction: column;
  gap: 6px;
  padding: 6px 14px 4px;
  width: 100%;
  box-sizing: border-box;
  background: #fff;
}

.ai-widget__file-card {
  display: flex;
  align-items: center;
  gap: 8px;
  padding: 7px 10px;
  background: #f0f9ff;
  border: 1px solid #bae6fd;
  border-radius: 8px;
  font-size: 12px;
}

.ai-widget__file-type {
  font-size: 15px;
  flex-shrink: 0;
}

.ai-widget__file-info {
  flex: 1;
  min-width: 0;
  overflow: hidden;
}

.ai-widget__file-name {
  font-weight: 500;
  color: #0c4a6e;
  white-space: nowrap;
  overflow: hidden;
  text-overflow: ellipsis;
}

.ai-widget__file-meta {
  color: #64748b;
  font-size: 11px;
  margin-top: 2px;
}

.ai-widget__file-remove {
  cursor: pointer;
  color: #94a3b8;
  flex-shrink: 0;
  font-size: 14px;
  transition: color 0.2s;
}

.ai-widget__file-remove:hover {
  color: #ef4444;
}

/* ========== 输入区 ========== */
.ai-widget__input {
  padding: 8px 12px 10px;
  border-top: 1px solid #f0f0f0;
  display: flex;
  gap: 8px;
  align-items: flex-end;
}

.ai-widget__file-input {
  display: none;
}

/* + 上传按钮 */
.ai-widget__upload {
  display: flex;
  align-items: center;
  justify-content: center;
  width: 32px;
  height: 32px;
  border-radius: 8px;
  background: #f0f5ff;
  color: #2563eb;
  font-size: 18px;
  cursor: pointer;
  flex-shrink: 0;
  transition: all 0.2s;
  user-select: none;
}

.ai-widget__upload:hover:not(.is-disabled) {
  background: #dbeafe;
  transform: scale(1.05);
}

.ai-widget__upload.is-disabled {
  opacity: 0.4;
  cursor: not-allowed;
}

.ai-widget__upload .is-loading {
  animation: spin 1s linear infinite;
}

@keyframes spin {
  from { transform: rotate(0deg); }
  to { transform: rotate(360deg); }
}

/* 输入框容器（含内嵌发送按钮） */
.ai-widget__input-box {
  flex: 1;
  position: relative;
  display: flex;
  align-items: flex-end;
  border: 1px solid #e0e0e0;
  border-radius: 10px;
  background: #fff;
  transition: border-color 0.2s;
  padding: 2px 4px 2px 0;
}

.ai-widget__input-box:focus-within {
  border-color: #2563eb;
  box-shadow: 0 0 0 2px rgba(37, 99, 235, 0.1);
}

.ai-widget__textarea {
  flex: 1;
  padding: 6px 8px;
}

.ai-widget__textarea :deep(textarea) {
  font-size: 13px;
  line-height: 1.5;
  padding: 4px 6px;
  background: transparent;
  border: none !important;
  box-shadow: none !important;
}

.ai-widget__textarea :deep(.el-textarea__inner) {
  border: none !important;
  box-shadow: none !important;
}

/* 发送按钮（内嵌在输入框右侧） */
.ai-widget__send {
  flex-shrink: 0;
  width: 30px;
  height: 30px;
  background: #2563eb !important;
  border: none !important;
  box-shadow: 0 2px 6px rgba(37, 99, 235, 0.3);
  transition: all 0.2s ease;
  margin: 0;
}

.ai-widget__send:hover:not(:disabled) {
  transform: scale(1.08);
  box-shadow: 0 3px 10px rgba(37, 99, 235, 0.45);
}

.ai-widget__send:disabled {
  background: #d1d5db !important;
  box-shadow: none;
}

.ai-widget__footer {
  text-align: left;
  padding: 3px 12px 6px;
  font-size: 11px;
  color: #999;
}
</style>
