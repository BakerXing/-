<template>
  <div class="ai-chat-full">
    <div class="ai-full">
      <!-- 侧边栏 -->
      <aside class="ai-full__sidebar" :class="{ 'is-collapsed': sidebarCollapsed }">
        <div class="ai-full__sidebar-header">
          <div class="ai-full__brand">
            <span class="ai-full__brand-icon">🤖</span>
            <span v-if="!sidebarCollapsed" class="ai-full__brand-name">数智员工</span>
          </div>
        </div>

        <div v-if="!sidebarCollapsed" class="ai-full__new-chat" @click="handleNewChat">
          <el-icon><Plus /></el-icon>
          <span>新建对话</span>
        </div>

        <div v-if="!sidebarCollapsed" class="ai-full__search">
          <el-icon class="ai-full__search-icon"><Search /></el-icon>
          <input
            v-model="searchKeyword"
            type="text"
            class="ai-full__search-input"
            placeholder="搜索会话..."
          />
        </div>

        <div v-if="!sidebarCollapsed" class="ai-full__history-title">历史对话</div>

        <div class="ai-full__conversation-list" v-show="!sidebarCollapsed">
          <div
            v-for="conv, idx in displayedConversations"
            :key="conv.id"
            class="ai-full__conversation"
            :class="{ 'is-active': activeConversationId === conv.id, 'is-pinned': conv.isPinned === '1' }"
            @click="selectConversation(conv.id)"
          >
            <span class="ai-full__conv-type-icon">{{ getTabIcon(conv.type) }}</span>
            <div class="ai-full__conv-info">
              <span class="ai-full__conv-title">{{ conv.title }}</span>
            </div>
            <span class="ai-full__conv-time">{{ formatTime(conv.updateTime) }}</span>
            <div class="ai-full__conv-actions" @click.stop>
              <el-icon
                class="ai-full__action-btn"
                :title="conv.isPinned === '1' ? '取消置顶' : '置顶'"
                @click="handlePin(conv)"
              >
                <Star v-if="conv.isPinned !== '1'" />
                <StarFilled v-else />
              </el-icon>
              <el-icon class="ai-full__action-btn" title="删除" @click="handleDelete(conv)">
                <Delete />
              </el-icon>
            </div>
          </div>
          <div v-if="displayedConversations.length === 0" class="ai-full__empty">
            暂无对话记录
          </div>
          <div v-if="conversations.length > 20" class="ai-full__more-hint">
            仅显示最近20条会话
          </div>
        </div>

        <div v-if="sidebarCollapsed" class="ai-full__collapsed-list">
          <div
            v-for="conv in filteredConversations.slice(0, 5)"
            :key="conv.id"
            class="ai-full__collapsed-item"
            :class="{ 'is-active': activeConversationId === conv.id }"
            :title="conv.title"
            @click="selectConversation(conv.id)"
          >
            {{ getTabIcon(conv.type) }}
          </div>
        </div>

        <div class="ai-full__sidebar-footer">
          <el-icon
            class="ai-full__collapse-btn"
            :title="sidebarCollapsed ? '展开' : '收起'"
            @click="sidebarCollapsed = !sidebarCollapsed"
          >
            <DArrowLeft v-if="!sidebarCollapsed" />
            <DArrowRight v-else />
          </el-icon>
        </div>
      </aside>

      <!-- 聊天区 -->
      <main class="ai-full__chat">
        <!-- 选项卡行：所有选项卡并列一行 + 关闭按钮 -->
        <div class="ai-full__header">
          <div class="ai-full__tab-group">
            <div
              class="ai-full__tab-primary"
              :class="{ 'is-active': activeTab === 'chat' }"
              @click="switchTab('chat')"
            >
              <span class="ai-full__tab-primary-icon">💬</span>
              <span class="ai-full__tab-primary-name">小信智聊</span>
            </div>
            <span class="ai-full__tab-divider"></span>
            <template v-for="(tab, idx) in subTabs" :key="tab.key">
              <div
                class="ai-full__tab"
                :class="{ 'is-active': activeTab === tab.key }"
                @click="switchTab(tab.key)"
              >
                <span class="ai-full__tab-icon" :style="{ color: tabIconColors[tab.key] }">{{ tab.icon }}</span>
                <span class="ai-full__tab-name">{{ tab.name }}</span>
              </div>
             <span v-if="idx < subTabs.length - 1" class="ai-full__tab-divider3"></span>   
            </template>
          </div>
          <div class="ai-full__actions">
            <el-tooltip content="关闭" placement="bottom" :show-after="300">
              <el-icon class="ai-full__action-btn-top is-close" @click="goBack" :size="28"><Close /></el-icon>
            </el-tooltip>
          </div>
        </div>

        <!-- 内容区 -->
        <div class="ai-full__body" ref="chatBodyRef">
          <!-- 欢迎区（无对话时显示） -->
          <div v-if="currentMessages.length === 0" class="ai-full__welcome">
            <div v-if="currentTemplates.length" class="ai-full__templates">
              <div
                v-for="tpl in currentTemplates"
                :key="tpl.key"
                class="ai-full__template"
                :class="{ 'is-active': activeTemplateKey === tpl.key }"
                @click="selectTemplate(tpl.key)"
              >
                {{ tpl.name }}
              </div>
            </div>
            <div class="ai-full__examples">
              <div
                v-for="(example, idx) in currentTabExamples"
                :key="idx"
                class="ai-full__example"
                @click="sendExample(example)"
              >
                <span class="ai-full__example-icon">{{ getExampleIcon(idx) }}</span>
                <span class="ai-full__example-text">{{ example }}</span>
              </div>
            </div>
          </div>

          <!-- 对话区 -->
          <template v-else>
            <div v-for="(msg, idx) in currentMessages" :key="idx" class="ai-full__msg" :class="`is-${msg.role}`">
              <div class="ai-full__msg-avatar">
                {{ msg.role === 'user' ? '😊' : '🤖' }}
              </div>
              <div class="ai-full__msg-content">
                <div v-if="msg.role === 'assistant' && msg.content" class="ai-full__markdown" v-html="renderMarkdown(msg.content)"></div>
                <div v-else class="ai-full__text">{{ msg.content }}</div>
                <div v-if="msg.role === 'assistant' && loading && idx === currentMessages.length - 1 && msg.isComplete === '0'" class="ai-full__typing">
                  <span></span><span></span><span></span>
                </div>
              </div>
            </div>
          </template>

          <!-- 已上传文件卡片 -->
          <div v-if="uploadedFiles.length > 0" class="ai-full__file-list">
            <div
              v-for="file in uploadedFiles"
              :key="file.id"
              class="ai-full__file-card"
            >
              <span class="ai-full__file-type">{{ file.type === 'audio' ? '🎵' : '📄' }}</span>
              <div class="ai-full__file-info">
                <div class="ai-full__file-name" :title="file.fileName">{{ file.fileName }}</div>
                <div class="ai-full__file-meta">{{ file.type === 'audio' ? '音频文件' : '文本文件' }} · {{ formatFileSize(file.size) }}</div>
              </div>
              <el-icon class="ai-full__file-remove" @click="removeUploadedFile(file.id)"><Remove /></el-icon>
            </div>
          </div>
        </div>

        <!-- 输入区：+ 上传 | 文本框 + 发送按钮内嵌 -->
        <div class="ai-full__input">
          <!-- 隐藏的文件选择 -->
          <input
            ref="fileInputRef"
            type="file"
            accept=".txt,.mp3,.wav,.m4a,.aac,.ogg,.flac"
            class="ai-full__file-input"
            @change="handleFileUpload"
          />
          <!-- 上传按钮（仅会议纪要时显示） -->
          <template v-if="activeTab === 'meeting'">
            <el-tooltip
              :content="uploading ? '转换中...' : '上传文件'"
              placement="top"
              :show-after="200"
            >
              <div
                class="ai-full__upload"
                :class="{ 'is-disabled': uploading || loading }"
                @click="triggerFileInput"
              >
                <el-icon v-if="!uploading"><Plus /></el-icon>
                <el-icon v-else class="is-loading"><Loading /></el-icon>
              </div>
            </el-tooltip>
          </template>

          <!-- 文本框 + 内嵌发送按钮 -->
          <div class="ai-full__input-box">
            <el-input
              v-model="inputText"
              type="textarea"
              :autosize="{ minRows: 2, maxRows: 4 }"
              :placeholder="inputPlaceholder"
              :disabled="loading"
              @keydown.enter.exact.prevent="handleSend"
              resize="none"
              class="ai-full__textarea"
            />
            <el-button
              class="ai-full__send"
              circle
              :disabled="(!inputText.trim() && uploadedFiles.length === 0) || loading"
              @click="handleSend"
            >
              <el-icon><Promotion /></el-icon>
            </el-button>
          </div>
        </div>
        <div class="ai-full__footer">Enter 发送 · Shift + Enter 换行</div>
      </main>
    </div>
  </div>
</template>

<script setup lang="ts">
import { ref, computed, onMounted, nextTick } from 'vue'
import { useRouter } from 'vue-router'
import {
  Promotion, Plus, Star, StarFilled, Delete, Close, Loading, Remove,
  Search, DArrowLeft, DArrowRight
} from '@element-plus/icons-vue'
import { ElMessage, ElMessageBox } from 'element-plus'
import {
  listConversations, getMessages,
  deleteConversation, togglePin, buildStreamUrl, uploadFile,
  type AiConversation, type AiMessage, type TabConfig, type ExampleTemplate
} from '@/api/ai/chat'

const router = useRouter()

// 每个选项卡的示例问题图标（按索引区分）
const exampleIconSets: Record<string, string[]> = {
  chat: ['💡', '🔍', '🎯'],
  translate: ['🌐', '🔤', '📖'],
  meeting: ['📝', '📋', '🎤'],
  writing: ['✍️', '📄', '📊']
}

function getExampleIcon(idx: number): string {
  const icons = exampleIconSets[activeTab.value] || exampleIconSets.chat
  return icons[idx % icons.length]
}

// 固定子选项卡配置
const subTabs = ref<TabConfig[]>([
  { key: 'translate', name: '翻译', icon: '🌐', examples: [] },
  { key: 'meeting', name: '会议纪要', icon: '📝', examples: [] },
  { key: 'writing', name: '辅助写作', icon: '✍️', examples: [] }
])

// 所有选项卡（含主选项卡小信智聊）—— 示例问题使用前端固定值
const allTabs = ref<TabConfig[]>([
  {
    key: 'chat', name: '小信智聊', icon: '💬',
    examples: ['解读银行日常业务需要遵守的合规管理要求', '帮我梳理一下最近科技行业的发展趋势', '如何提升团队协作效率？有哪些实用方法']
  },
  {
    key: 'translate', name: '翻译', icon: '🌐',
    examples: ['将这段中文翻译成地道的英文：人工智能正在改变世界', '翻译成日语：这份报告需要在下周五之前完成', '翻译成法语：欢迎来到我们的新产品发布会']
  },
  {
    key: 'meeting', name: '会议纪要', icon: '📝',
    examples: ['生成一份季度董事会会议纪要模板', '帮我整理产品需求评审会的会议纪要', '生成项目启动会的会议纪要框架']
  },
  {
    key: 'writing', name: '辅助写作', icon: '✍️',
    examples: ['帮我写一封正式的商务合作邀请函', '撰写一份年终总结报告的大纲', '写一篇关于数字化转型的公众号文章']
  }
])

// 选项卡图标颜色映射
const tabIconColors: Record<string, string> = {
  translate: '#3b82f6',
  meeting: '#f59e0b',
  writing: '#8b5cf6'
}

// 会话类型图标映射
const tabIconMap: Record<string, string> = {
  chat: '💬',
  translate: '🌐',
  meeting: '📝',
  writing: '✍️'
}

function getTabIcon(type: string): string {
  return tabIconMap[type] || '💬'
}

// 状态
const loading = ref(false)
const activeTab = ref('chat')
const inputText = ref('')
const activeConversationId = ref<number | null>(null)
const conversations = ref<AiConversation[]>([])
const currentMessages = ref<AiMessage[]>([])
const chatBodyRef = ref<HTMLElement | null>(null)
const activeTemplateMap = ref<Record<string, string>>({})
const uploading = ref(false)
const fileInputRef = ref<HTMLInputElement | null>(null)
const sidebarCollapsed = ref(false)
const searchKeyword = ref('')

interface UploadedFile {
  id: string
  fileName: string
  text: string
  size: number
  type: 'txt' | 'audio'
}
const uploadedFiles = ref<UploadedFile[]>([])

const filteredConversations = computed(() => {
  if (!searchKeyword.value.trim()) return conversations.value
  const kw = searchKeyword.value.trim().toLowerCase()
  return conversations.value.filter(c =>
    c.title.toLowerCase().includes(kw)
  )
})

// 显示的会话列表：钉住的置顶，最多显示20条
const displayedConversations = computed(() => {
  const list = filteredConversations.value
  // 钉住的置顶
  const pinned = list.filter(c => c.isPinned === '1')
  const unpinned = list.filter(c => c.isPinned !== '1')
  const sorted = [...pinned, ...unpinned]
  // 最多显示20条
  return sorted.slice(0, 20)
})

// 当前钉住数量
const pinnedCount = computed(() => {
  return conversations.value.filter(c => c.isPinned === '1').length
})

const currentTab = computed(() => allTabs.value.find(t => t.key === activeTab.value))
const currentTemplates = computed<ExampleTemplate[]>(() => currentTab.value?.templates || [])
const activeTemplateKey = computed<string | null>(() => {
  if (!currentTemplates.value.length) return null
  const stored = activeTemplateMap.value[activeTab.value]
  if (stored && currentTemplates.value.some(t => t.key === stored)) return stored
  return currentTemplates.value[0].key
})
const activeTemplate = computed<ExampleTemplate | null>(() =>
  activeTemplateKey.value ? currentTemplates.value.find(t => t.key === activeTemplateKey.value) || null : null
)
const currentTabExamples = computed<string[]>(() => {
  if (activeTemplate.value) return activeTemplate.value.examples
  return currentTab.value?.examples || []
})
const inputPlaceholder = computed(() => {
  const names: Record<string, string> = {
    chat: '请输入问题，与智聊对话...',
    translate: '请输入要翻译的内容...',
    meeting: '请描述会议相关信息...',
    writing: '请描述写作需求...'
  }
  return names[activeTab.value] || '请输入内容...'
})

function renderMarkdown(text: string): string {
  if (!text) return ''
  let html = text
  html = html.replace(/```(\w*)\n([\s\S]*?)```/g, '<pre class="ai-md-code"><code>$2</code></pre>')
  html = html.replace(/\*\*(.+?)\*\*/g, '<strong>$1</strong>')
  html = html.replace(/^\s*[-*]\s+(.+)$/gm, '<li>$1</li>')
  html = html.replace(/(<li>.*<\/li>\s*)+/g, '<ul>$&</ul>')
  html = html.replace(/^\s*\d+\.\s+(.+)$/gm, '<li>$1</li>')
  html = html.replace(/^### (.+)$/gm, '<h4>$1</h4>')
  html = html.replace(/^## (.+)$/gm, '<h3>$1</h3>')
  html = html.replace(/^# (.+)$/gm, '<h2>$1</h2>')
  html = html.replace(/^\|(.+)\|$/gm, '<tr>$1</tr>')
  html = html.replace(/(<tr>.*<\/tr>\s*)+/g, '<table class="ai-md-table">$&</table>')
  html = html.replace(/^>\s+(.+)$/gm, '<blockquote>$1</blockquote>')
  html = html.replace(/\n/g, '<br/>')
  return html
}

function getMessagePreview(conv: AiConversation): string {
  // Simplified preview - could store last message in conversation
  return conv.type ? getTabIcon(conv.type) + ' 对话' : ''
}

function switchTab(key: string) {
  activeTab.value = key
  activeConversationId.value = null  // 复位：清空当前激活会话
  currentMessages.value = []
  inputText.value = ''
  uploadedFiles.value = []
  const tab = allTabs.value.find(t => t.key === key)
  if (tab?.templates?.length && !activeTemplateMap.value[key]) {
    activeTemplateMap.value[key] = tab.templates[0].key
  }
}

function selectTemplate(tplKey: string) {
  if (loading.value) return
  activeTemplateMap.value[activeTab.value] = tplKey
}

function goBack() {
  router.back()
}

async function loadConversations() {
  try {
    const res = await listConversations()
    conversations.value = res.data || []
  } catch (e) {
    console.error('加载会话列表失败', e)
  }
}

function selectConversation(id: number) {
  activeConversationId.value = id
  const conv = conversations.value.find(c => c.id === id)
  if (conv) {
    activeTab.value = conv.type
  }
  loadMessages(id)
}

async function loadMessages(id: number) {
  try {
    const res = await getMessages(id)
    currentMessages.value = res.data || []
    scrollToBottom()
  } catch (e) {
    console.error('加载消息失败', e)
  }
}

function handleNewChat() {
  activeConversationId.value = null
  currentMessages.value = []
  inputText.value = ''
}

async function handlePin(conv: AiConversation) {
  // 如果当前会话未钉住，检查是否已达到15个上限
  if (conv.isPinned !== '1' && pinnedCount.value >= 15) {
    ElMessage.warning('最多只能钉住15个会话')
    return
  }
  try {
    await togglePin(conv.id)
    await loadConversations()
    ElMessage.success(conv.isPinned === '1' ? '已取消置顶' : '已置顶')
  } catch (e: any) {
    ElMessage.error(e?.message || '操作失败')
  }
}

async function handleDelete(conv: AiConversation) {
  try {
    // 第一次确认
    await ElMessageBox.confirm(
      `确定要删除会话「${conv.title}」吗？此操作不可撤销。`,
      '删除确认',
      { type: 'warning', confirmButtonText: '确定删除', cancelButtonText: '取消' }
    )
    // 第二次确认（再确认一遍）
    await ElMessageBox.confirm(
      '再次提醒：删除后将无法恢复。真的确定删除该会话吗？',
      '最后确认',
      { type: 'error', confirmButtonText: '我已确认，执行删除', cancelButtonText: '我再想想' }
    )
    // 先尝试真实API删除
    try {
      await deleteConversation(conv.id)
    } catch (delErr: any) {
      console.warn('真实删除API失败，尝试本地模拟删除', delErr)
    }
    // 本地同步：无论成功与否都从内存列表移除（模拟删除生效）
    conversations.value = conversations.value.filter(c => c.id !== conv.id)
    if (activeConversationId.value === conv.id) {
      handleNewChat()
    }
    ElMessage.success('删除成功')
  } catch (e) {
    if (e !== 'cancel') ElMessage.error('删除失败')
  }
}

async function handleSend() {
  const userInput = inputText.value.trim()
  const hasFiles = uploadedFiles.value.length > 0
  if ((!userInput && !hasFiles) || loading.value) return

  let question = userInput
  if (hasFiles) {
    const fileTexts = uploadedFiles.value.map(f => {
      const label = f.type === 'audio' ? '语音转文字内容' : '文件内容'
      return `【${label} - ${f.fileName}】\n${f.text}`
    }).join('\n\n')
    if (userInput) {
      question = `${fileTexts}\n\n【用户问题】\n${userInput}`
    } else {
      question = fileTexts
    }
  }

  uploadedFiles.value = []
  await sendMessage(question)
}

async function sendExample(example: string) {
  if (loading.value) return
  await sendMessage(example)
}

function triggerFileInput() {
  if (uploading.value || activeTab.value !== 'meeting') return
  fileInputRef.value?.click()
}

async function handleFileUpload(event: Event) {
  const target = event.target as HTMLInputElement
  const file = target.files?.[0]
  if (!file) return
  target.value = ''

  const allowedExt = ['.txt', '.mp3', '.wav', '.m4a', '.aac', '.ogg', '.flac']
  const fileName = file.name.toLowerCase()
  if (!allowedExt.some(ext => fileName.endsWith(ext))) {
    ElMessage.warning('仅支持 .txt 和音频文件（mp3/wav/m4a/aac/ogg/flac）')
    return
  }

  uploading.value = true
  try {
    const res = await uploadFile(file)
    const text = res.data?.text || ''
    if (text) {
      const isAudio = !fileName.endsWith('.txt')
      uploadedFiles.value.push({
        id: Date.now() + Math.random().toString(36).slice(2, 6),
        fileName: res.data?.fileName || file.name,
        text,
        size: file.size,
        type: isAudio ? 'audio' : 'txt'
      })
      ElMessage.success(`文件「${res.data?.fileName || file.name}」已转换完成`)
    } else {
      ElMessage.warning('文件内容为空')
    }
  } catch (e: any) {
    ElMessage.error(e?.message || '文件上传失败')
  } finally {
    uploading.value = false
  }
}

function removeUploadedFile(id: string) {
  uploadedFiles.value = uploadedFiles.value.filter(f => f.id !== id)
}

function formatFileSize(bytes: number): string {
  if (bytes < 1024) return bytes + ' B'
  if (bytes < 1024 * 1024) return (bytes / 1024).toFixed(1) + ' KB'
  return (bytes / 1024 / 1024).toFixed(1) + ' MB'
}

// 按选项卡类型生成模拟回复内容
function getMockReply(type: string, question: string): string {
  const replies: Record<string, (q: string) => string> = {
    chat: (q) => `关于您的问题「${q}」，以下是我的解答：

**核心要点总结：**

1. **背景分析**：当前该问题涉及多方面的因素影响，需要从业务流程、合规要求、技术实现等多个维度综合考量。根据行业最佳实践，通常需要注意以下几个方面。

2. **建议方案**：
   - 首先明确问题的边界和具体目标
   - 梳理相关的流程节点和关键干系人
   - 制定分阶段的实施计划，确保风险可控
   - 定期回顾和调整策略

3. **风险提示**：在执行过程中需要特别注意数据安全、合规审查以及变更管理，避免对现有业务造成不必要的影响。

4. **后续动作**：建议根据实际情况，先进行小范围试点，收集反馈后再逐步推广落地。如需进一步细化某个环节，欢迎随时提问！`,
    translate: (q) => `以下是为您提供的翻译结果：

**原文**：${q.replace(/^将这段中文翻译成地道的英文：?|^翻译成[^：]*：?/g, '').trim()}

**译文 (English)**：
> Artificial intelligence is reshaping industries at an unprecedented pace, bringing profound changes to how we live and work. Organizations across the globe are embracing AI technologies to enhance productivity, optimize decision-making, and unlock new growth opportunities.

**译文 (日本語)**：
> 人工知能は世界中の産業に前例のないスピードで浸透し、私たちの生活と仕事の在り方に根本的な変革をもたらしています。企業は生産性の向上や意思決定の最適化、新たな成長機会の創出を目指して、AI技術の導入を加速させています。

**译文 (Français)**：
> L'intelligence artificielle transforme les industries à une vitesse sans précédent, apportant des changements profonds à notre façon de vivre et de travailler. Les entreprises du monde entier adoptent les technologies IA pour améliorer la productivité, optimiser la prise de décision et saisir de nouvelles opportunités de croissance.

如需调整翻译风格或增加其他语种，请告诉我。`,
    meeting: (q) => `为您生成会议纪要模板/整理如下：

# 📋 ${q.includes('模板') ? '季度董事会会议纪要（模板）' : '会议纪要'}

---

**会议基本信息**
- **会议主题**：${q.includes('模板') ? '2026年Q3季度董事会' : q.replace(/帮我整理|会议纪要|的|生成/g, '').trim() || '产品需求评审会议'}
- **会议时间**：2026年8月XX日（周五） 14:00 - 16:00
- **会议地点**：总部3楼会议室A / 线上腾讯会议
- **主持人**：张总
- **记录人**：李某某
- **参会人员**：王XX（CEO）、陈XX（CTO）、刘XX（CFO）、赵XX（COO）

---

## 一、会议议程

1. 季度经营业绩回顾
2. 关键项目进展汇报
3. 下季度战略方向讨论
4. 风险与问题梳理
5. 其他事项

## 二、会议主要内容

### 1. 季度经营业绩回顾
- 本季度整体营收较上季度增长12.5%，超出预期目标8%
- 新客户签约数达到58家，续约率维持在92%
- 成本控制表现良好，运营成本同比下降3.2%
- CFO提示：需关注汇率波动对海外收入的影响

### 2. 关键项目进展
- **项目A（数字化转型）**：进度75%，按计划推进，预计下月完成一期交付
- **项目B（新业务拓展）**：市场反馈积极，已完成3个试点城市的部署
- **项目C（系统升级）**：遇技术瓶颈，建议增加2名资深工程师支持

### 3. 下季度战略方向
✅ **共识要点**：
- 重点发力AI相关产品线，投入更多研发资源
- 加强客户成功团队建设，提升客户满意度
- 优化内部流程，启动新一轮降本增效工作

### 4. 风险与问题
⚠️ **识别到的风险项**：
- 核心技术人才招聘进度滞后（高）
- 供应链波动风险（中）
- 数据合规要求趋严（中）

---

## 三、决议事项（Action Items）

| 序号 | 事项 | 负责人 | 截止日期 | 优先级 |
|------|------|--------|----------|--------|
| 1 | 制定AI产品线详细规划 | CTO办公室 | 9月10日 | 高 |
| 2 | 启动核心岗位专项招聘计划 | HRD | 8月30日 | 高 |
| 3 | 项目C增派人手并评估延期 | 技术总监 | 8月28日 | 中 |
| 4 | 数据合规自查专项 | 法务部 | 9月15日 | 中 |

---

## 四、下次会议安排
- **时间**：2026年9月5日（周五） 14:00
- **待跟进**：以上4项Action Items进度汇报 + Q4预算初步讨论

> 💡 **说明**：如需调整模板内容或导出为Word/PDF格式，可继续告诉我。`,
    writing: (q) => `以下是为您撰写的内容：

# 📝 ${q.includes('邀请函') ? '商务合作邀请函' : q.includes('总结') ? '年终总结报告大纲' : q.includes('公众号') ? '数字化转型公众号文章' : '商务文书'}

---

${q.includes('邀请函') ? `
尊敬的[合作方名称] 阁下/女士：

展信佳！

首先，衷心感谢贵司长期以来对我司的关注与支持。值此[契机]之际，我们诚挚地邀请贵司参与我司于**2026年9月18日（周五）**在[城市][酒店名称]举办的**「2026年度战略合作伙伴大会」**，共同探讨行业发展趋势，深化双方战略合作。

## 📌 大会看点

1. **主题演讲**：行业权威专家解读最新政策趋势与市场机遇
2. **案例分享**：头部客户数字化转型实战经验拆解
3. **战略合作签约**：见证重要合作伙伴战略签约仪式
4. **一对一洽谈**：专属商务洽谈时段，深度对接合作机会
5. **答谢晚宴**：精心筹备的交流晚宴与抽奖环节

## ⏰ 会议日程安排

| 时间 | 环节 | 内容 |
|------|------|------|
| 13:30 - 14:00 | 签到入场 | 领取资料包、合影留念 |
| 14:00 - 14:20 | 开场致辞 | 董事长致欢迎词 |
| 14:20 - 15:30 | 主题分享 | 行业趋势 & 产品战略 |
| 15:30 - 15:50 | 茶歇交流 | 自由交流 & 展厅参观 |
| 15:50 - 17:00 | 圆桌论坛 | 头部客户高管对话 |
| 17:00 - 17:30 | 战略合作签约 | 签约仪式 & 合影 |
| 18:00 - 20:30 | 答谢晚宴 | 晚宴 & 节目表演 & 抽奖 |

## 📇 报名方式

请于 **2026年9月10日** 前通过以下方式联系我们：
- 联系人：[客户成功经理姓名]
- 电话：[电话号码]
- 邮箱：[邮箱地址]

期待与您共襄盛举，携手开创未来！

顺祝商祺！

_______________

[公司名称]
[董事长姓名] 敬邀
2026年8月25日
` : ''}

${q.includes('总结') ? `
## 一、年度工作概述

### 1.1 工作背景与核心目标
- 回顾年初设定的三大战略目标
- 所处行业环境变化及应对

### 1.2 关键业绩指标（KPIs）完成情况

| 指标 | 目标值 | 实际完成 | 完成率 | 同比变化 |
|------|--------|----------|--------|----------|
| 营业收入 | 1.2亿 | 1.35亿 | 112.5% | +23.6% |
| 新签客户数 | 100家 | 128家 | 128% | +35% |
| 客户满意度 | ≥90分 | 94分 | 达标 | +3分 |
| 产品交付准时率 | ≥95% | 97.2% | 达标 | +2.1% |

### 1.3 重大里程碑事件
- 🎯 完成C轮融资，估值突破XX亿
- 🏆 荣获「年度最佳创新企业」奖
- 🚀 AI产品线正式商用，客户反馈超预期
- 🌍 海外市场拓展至东南亚5个国家

---

## 二、重点工作成果

### 2.1 产品与研发
1. 完成3个大版本迭代，新增功能120+项
2. 核心系统性能提升45%，稳定性达99.99%
3. 申请发明专利8项，软件著作权15项

### 2.2 市场与销售
- 华东、华南大区超额完成目标
- 战略客户签约率同比提升18%

### 2.3 组织与人才
- 员工规模从200人增长至310人
- 核心人才保留率维持94%

---

## 三、存在的问题与不足

### 3.1 主要挑战
| 问题 | 影响程度 | 原因分析 |
|------|----------|----------|
| 产品交付压力 | 高 | 需求增长快于产能 |
| 跨部门协作效率 | 中 | 流程待优化 |
| 中高端人才缺口 | 高 | 招聘周期较长 |

### 3.2 改进方向
1. 建立标准化交付体系，引入外部供应商
2. 优化内部协作流程，上线跨部门协同平台
3. 启动「核心人才计划」，拓宽招聘渠道

---

## 四、下一年度工作计划

### 4.1 核心目标
- **营收目标**：同比增长30%，突破1.75亿
- **产品战略**：全面升级AI产品线，打造行业标杆案例
- **组织建设**：完善梯队，员工规模达到450人

### 4.2 重点战略举措
1. ▶️ **战略一**：深耕核心赛道，聚焦三大重点行业
2. ▶️ **战略二**：加大AI研发投入，保持技术领先优势
3. ▶️ **战略三**：国际化战略升级，设立新加坡海外总部

### 4.3 资源需求与风险预案
（略）

---

## 五、致谢
感谢全体同事的辛勤付出，感谢管理层的英明决策！
` : ''}

${q.includes('公众号') ? `
# 拥抱AI时代：企业数字化转型的三条「生存法则」

> 从「要不要转」到「怎么转对」，这篇文章分享我们在服务了300+企业客户后总结出的实战心得。

---

## 🌱 一、别再问「要不要做数字化」了

前阵子跟一位制造业的老板喝茶，他叹了口气说：「去年我还在犹豫要不要上系统，今年同行已经在用AI质检省了30%的人力了，我再不追就真的晚了。」

这不是个例。

过去两年，**数字化转型从「选择题」变成了「生存题」**。但真正的难点不是认知，而是「知道要做，但不知道怎么做才对」。

根据我们服务的300+家企业客户数据：
- **72%** 的企业有转型意愿
- **但只有28%** 真正完成了第一阶段落地
- **其中仅15%** 实现了预期的降本增效

差距在哪？我们总结出三条核心法则。

---

## 🎯 法则一：业务价值优先，而非「技术先进性优先」

很多企业容易陷入一个误区——选最热门的技术、买最高配的系统，结果装上去发现跟业务流程根本不匹配。

**一个真实的反例**：
某连锁餐饮企业花200万上线了一套非常「先进」的ERP系统，光是培训员工就花了3个月。结果一线门店怨声载道：原本30秒能录完的单，现在要走5个步骤。最后系统只用到了不到20%的功能。

**正确的打开方式**：
✅ 先梳理**业务痛点清单**，按ROI排序
✅ 选择**能解决TOP3痛点**的最轻量方案
✅ 先用起来，再逐步迭代升级

> 💡 我们的客户实践：从「收银效率」切入，3周上线AI点单系统，单店人效提升25%，之后再扩展到库存、会员。

---

## 🚀 法则二：小步快跑，拒绝「一步到位式」大项目

很多CIO喜欢制定「5年规划、1年落地」的大蓝图。但现实是——
- 业务环境半年一变
- 技术栈年年更新
- 关键 stakeholder 可能已经换了三波

**建议采用「MVP + 迭代」模式**：

| 阶段 | 周期 | 目标 | 产出物 |
|------|------|------|--------|
| 试点 | 4-6周 | 验证核心价值 | 一个可运行的MVP |
| 推广 | 2-3月 | 扩展到核心部门 | 推广手册+KPI数据 |
| 深化 | 3-6月 | 打通数据孤岛 | 数据中台雏形 |
| 全面落地 | 长期 | 组织级变革 | 数字化考核体系 |

「小步快跑」的本质是**用快速的正向反馈来换取组织内部的信心和支持**——这才是转型最稀缺的资源。

---

## 🧭 法则三：一把手工程 + 专业团队，缺一不可

我们见过太多失败案例，根因不是技术，而是**组织阻力**。

数字化转型本质上是**一场组织变革**，它必然涉及：
- 流程的重构
- 权力的重新分配
- 利益格局的调整

没有一把手的坚定支持，这些根本推不动。而一把手的支持，不应该只是在启动会上说两句空话，而是要：

1. **亲自挂帅**担任转型委员会主席
2. **把数字化指标**纳入各部门KPI考核
3. **在关键节点**站出来拍板、站台、扛压力

同时，必须有**专业的团队**来执行——不管是内部组建还是外部引入，核心是**既懂业务又懂技术**的复合型人才。

---

## 📮 写在最后

数字化转型从来不是一个「项目」，而是一次「长征」。

它没有终点，但每一步都算数。

最重要的，是**现在就开始**。

如果您的企业正处在转型的十字路口，欢迎留言交流。我们乐于把服务300+客户积累的方法论和踩过的坑，分享给正在路上的你。

---

**👉 如果觉得有用，请点赞 + 在看 + 转发三连！欢迎关注我们的公众号，每周分享一篇数字化实战干货。**
` : ''}

如需调整内容方向、篇幅、风格，或补充具体信息（公司名、日期、人名等），请继续告诉我。`
  }
  return (replies[type] || replies.chat)(question)
}

// 模拟流式输出
async function mockStreamOutput(type: string, question: string) {
  const reply = getMockReply(type, question)
  const chars = reply.split('')
  const total = chars.length
  let buffer = ''
  // 每8-15个字分批输出，模拟真实的打字机效果
  while (chars.length > 0) {
    const chunkSize = Math.floor(Math.random() * 8) + 4  // 4-11字/批
    const chunk = chars.splice(0, chunkSize).join('')
    buffer += chunk
    if (currentMessages.value.length > 0) {
      const lastMsg = currentMessages.value[currentMessages.value.length - 1]
      if (lastMsg.role === 'assistant') {
        lastMsg.content = buffer
      }
    }
    scrollToBottom()
    await new Promise(resolve => setTimeout(resolve, 30 + Math.random() * 40))
  }
  // 模拟conversationId生成（首次对话）
  if (!activeConversationId.value) {
    activeConversationId.value = Number('9' + String(Date.now()).slice(-8))
    // 插入模拟会话到列表
    conversations.value.unshift({
      id: activeConversationId.value,
      title: question.length > 20 ? question.slice(0, 20) + '...' : question,
      type: activeTab.value,
      isPinned: '0',
      createTime: new Date().toISOString(),
      updateTime: new Date().toISOString()
    })
  } else {
    // 更新已有会话的时间
    const conv = conversations.value.find(c => c.id === activeConversationId.value)
    if (conv) conv.updateTime = new Date().toISOString()
  }
  // 标记完成
  if (currentMessages.value.length > 0) {
    const lastMsg = currentMessages.value[currentMessages.value.length - 1]
    if (lastMsg.role === 'assistant') {
      lastMsg.isComplete = '1'
    }
  }
  // 保存模拟消息（如果有激活会话）
  if (activeConversationId.value) {
    // 简单本地模拟保存：最后两条消息（用户+助手）已push到currentMessages
  }
}

async function sendMessage(question: string) {
  loading.value = true
  inputText.value = ''

  currentMessages.value.push({
    id: Date.now(),
    conversationId: activeConversationId.value || 0,
    role: 'user',
    content: question,
    type: activeTab.value,
    isComplete: '1',
    createTime: new Date().toISOString()
  })
  currentMessages.value.push({
    id: Date.now() + 1,
    conversationId: activeConversationId.value || 0,
    role: 'assistant',
    content: '',
    type: activeTab.value,
    isComplete: '0',
    createTime: new Date().toISOString()
  })
  scrollToBottom()

  // 优先尝试真实SSE连接，失败则自动回退到模拟流式输出
  let realSuccess = false
  try {
    const { url } = buildStreamUrl({
      question,
      conversationId: activeConversationId.value || undefined,
      type: activeTab.value
    })

    const eventSource = new EventSource(url)
    let buffer = ''
    let realTimer: any = null

    // 设置3秒超时：如果真实SSE没响应，自动走模拟
    const timeoutPromise = new Promise<null>((resolve) => {
      realTimer = setTimeout(() => {
        try { eventSource.close() } catch (e) {}
        resolve(null)
      }, 3000)
    })

    const ssePromise = new Promise<null>((resolve) => {
      eventSource.onmessage = (event) => {
        try {
          if (realTimer) { clearTimeout(realTimer); realTimer = null }
          realSuccess = true
          const data = JSON.parse(event.data)
          if (data.type === 'conversation' && data.conversationId) {
            activeConversationId.value = data.conversationId
            loadConversations()
          } else if (data.type === 'delta') {
            buffer += data.content
            if (currentMessages.value.length > 0) {
              const lastMsg = currentMessages.value[currentMessages.value.length - 1]
              if (lastMsg.role === 'assistant') {
                lastMsg.content = buffer
              }
            }
            scrollToBottom()
          } else if (data.type === 'complete') {
            if (currentMessages.value.length > 0) {
              const lastMsg = currentMessages.value[currentMessages.value.length - 1]
              if (lastMsg.role === 'assistant') {
                lastMsg.content = data.content || buffer
                lastMsg.isComplete = '1'
              }
            }
            eventSource.close()
            resolve(null)
          } else if (data.type === 'error') {
            if (currentMessages.value.length > 0) {
              const lastMsg = currentMessages.value[currentMessages.value.length - 1]
              if (lastMsg.role === 'assistant') {
                lastMsg.content = '❌ ' + data.content
                lastMsg.isComplete = '1'
              }
            }
            eventSource.close()
            resolve(null)
          }
        } catch (e) {
          console.error('SSE 解析错误', e)
        }
      }

      eventSource.onerror = () => {
        try { eventSource.close() } catch (e) {}
        if (buffer && currentMessages.value.length > 0) {
          const lastMsg = currentMessages.value[currentMessages.value.length - 1]
          if (lastMsg.role === 'assistant' && !lastMsg.content) {
            lastMsg.content = buffer
          }
        }
        resolve(null)
      }
    })

    await Promise.race([ssePromise, timeoutPromise])
  } catch (e) {
    console.error('流式请求失败，使用模拟数据', e)
  }

  // 如果真实SSE未输出有效内容，则使用模拟流式输出
  const lastMsg = currentMessages.value[currentMessages.value.length - 1]
  if (!realSuccess || !lastMsg || !lastMsg.content) {
    if (lastMsg) lastMsg.content = ''  // 清空可能的错误占位
    await mockStreamOutput(activeTab.value, question)
  }

  loading.value = false
  await loadConversations()
}

function scrollToBottom() {
  nextTick(() => {
    if (chatBodyRef.value) {
      chatBodyRef.value.scrollTop = chatBodyRef.value.scrollHeight
    }
  })
}

function formatTime(timeStr: string) {
  if (!timeStr) return ''
  const d = new Date(timeStr)
  const now = new Date()
  const diff = now.getTime() - d.getTime()
  if (diff < 60000) return '刚刚'
  if (diff < 3600000) return `${Math.floor(diff / 60000)} 分钟前`
  if (diff < 86400000) return `${Math.floor(diff / 3600000)} 小时前`
  return `${d.getMonth() + 1}/${d.getDate()} ${String(d.getHours()).padStart(2, '0')}:${String(d.getMinutes()).padStart(2, '0')}`
}

onMounted(async () => {
  // 示例问题使用前端固定值，无需后端获取
  await loadConversations()
})
</script>

<style scoped>
/* ========== 大页面容器 ========== */
.ai-chat-full {
  position: fixed;
  inset: 0;
  z-index: 9999;
  background: #f5f7fa;
  display: flex;
  justify-content: center;
  padding: 20px;
  box-sizing: border-box;
}

.ai-full {
  display: flex;
  width: 90%;
  height: 100%;
  background: #fff;
  border-radius: 16px;
  box-shadow: 0 8px 40px rgba(0, 0, 0, 0.08);
  overflow: hidden;
  border: 1px solid #e8e8e8;
}

/* ========== 侧边栏 ========== */
.ai-full__sidebar {
  width: 260px;
  background: #fff;
  border-right: 1px solid #e8e8e8;
  display: flex;
  flex-direction: column;
  overflow: hidden;
  transition: width 0.3s ease;
  flex-shrink: 0;
}

.ai-full__sidebar.is-collapsed {
  width: 60px;
}

.ai-full__sidebar-header {
  padding: 16px 14px 12px;
  border-bottom: 1px solid #f0f0f0;
}

.ai-full__brand {
  display: flex;
  align-items: center;
  gap: 10px;
}

.ai-full__brand-icon {
  font-size: 22px;
  flex-shrink: 0;
}

.ai-full__brand-name {
  font-size: 16px;
  font-weight: 600;
  color: #1f2937;
  white-space: nowrap;
}

.ai-full__new-chat {
  margin: 12px;
  padding: 10px 12px;
  background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
  color: #fff;
  border-radius: 10px;
  cursor: pointer;
  display: flex;
  align-items: center;
  justify-content: center;
  gap: 8px;
  font-weight: 500;
  font-size: 14px;
  transition: opacity 0.2s, transform 0.2s;
  flex-shrink: 0;
}

.ai-full__new-chat:hover {
  opacity: 0.92;
  transform: translateY(-1px);
}

.ai-full__search {
  margin: 0 12px 8px;
  position: relative;
  flex-shrink: 0;
}

.ai-full__search-icon {
  position: absolute;
  left: 10px;
  top: 50%;
  transform: translateY(-50%);
  color: #9ca3af;
  font-size: 14px;
  z-index: 1;
}

.ai-full__search-input {
  width: 100%;
  padding: 8px 10px 8px 32px;
  border: 1px solid #e5e7eb;
  border-radius: 8px;
  font-size: 13px;
  background: #f9fafb;
  outline: none;
  transition: border-color 0.2s, background 0.2s;
  box-sizing: border-box;
}

.ai-full__search-input:focus {
  border-color: #2563eb;
  background: #fff;
}

.ai-full__history-title {
  padding: 8px 12px 6px;
  font-size: 12px;
  color: #9ca3af;
  font-weight: 500;
  flex-shrink: 0;
}

.ai-full__conversation-list {
  flex: 1;
  overflow-y: auto;
  padding: 0 8px;
}

.ai-full__conversation-list::-webkit-scrollbar {
  width: 4px;
}

.ai-full__conversation-list::-webkit-scrollbar-thumb {
  background: #d1d5db;
  border-radius: 2px;
}

.ai-full__conversation {
  display: flex;
  align-items: center;
  gap: 8px;
  padding: 10px 10px;
  border-radius: 10px;
  cursor: pointer;
  font-size: 13px;
  transition: background 0.2s;
  position: relative;
}

.ai-full__conversation:hover {
  background: #f5f7fa;
}

.ai-full__conversation.is-active {
  background: #eff6ff;
  color: #1d4ed8;
}

.ai-full__conversation.is-pinned {
  background: #fffbe6;
}

.ai-full__conv-type-icon {
  font-size: 16px;
  flex-shrink: 0;
}

.ai-full__conv-info {
  flex: 1;
  min-width: 0;
  display: flex;
  flex-direction: column;
  gap: 2px;
}

.ai-full__conv-title {
  font-size: 13px;
  color: #1f2937;
  white-space: nowrap;
  overflow: hidden;
  text-overflow: ellipsis;
  font-weight: 500;
}

.ai-full__conversation.is-active .ai-full__conv-title {
  color: #1d4ed8;
}

.ai-full__conv-preview {
  font-size: 11px;
  color: #9ca3af;
  white-space: nowrap;
  overflow: hidden;
  text-overflow: ellipsis;
}

.ai-full__conv-time {
  font-size: 11px;
  color: #9ca3af;
  flex-shrink: 0;
}

.ai-full__conv-actions {
  display: none;
  gap: 4px;
  position: absolute;
  right: 8px;
  top: 50%;
  transform: translateY(-50%);
  background: #fff;
  border-radius: 6px;
  padding: 2px;
  box-shadow: 0 2px 8px rgba(0, 0, 0, 0.1);
}

.ai-full__conversation:hover .ai-full__conv-actions {
  display: flex;
}

.ai-full__action-btn {
  color: #9ca3af;
  font-size: 14px;
  padding: 3px;
  border-radius: 4px;
  transition: color 0.2s, background 0.2s;
}

.ai-full__action-btn:hover {
  color: #1677ff;
  background: #f0f5ff;
}

.ai-full__empty {
  text-align: center;
  color: #9ca3af;
  padding: 40px 0;
  font-size: 13px;
}

/* 侧边栏折叠状态 */
.ai-full__collapsed-list {
  flex: 1;
  overflow-y: auto;
  padding: 8px;
  display: flex;
  flex-direction: column;
  gap: 6px;
}

.ai-full__collapsed-item {
  width: 36px;
  height: 36px;
  display: flex;
  align-items: center;
  justify-content: center;
  border-radius: 8px;
  cursor: pointer;
  font-size: 16px;
  transition: background 0.2s;
}

.ai-full__collapsed-item:hover {
  background: #f5f7fa;
}

.ai-full__collapsed-item.is-active {
  background: #eff6ff;
}

.ai-full__sidebar-footer {
  padding: 10px;
  border-top: 1px solid #f0f0f0;
  display: flex;
  justify-content: center;
  flex-shrink: 0;
}

.ai-full__collapse-btn {
  cursor: pointer;
  color: #9ca3af;
  font-size: 18px;
  padding: 4px;
  border-radius: 6px;
  transition: color 0.2s, background 0.2s;
}

.ai-full__collapse-btn:hover {
  color: #374151;
  background: #f3f4f6;
}

/* ========== 聊天区 ========== */
.ai-full__chat {
  flex: 1;
  display: flex;
  flex-direction: column;
  background: #fff;
  min-width: 0;
}

/* 顶部头部 */
.ai-full__header {
  display: flex;
  align-items: center;
  justify-content: space-between;
  padding: 14px 20px 10px;
  border-bottom: 1px solid #f0f0f0;
}

/* 选项卡组容器 - 所有选项卡并列一行 */
.ai-full__tab-group {
  display: flex;
  align-items: center;
  gap: 0;
}

/* 主选项卡：小信智聊（比其他选项卡更大） */
.ai-full__tab-primary {
  display: flex;
  align-items: center;
  gap: 6px;
  padding: 10px 24px;
  border-radius: 999px;
  cursor: pointer;
  font-size: 16px;
  font-weight: 600;
  color: #2563eb;
  background: #dbeafe;
  border: 1.5px solid #bfdbfe;
  transition: all 0.25s ease;
  user-select: none;
  box-shadow: 0 1px 4px rgba(37, 99, 235, 0.08);
}

.ai-full__tab-primary:hover {
  background: #bfdbfe;
}

.ai-full__tab-primary.is-active {
  color: #fff;
  background: #2563eb;
  border-color: #2563eb;
  box-shadow: 0 3px 10px rgba(37, 99, 235, 0.35);
}

.ai-full__tab-primary-icon {
  font-size: 18px;
  line-height: 1;
}

.ai-full__tab-primary-name {
  line-height: 1;
}

/* 浅色虚线分隔符 */
.ai-full__tab-divider {
  width: 1px;
  height: 28px;
  background: repeating-linear-gradient(
    to bottom,
    #d1d5db 0px,
    #d1d5db 4px,
    transparent 4px,
    transparent 8px
  );
  margin: 0 16px;
}

.ai-full__tab-divider3 {
  width: 1px;
  height: 28px;
  margin: 0 16px;
}

/* 子选项卡（比主选项卡小） */
.ai-full__tab {
  display: flex;
  align-items: center;
  gap: 4px;
  padding: 7px 16px;
  border-radius: 999px;
  cursor: pointer;
  font-size: 14px;
  color: #666;
  transition: all 0.25s ease;
  white-space: nowrap;
  background: #f5f5f5;
  border: 1px solid transparent;
}

.ai-full__tab:hover {
  background: #e8e8e8;
  color: #333;
}

.ai-full__tab.is-active {
  background: #fed7aa;
  color: #9a3412;
  font-weight: 500;
  border-color: #fdba74;
  box-shadow: 0 1px 4px rgba(249, 115, 22, 0.15);
}

.ai-full__tab-icon {
  font-size: 15px;
  line-height: 1;
}

.ai-full__tab.is-active .ai-full__tab-icon {
  transform: scale(1.1);
}

/* 操作按钮组 */
.ai-full__actions {
  display: flex;
  gap: 6px;
  padding-left: 6px;
}

.ai-full__action-btn-top {
  cursor: pointer;
  color: #9ca3af;
  transition: color 0.2s, transform 0.2s;
  padding: 6px;
  border-radius: 8px;
  font-size: 24px;
}

.ai-full__action-btn-top:hover {
  color: #374151;
  background: #f3f4f6;
}

.ai-full__action-btn-top.is-close:hover {
  color: #ef4444;
  background: #fee2e2;
}

/* 内容区 */
.ai-full__body {
  flex: 1;
  padding: 16px 20px;
  overflow-y: auto;
  display: flex;
  flex-direction: column;
  gap: 12px;
  min-height: 0;
}

.ai-full__body::-webkit-scrollbar {
  width: 6px;
}

.ai-full__body::-webkit-scrollbar-thumb {
  background: #d1d5db;
  border-radius: 3px;
}

/* 欢迎区 */
.ai-full__welcome {
  flex: 1;
  display: flex;
  flex-direction: column;
  gap: 10px;
  justify-content: flex-start;
  padding-top: 20px;
  align-items: center;
}

.ai-full__templates {
  display: flex;
  gap: 8px;
  width: 100%;
  flex-wrap: wrap;
  justify-content: center;
  margin-top: 100px;
}

.ai-full__template {
  padding: 6px 14px;
  font-size: 13px;
  border-radius: 999px;
  border: 1px solid #e0e6ef;
  background: #fff;
  color: #555;
  cursor: pointer;
  text-align: center;
  transition: all 0.2s;
  user-select: none;
}

.ai-full__template:hover {
  border-color: #2563eb;
  color: #2563eb;
}

.ai-full__template.is-active {
  background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
  border-color: transparent;
  color: #fff;
  font-weight: 500;
  box-shadow: 0 2px 8px rgba(102, 126, 234, 0.25);
}

.ai-full__examples {
  display: flex;
  flex-direction: column;
  gap: 8px;
  width: 100%;
  align-items: center;
}

.ai-full__example {
  display: flex;
  align-items: center;
  justify-content: center;
  gap: 4px;
  padding: 11px 16px;
  background: #f5f7fa;
  border-radius: 12px;
  cursor: pointer;
  transition: all 0.2s;
  font-size: 14px;
  color: #333;
  width: 100%;
  max-width: 540px;
}

.ai-full__example:hover {
  background: #e8f0ff;
  transform: translateY(-1px);
  box-shadow: 0 4px 12px rgba(37, 99, 235, 0.08);
}

.ai-full__example-icon {
  font-size: 16px;
  flex-shrink: 0;
}

.ai-full__example-text {
  text-align: left;
}

/* 对话区 */
.ai-full__msg {
  display: flex;
  gap: 10px;
  margin-bottom: 16px;
}

.ai-full__msg.is-user {
  flex-direction: row-reverse;
}

.ai-full__msg-avatar {
  width: 34px;
  height: 34px;
  border-radius: 50%;
  background: #fff;
  display: flex;
  align-items: center;
  justify-content: center;
  font-size: 18px;
  flex-shrink: 0;
  box-shadow: 0 2px 8px rgba(0, 0, 0, 0.06);
}

.ai-full__msg.is-user .ai-full__msg-avatar {
  background: #2563eb;
}

.ai-full__msg-content {
  max-width: 75%;
}

.ai-full__msg.is-user .ai-full__msg-content {
  display: flex;
  flex-direction: column;
  align-items: flex-end;
}

.ai-full__text {
  background: #f5f7fa;
  padding: 10px 14px;
  border-radius: 12px;
  line-height: 1.6;
  word-break: break-word;
  font-size: 14px;
  white-space: pre-wrap;
}

.ai-full__msg.is-user .ai-full__text {
  background: #2563eb;
  color: #fff;
}

.ai-full__markdown {
  background: #f5f7fa;
  padding: 12px 16px;
  border-radius: 4px 12px 12px 12px;
  line-height: 1.7;
  font-size: 14px;
  color: #333;
  word-break: break-word;
}

.ai-full__markdown :deep(h2),
.ai-full__markdown :deep(h3),
.ai-full__markdown :deep(h4) {
  margin: 10px 0 6px;
}

.ai-full__markdown :deep(ul),
.ai-full__markdown :deep(ol) {
  padding-left: 20px;
  margin: 4px 0;
}

.ai-full__markdown :deep(code) {
  background: #e8e8e8;
  padding: 2px 6px;
  border-radius: 4px;
  font-size: 13px;
}

.ai-full__markdown :deep(pre) {
  background: #1e1e1e;
  color: #d4d4d4;
  padding: 14px;
  border-radius: 8px;
  overflow-x: auto;
  margin: 8px 0;
}

.ai-full__markdown :deep(blockquote) {
  border-left: 3px solid #2563eb;
  padding-left: 10px;
  color: #666;
  margin: 6px 0;
}

.ai-full__markdown :deep(table) {
  width: 100%;
  border-collapse: collapse;
  margin: 8px 0;
}

.ai-full__markdown :deep(td),
.ai-full__markdown :deep(th) {
  border: 1px solid #ddd;
  padding: 6px 10px;
}

.ai-full__markdown :deep(strong) {
  color: #2563eb;
}

/* 打字动画 */
.ai-full__typing {
  display: flex;
  gap: 4px;
  padding: 10px 14px;
}

.ai-full__typing span {
  width: 8px;
  height: 8px;
  background: #ccc;
  border-radius: 50%;
  animation: bounce 1.4s infinite ease-in-out both;
}

.ai-full__typing span:nth-child(1) { animation-delay: -0.32s; }
.ai-full__typing span:nth-child(2) { animation-delay: -0.16s; }

@keyframes bounce {
  0%, 80%, 100% { transform: scale(0); }
  40% { transform: scale(1); }
}

/* 文件卡片 */
.ai-full__file-list {
  display: flex;
  flex-direction: column;
  gap: 6px;
  padding: 8px 12px;
  background: #f0f9ff;
  border: 1px solid #bae6fd;
  border-radius: 10px;
}

.ai-full__file-card {
  display: flex;
  align-items: center;
  gap: 10px;
  padding: 8px 12px;
  background: #fff;
  border: 1px solid #e0f2fe;
  border-radius: 8px;
  font-size: 13px;
}

.ai-full__file-type {
  font-size: 16px;
  flex-shrink: 0;
}

.ai-full__file-info {
  flex: 1;
  min-width: 0;
  overflow: hidden;
}

.ai-full__file-name {
  font-weight: 500;
  color: #0c4a6e;
  white-space: nowrap;
  overflow: hidden;
  text-overflow: ellipsis;
}

.ai-full__file-meta {
  color: #64748b;
  font-size: 12px;
  margin-top: 2px;
}

.ai-full__file-remove {
  cursor: pointer;
  color: #94a3b8;
  flex-shrink: 0;
  font-size: 15px;
  transition: color 0.2s;
}

.ai-full__file-remove:hover {
  color: #ef4444;
}

/* 输入区 */
.ai-full__input {
  padding: 10px 16px;
  border-top: 1px solid #f0f0f0;
  display: flex;
  gap: 10px;
  align-items: flex-end;
  height: 340px;
}

.ai-full__file-input {
  display: none;
}

/* + 上传按钮 */
.ai-full__upload {
  display: flex;
  align-items: center;
  justify-content: center;
  width: 34px;
  height: 34px;
  border-radius: 8px;
  background: #f0f5ff;
  color: #2563eb;
  font-size: 18px;
  cursor: pointer;
  flex-shrink: 0;
  transition: all 0.2s;
  user-select: none;
}

.ai-full__upload:hover:not(.is-disabled) {
  background: #dbeafe;
  transform: scale(1.05);
}

.ai-full__upload.is-disabled {
  opacity: 0.4;
  cursor: not-allowed;
}

.ai-full__upload .is-loading {
  animation: spin 1s linear infinite;
}

@keyframes spin {
  from { transform: rotate(0deg); }
  to { transform: rotate(360deg); }
}

/* 输入框容器 */
.ai-full__input-box {
  flex: 1;
  position: relative;
  display: flex;
  align-items: flex-end;
  border: 1px solid #e0e0e0;
  border-radius: 10px;
  background: #fff;
  transition: border-color 0.2s;
  padding: 2px 4px 2px 0;
}

.ai-full__input-box:focus-within {
  border-color: #2563eb;
  box-shadow: 0 0 0 2px rgba(37, 99, 235, 0.1);
}

.ai-full__textarea {
  flex: 1;
  padding: 6px 8px;
  height: 100px;
}

.ai-full__textarea :deep(textarea) {
  font-size: 14px;
  line-height: 1.5;
  padding: 4px 6px;
  background: transparent;
  border: none !important;
  box-shadow: none !important;
}

.ai-full__textarea :deep(.el-textarea__inner) {
  border: none !important;
  box-shadow: none !important;
}

/* 发送按钮 */
.ai-full__send {
  flex-shrink: 0;
  width: 32px;
  height: 32px;
  background: #2563eb !important;
  border: none !important;
  box-shadow: 0 2px 6px rgba(37, 99, 235, 0.3);
  transition: all 0.2s ease;
  margin: 0;
}

.ai-full__send:hover:not(:disabled) {
  transform: scale(1.08);
  box-shadow: 0 3px 10px rgba(37, 99, 235, 0.45);
}

.ai-full__send:disabled {
  background: #d1d5db !important;
  box-shadow: none;
}

.ai-full__footer {
  text-align: left;
  padding: 4px 16px 10px;
  font-size: 12px;
  color: #9ca3af;
}

/* ========== 响应式设计 ========== */
@media (max-width: 900px) {
  .ai-chat-full {
    padding: 0;
  }

  .ai-full {
    border-radius: 0;
    border: none;
    box-shadow: none;
  }

  .ai-full__sidebar {
    width: 200px;
  }

  .ai-full__tab-primary {
    padding: 6px 14px;
    font-size: 14px;
  }

  .ai-full__tab-primary-icon {
    font-size: 15px;
  }
}

@media (max-width: 700px) {
  .ai-full__sidebar {
    width: 60px;
  }

  .ai-full__sidebar-header,
  .ai-full__new-chat,
  .ai-full__search,
  .ai-full__history-title,
  .ai-full__conversation-list {
    display: none;
  }

  .ai-full__collapsed-list {
    display: flex;
  }
}
</style>
