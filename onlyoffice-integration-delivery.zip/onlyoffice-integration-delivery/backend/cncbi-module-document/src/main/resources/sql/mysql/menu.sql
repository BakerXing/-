-- =============================================================
-- 【文档中心】菜单与权限初始化 SQL（MySQL）
--
-- 说明：
--   1. 一级菜单【文档中心】通过 sort 字段精确控制排序，使其位于顶部导航的
--      第一个菜单（首页/作者动态）之后。
--   2. 当前项目顶层目录（type=1, parent_id=0）实际排序如下：
--        作者动态(sort=0) > Boot开发文档(sort=1) > Cloud开发文档(sort=2) > 系统管理(sort=10) ...
--      因此本脚本将【文档中心】sort 设为 0，通过「sort 相同则按 id 升序」的
--      RuoYi 排序规则，令其排在作者动态(id=1254)之后、Boot开发文档(sort=1)之前。
--
--      ⚠ 若需在【首页】与【作者动态】两个菜单之间插入，请将下方 _SORT_ 替换为
--         [首页的 sort] 到 [作者动态的 sort] 之间的整数值（二者 id 顺序同样影响最终排序）。
--
--   3. 所有菜单 id 取 7000+，避免与既有菜单冲突。
-- =============================================================

-- ----------------------------
-- 一级目录：文档中心
-- ----------------------------
INSERT INTO `system_menu` (`id`, `name`, `permission`, `type`, `sort`, `parent_id`, `path`, `icon`, `component`, `component_name`, `status`, `visible`, `keep_alive`, `always_show`, `creator`, `create_time`, `updater`, `update_time`, `deleted`)
VALUES (7000, '文档中心', '', 1, 0, 0, '/document', 'ep:folder', NULL, NULL, 0, b'1', b'1', b'1', '1', NOW(), '1', NOW(), b'0');

-- ----------------------------
-- 二级菜单：文档管理
-- ----------------------------
INSERT INTO `system_menu` (`id`, `name`, `permission`, `type`, `sort`, `parent_id`, `path`, `icon`, `component`, `component_name`, `status`, `visible`, `keep_alive`, `always_show`, `creator`, `create_time`, `updater`, `update_time`, `deleted`)
VALUES (7001, '文档管理', '', 2, 1, 7000, 'file', 'ep:document', 'document/file/index', 'DocumentFile', 0, b'1', b'1', b'1', '1', NOW(), '1', NOW(), b'0');

-- ----------------------------
-- 按钮权限：目录管理
-- ----------------------------
INSERT INTO `system_menu` (`id`, `name`, `permission`, `type`, `sort`, `parent_id`, `path`, `icon`, `component`, `component_name`, `status`, `visible`, `keep_alive`, `always_show`, `creator`, `create_time`, `updater`, `update_time`, `deleted`)
VALUES (7002, '目录查询', 'document:dir:query', 3, 1, 7001, '', '', NULL, NULL, 0, b'1', b'1', b'1', '1', NOW(), '1', NOW(), b'0'),
       (7003, '目录创建', 'document:dir:create', 3, 2, 7001, '', '', NULL, NULL, 0, b'1', b'1', b'1', '1', NOW(), '1', NOW(), b'0'),
       (7004, '目录修改', 'document:dir:update', 3, 3, 7001, '', '', NULL, NULL, 0, b'1', b'1', b'1', '1', NOW(), '1', NOW(), b'0'),
       (7005, '目录删除', 'document:dir:delete', 3, 4, 7001, '', '', NULL, NULL, 0, b'1', b'1', b'1', '1', NOW(), '1', NOW(), b'0');

-- ----------------------------
-- 按钮权限：文件管理
-- ----------------------------
INSERT INTO `system_menu` (`id`, `name`, `permission`, `type`, `sort`, `parent_id`, `path`, `icon`, `component`, `component_name`, `status`, `visible`, `keep_alive`, `always_show`, `creator`, `create_time`, `updater`, `update_time`, `deleted`)
VALUES (7006, '文件查询', 'document:file:query', 3, 1, 7001, '', '', NULL, NULL, 0, b'1', b'1', b'1', '1', NOW(), '1', NOW(), b'0'),
       (7007, '文件创建', 'document:file:create', 3, 2, 7001, '', '', NULL, NULL, 0, b'1', b'1', b'1', '1', NOW(), '1', NOW(), b'0'),
       (7008, '文件修改', 'document:file:update', 3, 3, 7001, '', '', NULL, NULL, 0, b'1', b'1', b'1', '1', NOW(), '1', NOW(), b'0'),
       (7009, '文件删除', 'document:file:delete', 3, 4, 7001, '', '', NULL, NULL, 0, b'1', b'1', b'1', '1', NOW(), '1', NOW(), b'0');
