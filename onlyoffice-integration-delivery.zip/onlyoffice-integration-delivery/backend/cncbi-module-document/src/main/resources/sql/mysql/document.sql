-- =============================================================
-- 【文档中心】模块初始化 SQL（MySQL）
-- 说明：文档中心用于对接 OnlyOffice Document Server，实现在线预览与在线编辑。
--      本脚本仅包含模块自有表结构，配套的菜单、权限 SQL 请见 script 同级目录 menu.sql。
--
-- 文件存储策略说明：
--   文档中心不重复造轮子，直接复用 infra 模块的统一文件存储能力。
--   file_path 字段保存的是通过 FileApi#createFile 上传后返回的文件访问路径（相对路径），
--   实际文件内容由 infra 模块按「主文件配置」写入本地/S3/SFTP/FTP/DB 等目标存储。
-- =============================================================

-- -------------------------------------------------------------
-- 文档目录表
-- 说明：目录为树形结构，通过 parent_id 维护父子关系，root 目录的 parent_id 为 0。
-- -------------------------------------------------------------
CREATE TABLE `document_dir` (
  `id`           BIGINT       NOT NULL AUTO_INCREMENT COMMENT '目录编号，自增主键',
  `name`         VARCHAR(64)  NOT NULL COMMENT '目录名称',
  `parent_id`    BIGINT       NOT NULL DEFAULT 0 COMMENT '父目录编号，0 表示根目录',
  `sort`         INT          NOT NULL DEFAULT 0 COMMENT '排序序号，越小越靠前',
  `remark`       VARCHAR(255)          DEFAULT NULL COMMENT '目录备注',
  `creator`      VARCHAR(64)           DEFAULT '' COMMENT '创建者',
  `create_time`  DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `updater`      VARCHAR(64)           DEFAULT '' COMMENT '更新者',
  `update_time`  DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
  `deleted`      BIT(1)       NOT NULL DEFAULT b'0' COMMENT '是否删除(逻辑删除)',
  `tenant_id`    BIGINT       NOT NULL DEFAULT 0 COMMENT '租户编号',
  PRIMARY KEY (`id`),
  KEY `idx_parent_id` (`parent_id`),
  KEY `idx_tenant_id` (`tenant_id`)
) ENGINE = InnoDB AUTO_INCREMENT = 1 DEFAULT CHARSET = utf8mb4 COMMENT ='文档目录表';

-- -------------------------------------------------------------
-- 文档文件表
-- 说明：记录每一个上传至文档中心的文件元信息，文件实体复用 infra 统一存储。
--      预留 permission_type（权限）与 version（版本）扩展字段。
-- -------------------------------------------------------------
CREATE TABLE `document_file` (
  `id`              BIGINT       NOT NULL AUTO_INCREMENT COMMENT '文件编号，自增主键',
  `doc_no`          VARCHAR(64)           DEFAULT '' COMMENT 'CNCBI 文档编号',
  `dir_id`          BIGINT       NOT NULL DEFAULT 0 COMMENT '所属目录编号，关联 document_dir.id，0 表示根目录',
  `name`            VARCHAR(255) NOT NULL COMMENT '文件名称（含扩展名）',
  `file_path`       VARCHAR(511) NOT NULL COMMENT '文件存储路径（FileApi 返回的相对访问路径）',
  `file_size`       BIGINT       NOT NULL DEFAULT 0 COMMENT '文件大小，单位：字节',
  `file_ext`        VARCHAR(16)  NOT NULL DEFAULT '' COMMENT '文件扩展名，如 docx/xlsx/pptx/pdf',
  `file_type`       VARCHAR(128)          DEFAULT '' COMMENT '文件 MIME 类型',
  -- 扩展字段：文件权限、版本管理（预留，后续迭代使用）
  `permission_type` TINYINT      NOT NULL DEFAULT 1 COMMENT '文件权限类型：1-仅自己可见 2-指定人可见 3-公开只读（预留字段）',
  `version`         INT          NOT NULL DEFAULT 1 COMMENT '文件版本号（预留，后续迭代用于版本管理）',
  `audit_time`      DATETIME              DEFAULT NULL COMMENT '审核日期',
  `remark`          VARCHAR(255)          DEFAULT NULL COMMENT '文件备注',
  `creator`         VARCHAR(64)           DEFAULT '' COMMENT '创建者',
  `create_time`     DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `updater`         VARCHAR(64)           DEFAULT '' COMMENT '更新者',
  `update_time`     DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
  `deleted`         BIT(1)       NOT NULL DEFAULT b'0' COMMENT '是否删除(逻辑删除)',
  `tenant_id`       BIGINT       NOT NULL DEFAULT 0 COMMENT '租户编号',
  PRIMARY KEY (`id`),
  KEY `idx_dir_id` (`dir_id`),
  KEY `idx_tenant_id` (`tenant_id`)
) ENGINE = InnoDB AUTO_INCREMENT = 1 DEFAULT CHARSET = utf8mb4 COMMENT ='文档文件表';
