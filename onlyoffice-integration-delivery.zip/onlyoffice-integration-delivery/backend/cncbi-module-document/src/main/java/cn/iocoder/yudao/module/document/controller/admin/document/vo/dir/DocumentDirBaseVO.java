package cn.iocoder.yudao.module.document.controller.admin.document.vo.dir;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;

import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;

/**
 * 文档目录 Base VO
 *
 * @author eip-build
 */
@Data
public class DocumentDirBaseVO {

    @Schema(description = "目录名称", requiredMode = Schema.RequiredMode.REQUIRED, example = "规章制度")
    @NotEmpty(message = "目录名称不能为空")
    private String name;

    @Schema(description = "父目录编号，0 表示根目录", example = "0")
    @NotNull(message = "父目录编号不能为空")
    private Long parentId;

    @Schema(description = "排序序号，越小越靠前", example = "0")
    private Integer sort;

    @Schema(description = "目录备注", example = "公司规章制度文档")
    private String remark;

}
