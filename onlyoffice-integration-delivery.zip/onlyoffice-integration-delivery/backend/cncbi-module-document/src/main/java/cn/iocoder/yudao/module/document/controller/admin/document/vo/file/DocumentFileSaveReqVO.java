package cn.iocoder.yudao.module.document.controller.admin.document.vo.file;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;

import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;
import java.time.LocalDateTime;

@Schema(description = "管理后台 - 文档文件创建 Request VO")
@Data
public class DocumentFileSaveReqVO {

    @Schema(description = "文件编号，修改时必传", example = "1")
    private Long id;

    @Schema(description = "CNCBI 文档编号", example = "CIP-2026-0001")
    private String docNo;

    @Schema(description = "所属目录编号，0 表示根目录", example = "0")
    @NotNull(message = "所属目录编号不能为空")
    private Long dirId;

    @Schema(description = "文件名称", requiredMode = Schema.RequiredMode.REQUIRED, example = "年度报告.docx")
    @NotEmpty(message = "文件名称不能为空")
    private String name;

    @Schema(description = "文件存储路径（FileApi 返回的相对访问路径）", requiredMode = Schema.RequiredMode.REQUIRED)
    @NotEmpty(message = "文件存储路径不能为空")
    private String filePath;

    @Schema(description = "文件大小，单位字节", example = "102400")
    private Long fileSize;

    @Schema(description = "文件扩展名", example = "docx")
    private String fileExt;

    @Schema(description = "文件 MIME 类型", example = "application/octet-stream")
    private String fileType;

    @Schema(description = "文件权限类型：1-仅自己可见 2-指定人可见 3-公开只读", example = "1")
    private Integer permissionType;

    @Schema(description = "文件版本号", example = "1")
    private Integer version;

    @Schema(description = "文件备注")
    private String remark;

    @Schema(description = "审核日期")
    private LocalDateTime auditTime;

}
