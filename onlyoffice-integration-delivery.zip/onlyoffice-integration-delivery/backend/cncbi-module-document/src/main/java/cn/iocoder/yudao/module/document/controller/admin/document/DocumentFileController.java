package cn.iocoder.yudao.module.document.controller.admin.document;

import cn.iocoder.yudao.framework.common.pojo.CommonResult;
import cn.iocoder.yudao.framework.common.pojo.PageResult;
import cn.iocoder.yudao.framework.common.util.object.BeanUtils;
import cn.iocoder.yudao.module.document.controller.admin.document.vo.file.DocumentFilePageReqVO;
import cn.iocoder.yudao.module.document.controller.admin.document.vo.file.DocumentFileRespVO;
import cn.iocoder.yudao.module.document.controller.admin.document.vo.file.DocumentFileSaveReqVO;
import cn.iocoder.yudao.module.document.convert.DocumentConvert;
import cn.iocoder.yudao.module.document.dal.dataobject.DocumentFileDO;
import cn.iocoder.yudao.module.document.framework.onlyoffice.OnlyOfficeConfigVO;
import cn.iocoder.yudao.module.document.service.document.DocumentFileService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.tags.Tag;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;

import javax.annotation.Resource;
import javax.validation.Valid;

import static cn.iocoder.yudao.framework.common.pojo.CommonResult.success;

/**
 * 管理后台 - 文档文件
 *
 * 提供文档文件的元信息管理，以及对接 OnlyOffice 的在线预览、在线编辑入口。
 * 所有接口均接入系统原生权限体系，禁止匿名访问。
 *
 * @author eip-build
 */
@Tag(name = "管理后台 - 文档文件")
@RestController
@RequestMapping("/document/file")
@Validated
public class DocumentFileController {

    @Resource
    private DocumentFileService fileService;

    @PostMapping("/create")
    @Operation(summary = "创建文档文件元信息")
    @PreAuthorize("@ss.hasPermission('document:file:create')")
    public CommonResult<Long> createFile(@Valid @RequestBody DocumentFileSaveReqVO createReqVO) {
        return success(fileService.createFile(createReqVO));
    }

    @PutMapping("/update")
    @Operation(summary = "更新文档文件元信息")
    @PreAuthorize("@ss.hasPermission('document:file:update')")
    public CommonResult<Boolean> updateFile(@Valid @RequestBody DocumentFileSaveReqVO updateReqVO) {
        fileService.updateFile(updateReqVO);
        return success(true);
    }

    @DeleteMapping("/delete")
    @Operation(summary = "删除文档文件")
    @Parameter(name = "id", description = "文件编号", required = true)
    @PreAuthorize("@ss.hasPermission('document:file:delete')")
    public CommonResult<Boolean> deleteFile(@RequestParam("id") Long id) {
        fileService.deleteFile(id);
        return success(true);
    }

    @GetMapping("/get")
    @Operation(summary = "获得文档文件")
    @Parameter(name = "id", description = "文件编号", required = true)
    @PreAuthorize("@ss.hasPermission('document:file:query')")
    public CommonResult<DocumentFileRespVO> getFile(@RequestParam("id") Long id) {
        DocumentFileDO file = fileService.getFile(id);
        return success(DocumentConvert.INSTANCE.convert(file));
    }

    @GetMapping("/page")
    @Operation(summary = "获得文档文件分页")
    @PreAuthorize("@ss.hasPermission('document:file:query')")
    public CommonResult<PageResult<DocumentFileRespVO>> getFilePage(@Valid DocumentFilePageReqVO pageVO) {
        PageResult<DocumentFileDO> pageResult = fileService.getFilePage(pageVO);
        return success(BeanUtils.toBean(pageResult, DocumentFileRespVO.class));
    }

    /**
     * 在线预览/编辑入口：返回 OnlyOffice 编辑器配置。
     *
     * 前端拿到该配置后，通过 OnlyOffice JavaScript API（DocsAPI.DocEditor）
     * 在页面内渲染编辑器。
     *
     * @param id   文件编号
     * @param mode 打开模式：view-只读预览（默认）；edit-在线编辑
     */
    @GetMapping("/onlyoffice-config")
    @Operation(summary = "获取 OnlyOffice 编辑器配置（在线预览/编辑）")
    @Parameter(name = "id", description = "文件编号", required = true)
    @Parameter(name = "mode", description = "打开模式：view-只读预览；edit-在线编辑")
    @PreAuthorize("@ss.hasPermission('document:file:query')")
    public CommonResult<OnlyOfficeConfigVO> getOnlyOfficeConfig(@RequestParam("id") Long id,
                                                                 @RequestParam(value = "mode", required = false) String mode) {
        return success(fileService.getOnlyOfficeConfig(id, mode));
    }

}
