package cn.iocoder.yudao.module.document.controller.admin.document;

import cn.iocoder.yudao.framework.common.pojo.CommonResult;
import cn.iocoder.yudao.module.document.framework.onlyoffice.OnlyOfficeCallbackDTO;
import cn.iocoder.yudao.module.document.framework.onlyoffice.OnlyOfficeProperties;
import cn.iocoder.yudao.module.document.service.document.DocumentFileService;
import cn.hutool.core.util.StrUtil;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.extern.slf4j.Slf4j;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;

import javax.annotation.Resource;

import static cn.iocoder.yudao.framework.common.pojo.CommonResult.success;
import static cn.iocoder.yudao.framework.common.exception.util.ServiceExceptionUtil.exception;
import static cn.iocoder.yudao.module.document.enums.ErrorCodeConstants.ONLYOFFICE_CALLBACK_INVALID;

/**
 * OnlyOffice 回调接口
 *
 * <p>该接口由 OnlyOffice 服务端在文档保存后回调，属于服务端到服务端的调用，
 * 不经过浏览器登录态，因此不能使用 {@code @PreAuthorize} 登录鉴权。
 * 转而在请求头中通过共享密钥 {@code Authorization} 进行校验，
 * 防止被匿名外部调用伪造回调、篡改文档。</p>
 *
 * <p>回调地址示例（与 application.yml 中的 {@code yudao.onlyoffice.callback-url} 一致）：
 * {@code http://<host>:48080/admin-api/document/onlyoffice/callback}</p>
 *
 * @author eip-build
 */
@Tag(name = "管理后台 - OnlyOffice 回调")
@RestController
@RequestMapping("/document/onlyoffice")
@Validated
@Slf4j
public class OnlyOfficeCallbackController {

    @Resource
    private DocumentFileService fileService;

    @Resource
    private OnlyOfficeProperties onlyOfficeProperties;

    @PostMapping("/callback")
    @Operation(summary = "接收 OnlyOffice 文档保存回调")
    public CommonResult<Integer> callback(@RequestBody OnlyOfficeCallbackDTO callbackDTO,
                                          @RequestHeader(value = "Authorization", required = false) String authorization) {
        // 1. 校验回调来源合法性：请求头需携带与 OnlyOffice 配置一致的共享密钥
        validateCallbackAuth(authorization);

        // 2. 参数与状态校验
        if (callbackDTO == null || StrUtil.isBlank(callbackDTO.getKey())) {
            log.warn("[callback] 非法回调：key 缺失");
            throw exception(ONLYOFFICE_CALLBACK_INVALID);
        }
        // 仅状态 2（需保存）、6（强制保存）才需要落盘
        // 状态 3/7 为保存失败，记录日志；其余状态（0/1/4）无需处理。
        if (callbackDTO.getStatus() != null && (callbackDTO.getStatus() == 3 || callbackDTO.getStatus() == 7)) {
            log.error("[callback] 文档保存异常，status={}, error={}, key={}",
                    callbackDTO.getStatus(), callbackDTO.getError(), callbackDTO.getKey());
            return success(0);
        }
        if (!callbackDTO.isSaveStatus() || StrUtil.isBlank(callbackDTO.getUrl())) {
            // 无需保存或缺少下载地址，直接响应成功避免 OnlyOffice 重试
            return success(0);
        }

        // 3. 拉取编辑后的文件并写回存储
        fileService.handleCallbackSave(callbackDTO.getKey(), callbackDTO.getUrl());
        return success(0);
    }

    /**
     * 校验回调来源：对比请求头 Authorization 与配置的 jwtSecret。
     * 仅当配置了 jwtSecret 时才强制校验；未配置时降级为仅校验 key 格式（可在内网网段内使用）。
     */
    private void validateCallbackAuth(String authorization) {
        String secret = onlyOfficeProperties.getJwtSecret();
        if (StrUtil.isBlank(secret)) {
            // 未配置 JWT 密钥时，回调安全依赖网络层（内网隔离/防火墙），此处不强制。
            log.warn("[callback] 未配置 yudao.onlyoffice.jwt-secret，回调接口未启用密钥校验，请确保回调地址处于受信任网络");
            return;
        }
        if (!StrUtil.equals(secret, authorization)) {
            log.warn("[callback] 回调密钥校验失败，非法调用被拒绝");
            throw exception(ONLYOFFICE_CALLBACK_INVALID);
        }
    }

}
