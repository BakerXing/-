package cn.iocoder.yudao.module.document.service.document;

import cn.hutool.core.io.IoUtil;
import cn.hutool.core.util.StrUtil;
import cn.hutool.http.HttpUtil;
import cn.iocoder.yudao.framework.common.pojo.PageResult;
import cn.iocoder.yudao.framework.security.core.util.SecurityFrameworkUtils;
import cn.iocoder.yudao.module.document.controller.admin.document.vo.file.DocumentFilePageReqVO;
import cn.iocoder.yudao.module.document.controller.admin.document.vo.file.DocumentFileSaveReqVO;
import cn.iocoder.yudao.module.document.dal.dataobject.DocumentFileDO;
import cn.iocoder.yudao.module.document.dal.mysql.DocumentFileMapper;
import cn.iocoder.yudao.module.document.framework.onlyoffice.OnlyOfficeConfigVO;
import cn.iocoder.yudao.module.document.framework.onlyoffice.OnlyOfficeProperties;
import cn.iocoder.yudao.module.infra.api.file.FileApi;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import org.springframework.validation.annotation.Validated;

import javax.annotation.Resource;
import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.util.Objects;

import static cn.iocoder.yudao.framework.common.exception.util.ServiceExceptionUtil.exception;
import static cn.iocoder.yudao.module.document.enums.ErrorCodeConstants.*;

/**
 * 文档文件 Service 实现类
 *
 * 核心设计：
 * <ul>
 *   <li>文件实体复用 infra 模块统一存储；{@code filePath} 保存的是上传后返回的完整访问 URL
 *       （形如 {@code {domain}/admin-api/infra/file/{configId}/get/{path}}），OnlyOffice 可直接拉取。</li>
 *   <li>在线预览/编辑通过 {@link #getOnlyOfficeConfig} 构建 OnlyOffice 编辑器配置返回给前端。</li>
 *   <li>保存回调 {@link #handleCallbackSave} 从 OnlyOffice 提供的下载地址拉取编辑后的文件，
 *       重新通过 {@link FileApi#createFile} 写入存储，并递增版本号。</li>
 * </ul>
 *
 * @author eip-build
 */
@Service
@Validated
@Slf4j
public class DocumentFileServiceImpl implements DocumentFileService {

    @Resource
    private DocumentFileMapper documentFileMapper;

    @Resource
    private FileApi fileApi;

    @Resource
    private OnlyOfficeProperties onlyOfficeProperties;

    @Override
    public Long createFile(DocumentFileSaveReqVO createReqVO) {
        // 校验同目录下文件名唯一
        validateFileNameUnique(createReqVO.getDirId(), createReqVO.getName(), null);
        // 入库
        DocumentFileDO file = DocumentFileDO.builder()
                .docNo(createReqVO.getDocNo())
                .dirId(createReqVO.getDirId())
                .name(createReqVO.getName())
                .filePath(createReqVO.getFilePath())
                .fileSize(createReqVO.getFileSize())
                .fileExt(createReqVO.getFileExt())
                .fileType(createReqVO.getFileType())
                .permissionType(createReqVO.getPermissionType() == null ? 1 : createReqVO.getPermissionType())
                .version(1)
                .auditTime(createReqVO.getAuditTime())
                .remark(createReqVO.getRemark())
                .build();
        documentFileMapper.insert(file);
        return file.getId();
    }

    @Override
    public void updateFile(DocumentFileSaveReqVO updateReqVO) {
        DocumentFileDO file = validateFileExists(updateReqVO.getId());
        validateFileNameUnique(updateReqVO.getDirId(), updateReqVO.getName(), updateReqVO.getId());

        DocumentFileDO updateObj = DocumentFileDO.builder()
                .id(updateReqVO.getId())
                .docNo(updateReqVO.getDocNo())
                .dirId(updateReqVO.getDirId())
                .name(updateReqVO.getName())
                .filePath(updateReqVO.getFilePath())
                .fileSize(updateReqVO.getFileSize())
                .fileExt(updateReqVO.getFileExt())
                .fileType(updateReqVO.getFileType())
                .permissionType(updateReqVO.getPermissionType() == null ? file.getPermissionType() : updateReqVO.getPermissionType())
                .version(updateReqVO.getVersion() == null ? file.getVersion() : updateReqVO.getVersion())
                .auditTime(updateReqVO.getAuditTime())
                .remark(updateReqVO.getRemark())
                .build();
        documentFileMapper.updateById(updateObj);
    }

    @Override
    public void deleteFile(Long id) {
        DocumentFileDO file = validateFileExists(id);
        // 逻辑删除元信息；文件实体随 infra file 表统一管理，
        // 若需彻底清理文件实体，可在此扩展调用 FileApi 对应的删除能力。
        documentFileMapper.deleteById(file.getId());
    }

    @Override
    public DocumentFileDO getFile(Long id) {
        return validateFileExists(id);
    }

    @Override
    public PageResult<DocumentFileDO> getFilePage(DocumentFilePageReqVO pageReqVO) {
        return documentFileMapper.selectPage(pageReqVO);
    }

    @Override
    public OnlyOfficeConfigVO getOnlyOfficeConfig(Long id, String mode) {
        // 1. 校验文件存在
        DocumentFileDO file = validateFileExists(id);
        // 2. 校验 OnlyOffice 服务地址是否已配置
        if (StrUtil.isBlank(onlyOfficeProperties.getDocServiceUrl())
                || StrUtil.isBlank(onlyOfficeProperties.getCallbackUrl())) {
            throw exception(ONLYOFFICE_CONFIG_ERROR);
        }
        // 3. 判断打开模式：默认只读预览（view），仅 edit 才开启编辑
        boolean editable = "edit".equalsIgnoreCase(mode);
        // 4. 获取当前登录用户（用于协作、修订记录）
        Long userId = SecurityFrameworkUtils.getLoginUserId();
        String username = Objects.toString(SecurityFrameworkUtils.getLoginUserNickname(), String.valueOf(userId));

        // 5. 构建编辑器配置
        String jwtSecret = onlyOfficeProperties.getJwtSecret();
        if (editable) {
            return OnlyOfficeConfigVO.edit(file.getFileExt(), String.valueOf(file.getId()), file.getName(),
                    file.getFilePath(), onlyOfficeProperties.getCallbackUrl(), userId, username,
                    onlyOfficeProperties.getDocServiceUrl(), jwtSecret);
        }
        return OnlyOfficeConfigVO.preview(file.getFileExt(), String.valueOf(file.getId()), file.getName(),
                file.getFilePath(), onlyOfficeProperties.getCallbackUrl(), userId, username,
                onlyOfficeProperties.getDocServiceUrl(), jwtSecret);
    }

    @Override
    public void handleCallbackSave(String key, String url) {
        // 1. 根据 key（文件编号）定位文件
        Long fileId = Long.parseLong(key);
        DocumentFileDO file = validateFileExists(fileId);

        // 2. 从 OnlyOffice 提供的下载地址拉取编辑后的文件内容
        byte[] content;
        try (InputStream in = HttpUtil.createGet(url).execute().bodyStream();
             ByteArrayOutputStream out = new ByteArrayOutputStream()) {
            IoUtil.copy(in, out);
            content = out.toByteArray();
        } catch (Exception e) {
            log.error("[handleCallbackSave][fileId({}) 下载编辑后文件失败 url({})]", fileId, url, e);
            throw exception(ONLYOFFICE_CALLBACK_SAVE_FAIL);
        }

        // 3. 重新写入统一文件存储，返回新的访问地址
        String newUrl = fileApi.createFile(content, file.getName(), null, file.getFileType());

        // 4. 更新文件元信息：新的访问地址 + 文件大小 + 版本号递增
        DocumentFileDO updateObj = new DocumentFileDO();
        updateObj.setId(file.getId());
        updateObj.setFilePath(newUrl);
        updateObj.setFileSize((long) content.length);
        updateObj.setVersion(file.getVersion() + 1);
        documentFileMapper.updateById(updateObj);

        log.info("[handleCallbackSave][fileId({}) 保存成功，version({} -> {})]", fileId, file.getVersion(), updateObj.getVersion());
    }

    private DocumentFileDO validateFileExists(Long id) {
        DocumentFileDO file = documentFileMapper.selectById(id);
        if (file == null) {
            throw exception(DOC_FILE_NOT_EXISTS);
        }
        return file;
    }

    private void validateFileNameUnique(Long dirId, String name, Long excludeId) {
        Long did = dirId == null ? 0L : dirId;
        DocumentFileDO exist = documentFileMapper.selectByDirIdAndName(did, name);
        if (exist != null && !Objects.equals(exist.getId(), excludeId)) {
            throw exception(DOC_FILE_NAME_DUPLICATE);
        }
    }

}
