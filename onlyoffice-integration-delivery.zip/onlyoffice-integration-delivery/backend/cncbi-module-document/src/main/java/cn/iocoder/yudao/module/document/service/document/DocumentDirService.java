package cn.iocoder.yudao.module.document.service.document;

import cn.iocoder.yudao.module.document.controller.admin.document.vo.dir.DocumentDirSaveReqVO;
import cn.iocoder.yudao.module.document.dal.dataobject.DocumentDirDO;

import javax.validation.Valid;
import java.util.List;

/**
 * 文档目录 Service 接口
 *
 * @author eip-build
 */
public interface DocumentDirService {

    /**
     * 创建文档目录
     *
     * @param createReqVO 创建信息
     * @return 编号
     */
    Long createDir(@Valid DocumentDirSaveReqVO createReqVO);

    /**
     * 更新文档目录
     *
     * @param updateReqVO 更新信息
     */
    void updateDir(@Valid DocumentDirSaveReqVO updateReqVO);

    /**
     * 删除文档目录（目录下存在子目录或文件时禁止删除）
     *
     * @param id 编号
     */
    void deleteDir(Long id);

    /**
     * 获得文档目录
     *
     * @param id 编号
     * @return 文档目录
     */
    DocumentDirDO getDir(Long id);

    /**
     * 获得某父目录下的所有子目录（用于构建目录树）
     *
     * @param parentId 父目录编号，null 表示根目录(parentId=0)
     * @return 目录列表
     */
    List<DocumentDirDO> getDirList(Long parentId);

}
