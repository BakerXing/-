package cn.iocoder.yudao.module.document.framework.onlyoffice;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;

import java.util.List;

/**
 * OnlyOffice 回调请求 DTO
 *
 * 对齐 OnlyOffice Document Server 保存回调的 JSON 结构。
 * 状态码定义：
 * <ul>
 *   <li>0 - 文档已关闭，无修改</li>
 *   <li>1 - 文档正在编辑中</li>
 *   <li>2 - 文档已准备好，等待强制保存</li>
 *   <li>3 - 文档保存出错</li>
 *   <li>4 - 文档已无修改地关闭</li>
 *   <li>6 - 文档被强制保存</li>
 *   <li>7 - 文档强制保存出错</li>
 * </ul>
 *
 * @author eip-build
 */
@Schema(description = "OnlyOffice 回调请求 DTO")
@Data
public class OnlyOfficeCallbackDTO {

    @Schema(description = "状态码：0~7")
    private Integer status;

    @Schema(description = "文档 key（即打开文档时传入的业务主键）")
    private String key;

    @Schema(description = "修改后的文档下载 URL（状态 2、6 时有效）")
    private String url;

    @Schema(description = "操作类型集合")
    private List<Action> actions;

    @Schema(description = "修改后的文档历史记录")
    private List<History> history;

    @Schema(description = "错误码（保存出错时）")
    private Integer error;

    @Schema(description = "操作用户 ID")
    private String userid;

    @Data
    public static class Action {
        @Schema(description = "操作类型：0-断开 1-连接 2-强制保存")
        private Integer type;

        @Schema(description = "用户 ID")
        private String userid;
    }

    @Data
    public static class History {
        @Schema(description = "变更记录 JSON")
        private Object changes;
    }

    /**
     * 是否是需要持久化保存文件的状态（状态 2、6 表示文件已编辑完成，需要下载并保存）
     */
    public boolean isSaveStatus() {
        return status != null && (status == 2 || status == 6);
    }
}
