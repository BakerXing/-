package cn.iocoder.yudao.module.document.dal.dataobject;

import cn.iocoder.yudao.framework.mybatis.core.dataobject.BaseDO;
import cn.iocoder.yudao.framework.tenant.core.aop.TenantIgnore;
import com.baomidou.mybatisplus.annotation.TableName;
import lombok.*;

/**
 * 文档目录 DO
 *
 * 目录为树形结构，通过 {@link #parentId} 维护父子关系，根目录 parentId 为 0。
 *
 * @author eip-build
 */
@TableName("document_dir")
@Data
@EqualsAndHashCode(callSuper = true)
@ToString(callSuper = true)
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class DocumentDirDO extends BaseDO {

    /**
     * 目录编号，数据库自增
     */
    private Long id;

    /**
     * 目录名称
     */
    private String name;

    /**
     * 父目录编号，0 表示根目录
     */
    private Long parentId;

    /**
     * 排序序号，越小越靠前
     */
    private Integer sort;

    /**
     * 目录备注
     */
    private String remark;

}
