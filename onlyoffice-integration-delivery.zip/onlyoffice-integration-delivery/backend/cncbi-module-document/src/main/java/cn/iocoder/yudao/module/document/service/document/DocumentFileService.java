package cn.iocoder.yudao.module.document.service.document;

import cn.iocoder.yudao.framework.common.pojo.PageResult;
import cn.iocoder.yudao.module.document.controller.admin.document.vo.file.DocumentFilePageReqVO;
import cn.iocoder.yudao.module.document.controller.admin.document.vo.file.DocumentFileSaveReqVO;
import cn.iocoder.yudao.module.document.dal.dataobject.DocumentFileDO;
import cn.iocoder.yudao.module.document.framework.onlyoffice.OnlyOfficeConfigVO;

import javax.validation.Valid;

/**
 * 文档文件 Service 接口
 *
 * @author eip-build
 */
public interface DocumentFileService {

    /**
     * 创建文档文件元信息（文件实体已在调用方通过 FileApi 上传完成）
     *
     * @param createReqVO 创建信息
     * @return 文件编号
     */
    Long createFile(@Valid DocumentFileSaveReqVO createReqVO);

    /**
     * 更新文档文件元信息
     *
     * @param updateReqVO 更新信息
     */
    void updateFile(@Valid DocumentFileSaveReqVO updateReqVO);

    /**
     * 删除文档文件（同时删除文件存储实体）
     *
     * @param id 编号
     */
    void deleteFile(Long id);

    /**
     * 获得文档文件
     *
     * @param id 编号
     * @return 文件
     */
    DocumentFileDO getFile(Long id);

    /**
     * 文档文件分页
     *
     * @param pageReqVO 分页请求
     * @return 分页结果
     */
    PageResult<DocumentFileDO> getFilePage(DocumentFilePageReqVO pageReqVO);

    /**
     * 构建 OnlyOffice 编辑器配置（打开文档，供在线预览/编辑）
     *
     * @param id       文件编号
     * @param mode     打开模式：view-只读预览；edit-在线编辑
     * @return OnlyOffice 编辑器配置
     */
    OnlyOfficeConfigVO getOnlyOfficeConfig(Long id, String mode);

    /**
     * 处理 OnlyOffice 保存回调：拉取已编辑的文件内容并写回存储
     *
     * @param key  文档 key（对应文件编号的字符串）
     * @param url  修改后文档的下载地址（OnlyOffice 提供）
     */
    void handleCallbackSave(String key, String url);

}
