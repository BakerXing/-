package cn.iocoder.yudao.module.document.controller.admin.document;

import cn.iocoder.yudao.framework.common.pojo.CommonResult;
import cn.iocoder.yudao.module.document.controller.admin.document.vo.dir.DocumentDirRespVO;
import cn.iocoder.yudao.module.document.controller.admin.document.vo.dir.DocumentDirSaveReqVO;
import cn.iocoder.yudao.module.document.convert.DocumentConvert;
import cn.iocoder.yudao.module.document.dal.dataobject.DocumentDirDO;
import cn.iocoder.yudao.module.document.service.document.DocumentDirService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.tags.Tag;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;

import javax.annotation.Resource;
import javax.validation.Valid;
import java.util.List;

import static cn.iocoder.yudao.framework.common.pojo.CommonResult.success;

/**
 * 管理后台 - 文档目录
 *
 * 所有接口均接入系统原生权限体系 {@code @PreAuthorize("@ss.hasPermission(...)")}，
 * 禁止匿名访问。
 *
 * @author eip-build
 */
@Tag(name = "管理后台 - 文档目录")
@RestController
@RequestMapping("/document/dir")
@Validated
public class DocumentDirController {

    @Resource
    private DocumentDirService dirService;

    @PostMapping("/create")
    @Operation(summary = "创建文档目录")
    @PreAuthorize("@ss.hasPermission('document:dir:create')")
    public CommonResult<Long> createDir(@Valid @RequestBody DocumentDirSaveReqVO createReqVO) {
        return success(dirService.createDir(createReqVO));
    }

    @PutMapping("/update")
    @Operation(summary = "更新文档目录")
    @PreAuthorize("@ss.hasPermission('document:dir:update')")
    public CommonResult<Boolean> updateDir(@Valid @RequestBody DocumentDirSaveReqVO updateReqVO) {
        dirService.updateDir(updateReqVO);
        return success(true);
    }

    @DeleteMapping("/delete")
    @Operation(summary = "删除文档目录")
    @Parameter(name = "id", description = "目录编号", required = true)
    @PreAuthorize("@ss.hasPermission('document:dir:delete')")
    public CommonResult<Boolean> deleteDir(@RequestParam("id") Long id) {
        dirService.deleteDir(id);
        return success(true);
    }

    @GetMapping("/get")
    @Operation(summary = "获得文档目录")
    @Parameter(name = "id", description = "目录编号", required = true)
    @PreAuthorize("@ss.hasPermission('document:dir:query')")
    public CommonResult<DocumentDirRespVO> getDir(@RequestParam("id") Long id) {
        DocumentDirDO dir = dirService.getDir(id);
        return success(DocumentConvert.INSTANCE.convert(dir));
    }

    @GetMapping("/list")
    @Operation(summary = "获得某父目录下的子目录列表")
    @Parameter(name = "parentId", description = "父目录编号，不传默认根目录(0)")
    @PreAuthorize("@ss.hasPermission('document:dir:query')")
    public CommonResult<List<DocumentDirRespVO>> getDirList(
            @RequestParam(value = "parentId", required = false) Long parentId) {
        List<DocumentDirDO> list = dirService.getDirList(parentId);
        return success(DocumentConvert.INSTANCE.toDirRespList(list));
    }

}
