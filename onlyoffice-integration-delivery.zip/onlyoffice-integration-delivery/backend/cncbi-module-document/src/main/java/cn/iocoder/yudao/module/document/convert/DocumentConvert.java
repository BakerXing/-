package cn.iocoder.yudao.module.document.convert;

import cn.iocoder.yudao.framework.common.util.object.BeanUtils;
import cn.iocoder.yudao.module.document.controller.admin.document.vo.dir.DocumentDirRespVO;
import cn.iocoder.yudao.module.document.controller.admin.document.vo.file.DocumentFileRespVO;
import cn.iocoder.yudao.module.document.dal.dataobject.DocumentDirDO;
import cn.iocoder.yudao.module.document.dal.dataobject.DocumentFileDO;
import org.mapstruct.Mapper;
import org.mapstruct.factory.Mappers;

import java.util.List;

/**
 * 文档中心 Convert 转换器
 *
 * DO 与 VO 之间的对象转换，统一使用框架的 BeanUtils/mapstruct（与现有模块一致）。
 *
 * @author eip-build
 */
@Mapper
public interface DocumentConvert {

    DocumentConvert INSTANCE = Mappers.getMapper(DocumentConvert.class);

    /**
     * 目录 DO → 目录 RespVO
     */
    DocumentDirRespVO convert(DocumentDirDO bean);

    /**
     * 目录 DO 列表 → 目录 RespVO 列表
     */
    default List<DocumentDirRespVO> toDirRespList(List<DocumentDirDO> list) {
        return BeanUtils.toBean(list, DocumentDirRespVO.class);
    }

    /**
     * 文件 DO → 文件 RespVO
     */
    default DocumentFileRespVO convert(DocumentFileDO bean) {
        return BeanUtils.toBean(bean, DocumentFileRespVO.class);
    }

    /**
     * 文件 DO 列表 → 文件 RespVO 列表
     */
    default List<DocumentFileRespVO> toFileRespList(List<DocumentFileDO> list) {
        return BeanUtils.toBean(list, DocumentFileRespVO.class);
    }

}
