package cn.iocoder.yudao.module.document.service.document;

import cn.iocoder.yudao.module.document.controller.admin.document.vo.dir.DocumentDirSaveReqVO;
import cn.iocoder.yudao.module.document.dal.dataobject.DocumentDirDO;
import cn.iocoder.yudao.module.document.dal.mysql.DocumentDirMapper;
import cn.iocoder.yudao.module.document.dal.mysql.DocumentFileMapper;
import org.springframework.stereotype.Service;
import org.springframework.validation.annotation.Validated;

import javax.annotation.Resource;
import java.util.List;
import java.util.Objects;

import static cn.iocoder.yudao.framework.common.exception.util.ServiceExceptionUtil.exception;
import static cn.iocoder.yudao.module.document.enums.ErrorCodeConstants.*;

/**
 * 文档目录 Service 实现类
 *
 * 说明：目录删除前需校验是否有子目录/文件，保证数据一致性；
 *       目录重名校验限定在“同一父目录下”，与文件存储策略解耦。
 *
 * @author eip-build
 */
@Service
@Validated
public class DocumentDirServiceImpl implements DocumentDirService {

    @Resource
    private DocumentDirMapper documentDirMapper;

    @Resource
    private DocumentFileMapper documentFileMapper;

    @Override
    public Long createDir(DocumentDirSaveReqVO createReqVO) {
        // 1. 校验父目录是否存在
        validateParentDir(createReqVO.getParentId());
        // 2. 校验同一父目录下目录名唯一
        validateDirNameUnique(createReqVO.getParentId(), createReqVO.getName(), null);

        // 3. 入库
        DocumentDirDO dir = DocumentDirDO.builder()
                .name(createReqVO.getName())
                .parentId(createReqVO.getParentId())
                .sort(createReqVO.getSort() == null ? 0 : createReqVO.getSort())
                .remark(createReqVO.getRemark())
                .build();
        documentDirMapper.insert(dir);
        return dir.getId();
    }

    @Override
    public void updateDir(DocumentDirSaveReqVO updateReqVO) {
        // 校验目录是否存在
        DocumentDirDO dir = validateDirExists(updateReqVO.getId());
        // 校验父目录是否存在（排除自身）
        validateParentDir(updateReqVO.getParentId());
        // 校验同一父目录下目录名唯一（排除自身）
        validateDirNameUnique(updateReqVO.getParentId(), updateReqVO.getName(), updateReqVO.getId());

        // 更新
        DocumentDirDO updateObj = DocumentDirDO.builder()
                .id(updateReqVO.getId())
                .name(updateReqVO.getName())
                .parentId(updateReqVO.getParentId())
                .sort(updateReqVO.getSort() == null ? dir.getSort() : updateReqVO.getSort())
                .remark(updateReqVO.getRemark())
                .build();
        documentDirMapper.updateById(updateObj);
    }

    @Override
    public void deleteDir(Long id) {
        // 校验目录是否存在
        validateDirExists(id);
        // 校验目录下是否存在子目录
        if (!documentDirMapper.selectListByParentId(id).isEmpty()) {
            throw exception(DOC_DIR_NOT_EMPTY);
        }
        // 校验目录下是否存在文件
        if (!documentFileMapper.selectListByDirId(id).isEmpty()) {
            throw exception(DOC_DIR_NOT_EMPTY);
        }
        // 删除目录
        documentDirMapper.deleteById(id);
    }

    @Override
    public DocumentDirDO getDir(Long id) {
        return validateDirExists(id);
    }

    @Override
    public List<DocumentDirDO> getDirList(Long parentId) {
        Long pid = parentId == null ? 0L : parentId;
        return documentDirMapper.selectListByParentId(pid);
    }

    private DocumentDirDO validateDirExists(Long id) {
        DocumentDirDO dir = documentDirMapper.selectById(id);
        if (dir == null) {
            throw exception(DOC_DIR_NOT_EXISTS);
        }
        return dir;
    }

    private void validateParentDir(Long parentId) {
        if (Objects.equals(parentId, 0L) || parentId == null) {
            return;
        }
        validateDirExists(parentId);
    }

    private void validateDirNameUnique(Long parentId, String name, Long excludeId) {
        Long pid = parentId == null ? 0L : parentId;
        DocumentDirDO exist = documentDirMapper.selectListByParentId(pid).stream()
                .filter(d -> d.getName().equals(name))
                .filter(d -> !Objects.equals(d.getId(), excludeId))
                .findFirst()
                .orElse(null);
        if (exist != null) {
            throw exception(DOC_DIR_NAME_DUPLICATE);
        }
    }

}
