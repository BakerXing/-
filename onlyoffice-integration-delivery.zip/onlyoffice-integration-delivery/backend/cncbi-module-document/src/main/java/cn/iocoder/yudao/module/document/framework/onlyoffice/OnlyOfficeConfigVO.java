package cn.iocoder.yudao.module.document.framework.onlyoffice;

import io.swagger.v3.oas.annotations.media.Schema;
import cn.hutool.core.util.StrUtil;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;
import java.util.Collections;
import java.util.Map;

/**
 * OnlyOffice 编辑器打开文档所需的配置 Response
 *
 * 该对象的 JSON 结构严格对齐 OnlyOffice Document Server API 规范，
 * 由前端 {@code DocsAPI.DocEditor("placeholder", config)} 直接消费。
 *
 * 参考：https://api.onlyoffice.com/docs/docs-api/config/config/
 *
 * @author eip-build
 */
@Schema(description = "OnlyOffice 编辑器配置 Response")
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class OnlyOfficeConfigVO implements Serializable {

    @Schema(description = "文档类型：word/cell/slide")
    private String documentType;

    @Schema(description = "文档配置")
    private Document document;

    @Schema(description = "编辑器配置")
    private EditorConfig editorConfig;

    @Schema(description = "文档令牌（JWT），未启用时为 null")
    private String token;

    @Schema(description = "OnlyOffice Document Server 服务地址（前端加载 JS API 用）")
    private String docServiceUrl;

    @Data
    @Builder
    @NoArgsConstructor
    @AllArgsConstructor
    public static class Document implements Serializable {

        @Schema(description = "文件类型，如 docx/xlsx/pptx")
        private String fileType;

        @Schema(description = "文档唯一标识，通常用业务主键")
        private String key;

        @Schema(description = "文档标题")
        private String title;

        @Schema(description = "文档原始访问 URL（OnlyOffice 拉取文档内容）")
        private String url;

        @Schema(description = "文档权限")
        private Permissions permissions;
    }

    @Data
    @Builder
    @NoArgsConstructor
    @AllArgsConstructor
    public static class Permissions implements Serializable {

        @Schema(description = "是否允许编辑")
        private Boolean edit;

        @Schema(description = "是否允许下载")
        private Boolean download;

        @Schema(description = "是否允许打印")
        private Boolean print;
    }

    @Data
    @Builder
    @NoArgsConstructor
    @AllArgsConstructor
    public static class EditorConfig implements Serializable {

        @Schema(description = "回调地址（文档保存时 OnlyOffice 回调）")
        private String callbackUrl;

        @Schema(description = "编辑器语言，如 zh-CN")
        private String lang;

        @Schema(description = "编辑器模式：edit/view")
        private String mode;

        @Schema(description = "当前操作用户（用于协作与修订记录）")
        private User user;

        @Schema(description = "自定义字段（可透传业务扩展信息）")
        private Map<String, Object> customization;
    }

    @Data
    @Builder
    @NoArgsConstructor
    @AllArgsConstructor
    public static class User implements Serializable {

        @Schema(description = "用户标识")
        private String id;

        @Schema(description = "用户显示名")
        private String name;
    }

    /**
     * 便捷构造：只读预览模式
     */
    public static OnlyOfficeConfigVO preview(String fileType, String key, String title,
                                             String url, String callbackUrl, Long userId, String username, String docServiceUrl) {
        return build(fileType, key, title, url, callbackUrl, userId, username, false, docServiceUrl, null);
    }

    /**
     * 便捷构造：可编辑模式
     */
    public static OnlyOfficeConfigVO edit(String fileType, String key, String title,
                                          String url, String callbackUrl, Long userId, String username, String docServiceUrl) {
        return build(fileType, key, title, url, callbackUrl, userId, username, true, docServiceUrl, null);
    }

    /**
     * 便捷构造：带 JWT 的只读预览模式
     */
    public static OnlyOfficeConfigVO preview(String fileType, String key, String title,
                                             String url, String callbackUrl, Long userId, String username,
                                             String docServiceUrl, String jwtSecret) {
        return build(fileType, key, title, url, callbackUrl, userId, username, false, docServiceUrl, jwtSecret);
    }

    /**
     * 便捷构造：带 JWT 的可编辑模式
     */
    public static OnlyOfficeConfigVO edit(String fileType, String key, String title,
                                          String url, String callbackUrl, Long userId, String username,
                                          String docServiceUrl, String jwtSecret) {
        return build(fileType, key, title, url, callbackUrl, userId, username, true, docServiceUrl, jwtSecret);
    }

    private static OnlyOfficeConfigVO build(String fileType, String key, String title,
                                            String url, String callbackUrl, Long userId, String username,
                                            boolean editable, String docServiceUrl, String jwtSecret) {
        Permissions permissions = Permissions.builder()
                .edit(editable)
                .download(editable)
                .print(true)
                .build();
        Document document = Document.builder()
                .fileType(fileType)
                .key(key)
                .title(title)
                .url(url)
                .permissions(permissions)
                .build();
        EditorConfig editorConfig = EditorConfig.builder()
                .callbackUrl(callbackUrl)
                .lang("zh-CN")
                .mode(editable ? "edit" : "view")
                .user(User.builder().id(String.valueOf(userId)).name(username).build())
                .customization(Collections.emptyMap())
                .build();
        OnlyOfficeConfigVO vo = OnlyOfficeConfigVO.builder()
                .documentType(documentTypeOf(fileType))
                .document(document)
                .editorConfig(editorConfig)
                .docServiceUrl(docServiceUrl)
                .build();

        // 若配置了 JWT 密钥，则生成 OnlyOffice 所需的浏览器令牌（browser token）
        if (StrUtil.isNotBlank(jwtSecret)) {
            vo.setToken(OnlyOfficeJwtUtils.generate(buildTokenPayload(vo), jwtSecret));
        }
        return vo;
    }

    /**
     * 构建参与 JWT 签名的 payload。
     *
     * 注意：OnlyOffice browser token 的 payload 为配置对象（含 document、editorConfig、documentType），
     * 但不含 token 字段本身，避免自引用。
     */
    private static java.util.Map<String, Object> buildTokenPayload(OnlyOfficeConfigVO vo) {
        java.util.Map<String, Object> payload = new java.util.LinkedHashMap<>();
        payload.put("documentType", vo.getDocumentType());
        payload.put("document", vo.getDocument());
        payload.put("editorConfig", vo.getEditorConfig());
        payload.put("docServiceUrl", vo.getDocServiceUrl());
        return payload;
    }

    /**
     * 根据文件扩展名推导 OnlyOffice 文档类型
     *
     * @param fileType 文件扩展名（不含点），如 docx/xlsx/pptx
     * @return OnlyOffice 文档类型：word/cell/slide
     */
    public static String documentTypeOf(String fileType) {
        if (fileType == null) {
            return "word";
        }
        switch (fileType.toLowerCase()) {
            case "xlsx":
            case "xls":
            case "csv":
            case "ods":
                return "cell";
            case "pptx":
            case "ppt":
            case "odp":
                return "slide";
            default:
                return "word";
        }
    }

}
