package cn.iocoder.yudao.module.document.dal.mysql;

import cn.iocoder.yudao.framework.common.pojo.PageResult;
import cn.iocoder.yudao.framework.mybatis.core.mapper.BaseMapperX;
import cn.iocoder.yudao.framework.mybatis.core.query.LambdaQueryWrapperX;
import cn.iocoder.yudao.module.document.controller.admin.document.vo.file.DocumentFilePageReqVO;
import cn.iocoder.yudao.module.document.dal.dataobject.DocumentFileDO;
import org.apache.ibatis.annotations.Mapper;

import java.util.List;

/**
 * 文档文件 Mapper
 *
 * @author eip-build
 */
@Mapper
public interface DocumentFileMapper extends BaseMapperX<DocumentFileDO> {

    /**
     * 分页查询文档文件
     *
     * @param reqVO 分页请求
     * @return 分页结果
     */
    default PageResult<DocumentFileDO> selectPage(DocumentFilePageReqVO reqVO) {
        return selectPage(reqVO, new LambdaQueryWrapperX<DocumentFileDO>()
                .eqIfPresent(DocumentFileDO::getDirId, reqVO.getDirId())
                .likeIfPresent(DocumentFileDO::getName, reqVO.getName())
                .betweenIfPresent(DocumentFileDO::getCreateTime, reqVO.getCreateTime())
                .orderByDesc(DocumentFileDO::getId));
    }

    /**
     * 查询指定目录下的所有文件（用于删除目录前校验目录是否为空）
     *
     * @param dirId 目录编号
     * @return 文件列表
     */
    default List<DocumentFileDO> selectListByDirId(Long dirId) {
        return selectList(new LambdaQueryWrapperX<DocumentFileDO>()
                .eq(DocumentFileDO::getDirId, dirId));
    }

    /**
     * 查询指定目录下指定名称的文件（忽略逻辑删除，用于查重）
     *
     * @param dirId 目录编号
     * @param name  文件名称
     * @return 文件，不存在返回 null
     */
    default DocumentFileDO selectByDirIdAndName(Long dirId, String name) {
        return selectOne(new LambdaQueryWrapperX<DocumentFileDO>()
                .eq(DocumentFileDO::getDirId, dirId)
                .eq(DocumentFileDO::getName, name));
    }

}
