package cn.iocoder.yudao.module.document.dal.mysql;

import cn.iocoder.yudao.framework.mybatis.core.mapper.BaseMapperX;
import cn.iocoder.yudao.framework.mybatis.core.query.LambdaQueryWrapperX;
import cn.iocoder.yudao.module.document.dal.dataobject.DocumentDirDO;
import org.apache.ibatis.annotations.Mapper;

import java.util.List;

/**
 * 文档目录 Mapper
 *
 * @author eip-build
 */
@Mapper
public interface DocumentDirMapper extends BaseMapperX<DocumentDirDO> {

    /**
     * 查询指定父目录下的所有子目录（用于删除前校验目录是否为空）
     *
     * @param parentId 父目录编号
     * @return 子目录列表
     */
    default List<DocumentDirDO> selectListByParentId(Long parentId) {
        return selectList(new LambdaQueryWrapperX<DocumentDirDO>()
                .eq(DocumentDirDO::getParentId, parentId));
    }

}
