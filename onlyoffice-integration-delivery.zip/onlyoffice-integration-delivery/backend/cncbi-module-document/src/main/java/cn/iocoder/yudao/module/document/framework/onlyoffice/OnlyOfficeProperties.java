package cn.iocoder.yudao.module.document.framework.onlyoffice;

import lombok.Data;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.stereotype.Component;

/**
 * OnlyOffice 配置类
 *
 * 读取 application.yml 中 {@code yudao.onlyoffice} 前缀的配置。
 * 所有 OnlyOffice 服务地址、回调地址均从配置注入，禁止在代码中硬编码 IP/域名，
 * 满足“银行内网无外网 + 多环境通过配置区分”的约束。
 *
 * <p>示例配置（云服务器测试环境）：</p>
 * <pre>
 * yudao:
 *   onlyoffice:
 *     doc-service-url: http://10.1.0.14:8080      # OnlyOffice Document Server 地址
 *     callback-url: http://<云服务器公网地址>:48080/admin-api/document/onlyoffice/callback  # 回调地址
 *     jwt-secret: ''                                # 若 OnlyOffice 启用了 JWT，则填写对应 secret
 * </pre>
 *
 * @author eip-build
 */
@ConfigurationProperties(prefix = "yudao.onlyoffice")
@Component
@Data
public class OnlyOfficeProperties {

    /**
     * OnlyOffice Document Server 服务地址（例如 http://10.1.0.14:8080），不含末尾斜杠
     */
    private String docServiceUrl;

    /**
     * OnlyOffice 回调地址：文档保存时由 OnlyOffice 回调本后端接口的完整 URL。
     * 该地址必须是 OnlyOffice 服务（容器）能够访问到的地址（通常为后端公网/内网可达地址）。
     */
    private String callbackUrl;

    /**
     * JWT 密钥：与 OnlyOffice 服务端配置一致；未启用 JWT 时留空字符串。
     */
    private String jwtSecret = "";

    /**
     * 是否对文档启用视图评论/聊天等增强能力（预留），默认关闭
     */
    private Boolean enableComments = false;

}
