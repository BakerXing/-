package cn.iocoder.yudao.module.document.dal.dataobject;

import cn.iocoder.yudao.framework.mybatis.core.dataobject.BaseDO;
import com.baomidou.mybatisplus.annotation.TableName;
import lombok.*;

import java.time.LocalDateTime;

/**
 * 文档文件 DO
 *
 * 记录上传至文档中心的文件元信息。文件实体内容复用 infra 模块统一文件存储，
 * 通过 {@link #filePath}（FileApi 返回的相对访问路径）定位实际文件。
 * {@link #permissionType} 与 {@link #version} 为预留扩展字段，后续迭代用于权限与版本管理。
 *
 * @author eip-build
 */
@TableName("document_file")
@Data
@EqualsAndHashCode(callSuper = true)
@ToString(callSuper = true)
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class DocumentFileDO extends BaseDO {

    /**
     * 文件编号，数据库自增
     */
    private Long id;

    /**
     * CNCBI 文档编号
     */
    private String docNo;

    /**
     * 所属目录编号，关联 {@link DocumentDirDO#getId()}，0 表示根目录
     */
    private Long dirId;

    /**
     * 文件名称（含扩展名）
     */
    private String name;

    /**
     * 文件存储路径（FileApi 返回的相对访问路径）
     */
    private String filePath;

    /**
     * 文件大小，单位：字节
     */
    private Long fileSize;

    /**
     * 文件扩展名，如 docx/xlsx/pptx/pdf
     */
    private String fileExt;

    /**
     * 文件 MIME 类型
     */
    private String fileType;

    /**
     * 文件权限类型（预留字段）
     * 1-仅自己可见 2-指定人可见 3-公开只读
     */
    private Integer permissionType;

    /**
     * 文件版本号（预留字段）
     */
    private Integer version;

    /**
     * 审核日期
     */
    private LocalDateTime auditTime;

    /**
     * 文件备注
     */
    private String remark;

}
