package cn.iocoder.yudao.module.document.framework.onlyoffice;

import cn.hutool.core.codec.Base64;
import cn.hutool.crypto.digest.HMac;
import cn.hutool.crypto.digest.HmacAlgorithm;
import cn.hutool.json.JSONUtil;

import java.nio.charset.StandardCharsets;
import java.util.Map;

/**
 * OnlyOffice JWT 工具类
 *
 * <p>OnlyOffice Document Server 在启用 JWT 校验时（local.json 中 token.enable.browser=true），
 * 要求编辑器配置对象中携带一个由服务端签发的 JWT。其结构与标准 JWT 一致（HS256）：</p>
 * <pre>
 *   header  = {"alg":"HS256","typ":"JWT"}
 *   payload = 编辑器配置对象（不含 token 字段）的 JSON 序列化结果
 *   token   = base64Url(header).base64Url(payload).base64Url(HMAC-SHA256(header.payload, secret))
 * </pre>
 *
 * <p>密钥必须与 OnlyOffice 服务端 <code>local.json</code> 中
 * <code>services.CoAuthoring.secret.inbox/outbox/session.string</code> 保持一致。</p>
 *
 * @author eip-build
 */
public class OnlyOfficeJwtUtils {

    /**
     * 生成 OnlyOffice 所需的 JWT。
     *
     * @param payload 编辑器配置对象（不含 token 字段）
     * @param secret  JWT 密钥（与 OnlyOffice 服务端一致）
     * @return JWT 字符串
     */
    public static String generate(Map<String, Object> payload, String secret) {
        // 1. header
        String header = "{\"alg\":\"HS256\",\"typ\":\"JWT\"}";
        String headerBase64 = base64UrlEncode(header.getBytes(StandardCharsets.UTF_8));

        // 2. payload
        String payloadJson = JSONUtil.toJsonStr(payload);
        String payloadBase64 = base64UrlEncode(payloadJson.getBytes(StandardCharsets.UTF_8));

        // 3. signature
        String signingInput = headerBase64 + "." + payloadBase64;
        HMac hmac = new HMac(HmacAlgorithm.HmacSHA256, secret.getBytes(StandardCharsets.UTF_8));
        String signature = base64UrlEncode(hmac.digest(signingInput));

        return signingInput + "." + signature;
    }

    private static String base64UrlEncode(byte[] bytes) {
        return Base64.encodeUrlSafe(bytes);
    }
}
