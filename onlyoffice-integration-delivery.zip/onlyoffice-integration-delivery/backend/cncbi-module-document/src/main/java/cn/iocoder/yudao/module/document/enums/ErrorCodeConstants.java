package cn.iocoder.yudao.module.document.enums;

import cn.iocoder.yudao.framework.common.exception.ErrorCode;

/**
 * 文档中心模块错误码枚举
 *
 * 错误码区间规划：{@code 1_017_000_000 + xxx}
 * 说明：登录鉴权类错误码复用框架全局的 {@code GlobalErrorCodeConstants}，此处只定义模块业务错误。
 *
 * @author eip-build
 */
public interface ErrorCodeConstants {

    // ========== 文档目录 1_017_000_000 ==========
    ErrorCode DOC_DIR_NOT_EXISTS = new ErrorCode(1_017_000_000, "文档目录不存在");
    ErrorCode DOC_DIR_NAME_DUPLICATE = new ErrorCode(1_017_000_001, "同级目录下已存在同名目录");
    ErrorCode DOC_DIR_NOT_EMPTY = new ErrorCode(1_017_000_002, "目录下存在子目录或文件，无法删除");

    // ========== 文档文件 1_017_001_000 ==========
    ErrorCode DOC_FILE_NOT_EXISTS = new ErrorCode(1_017_001_000, "文档文件不存在");
    ErrorCode DOC_FILE_NAME_DUPLICATE = new ErrorCode(1_017_001_001, "同一目录下已存在同名文件");
    ErrorCode DOC_FILE_FORMAT_NOT_SUPPORT = new ErrorCode(1_017_001_002, "暂不支持该文件格式的在线预览/编辑");

    // ========== OnlyOffice 1_017_002_000 ==========
    ErrorCode ONLYOFFICE_CALLBACK_INVALID = new ErrorCode(1_017_002_000, "OnlyOffice 回调参数不合法");
    ErrorCode ONLYOFFICE_CALLBACK_SAVE_FAIL = new ErrorCode(1_017_002_001, "OnlyOffice 回调保存失败");
    ErrorCode ONLYOFFICE_CONFIG_ERROR = new ErrorCode(1_017_002_002, "OnlyOffice 服务地址未配置，请检查 application.yml");
}
