package cn.iocoder.yudao.module.document.controller.admin.document.vo.dir;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.ToString;

@Schema(description = "管理后台 - 文档目录创建/修改 Request VO")
@Data
@EqualsAndHashCode(callSuper = true)
@ToString(callSuper = true)
public class DocumentDirSaveReqVO extends DocumentDirBaseVO {

    @Schema(description = "目录编号，修改时必传", example = "1")
    private Long id;

}
