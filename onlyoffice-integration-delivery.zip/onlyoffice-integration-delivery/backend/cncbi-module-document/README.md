# 文档中心模块（cncbi-module-document）

对接 OnlyOffice Document Server，实现文档在线预览、在线编辑。

## 模块定位

- 完全独立的 Maven 模块，`cn.iocoder.yudao.module.document` 包下，不侵入任何原有模块。
- 复用框架/基础设施能力：登录鉴权、`FileApi` 统一文件存储、`BeanUtils`、统一异常。
- 文件实体复用 infra 模块统一文件存储策略；`document_file.file_path` 保存上传后返回的
  完整访问 URL（形如 `{domain}/admin-api/infra/file/{configId}/get/{path}`），OnlyOffice 可直接拉取。

## 目录结构

```
cncbi-module-document
└── src/main
    ├── java/cn/iocoder/yudao/module/document
    │   ├── controller/admin/document
    │   │   ├── DocumentDirController.java         # 目录管理
    │   │   ├── DocumentFileController.java        # 文件管理 + OnlyOffice 配置入口
    │   │   ├── OnlyOfficeCallbackController.java  # OnlyOffice 保存回调（JWT 校验）
    │   │   └── vo/{dir,file}/*                    # 请求/响应 VO
    │   ├── convert/DocumentConvert.java           # DO/VO 转换
    │   ├── dal/dataobject/*.java                  # DocumentDirDO / DocumentFileDO
    │   ├── dal/mysql/*.java                       # Mapper
    │   ├── enums/ErrorCodeConstants.java          # 错误码
    │   ├── framework/onlyoffice/*                 # OnlyOffice 配置/回调 DTO/编辑器配置 VO
    │   └── service/document/*                     # Service 接口 + 实现
    └── resources
        ├── sql/mysql/document.sql                 # 建表 SQL
        ├── sql/mysql/menu.sql                     # 菜单/权限 SQL
        └── config/application-document-*.yaml     # 双环境配置样例
```

## 关键约定

1. **鉴权**：所有业务接口 `@PreAuthorize("@ss.hasPermission('document:*')")`；
   OnlyOffice 回调接口无登录态，改用 `Authorization` 请求头 + `jwt-secret` 校验。
2. **回调地址**：必须加入 `yudao.security.permit-all_urls`。
3. **多环境**：OnlyOffice 服务地址、回调地址全部走 `yudao.onlyoffice.*` 配置，无硬编码。

## 交互时序

见 `docs/` 或交付文档第 7 节。
