# OnlyOffice 在线预览/编辑 —— 增量集成部署文档

> 目标：把已验证的 OnlyOffice 集成代码，以**增量**方式集成到公司芋道（RuoYi-Vue-Pro）项目。
> 适用版本：芋道 `cn.iocoder.yudao.*` 包结构，后端 Spring Boot，前端 Vue3 + Element Plus。
> 业务包前导：所有新增代码统一使用 `cn.iocoder.yudao.module.document.*`（与现有芋道结构对齐）。

---

## 一、整体架构

```
┌─────────────┐      浏览器       ┌──────────────┐       ┌──────────────────────┐
│  前端 Vue3   │ ───────────────▶ │  nginx (8088) │────▶ │  后端 Spring Boot     │
│  (editor.vue)│                  │  /admin-api   │      │  (48080)              │
└─────┬───────┘                  └──────────────┘      │  · document 模块      │
      │ ① 加载 OnlyOffice JS API (.js)                  │  · infra 文件存储      │
      ▼                                                  └─────────┬────────────┘
┌─────────────────────────────┐                                    │ ③ 拉取文档内容
│ OnlyOffice Document Server   │◀──── ② 浏览器直接连接（公网 8080）  ▼
│ (docker, 8080→80, JWT开启)    │                          ┌──────────────┐
└──────────┬──────────────────┘                          │ 文件存储      │
           │ ④ 保存后回调（服务端→服务端, 内网）              │ (本地磁盘/DB) │
           └───────────────────────────────────────────▶ │              │
                      callback: /document/onlyoffice/callback
```

**两个回调地址的用途差异（关键）：**
- `doc-service-url`：指向前端浏览器能访问的 OnlyOffice 地址（**公网**，如 `http://119.29.60.179:8080`），用于浏览器加载 `api.js` 和直连编辑器。
- `callback-url`：指向前端 OnlyOffice 服务能访问的后端地址（**内网可达**即可，如 `http://10.1.0.14:48080/...`），用于文档保存后服务端间回调。

---

## 二、后端新增模块（增量）

> 新增一个独立 Maven 模块 `cncbi-module-document`（可整体复制）。

### 2.1 模块清单

| 文件 | 功能说明 |
|---|---|
| `pom.xml` | 模块定义，依赖 `infra`(FileApi)、`tenant`、`security`、`mybatis` |
| `framework/onlyoffice/OnlyOfficeProperties.java` | OnlyOffice 配置注入类（读 `yudao.onlyoffice.*`） |
| `framework/onlyoffice/OnlyOfficeConfigVO.java` | 编辑器配置 VO，JSON 严格对齐 OnlyOffice API，含 `preview/edit` 构造方法 |
| `framework/onlyoffice/OnlyOfficeJwtUtils.java` | JWT 生成工具（HS256），OnlyOffice 开启 JWT 时签名浏览器令牌 |
| `framework/onlyoffice/OnlyOfficeCallbackDTO.java` | 保存回调请求 DTO，对齐 OnlyOffice 回调 JSON |
| `controller/admin/document/OnlyOfficeCallbackController.java` | 回调接口（免登录、共享密钥校验） |
| `service/document/DocumentFileService.java` | 文件服务接口（含 OnlyOffice 两个方法） |
| `service/document/DocumentFileServiceImpl.java` | 文件服务实现（含 `getOnlyOfficeConfig`、`handleCallbackSave`） |
| `enums/ErrorCodeConstants.java` | 错误码（ONLYOFFICE_* 三个） |

### 2.2 各文件代码功能详解

#### （1）`OnlyOfficeProperties.java` —— 配置注入
- 读取 `application.yml` 中 `yudao.onlyoffice` 前缀配置。
- 4 个属性：`docServiceUrl`、`callbackUrl`、`jwtSecret`、`enableComments`。
- **所有地址由配置注入，禁止硬编码 IP**（满足内网/多环境约束）。

#### （2）`OnlyOfficeJwtUtils.java` —— JWT 生成
- 当 OnlyOffice `JWT_ENABLED=true` 时，编辑器配置需携带服务端签发的 JWT。
- 用 Hutool 的 HMac(HmacSHA256) 生成标准 HS256 JWT：`base64Url(header).base64Url(payload).base64Url(signature)`。
- 密钥必须与 OnlyOffice `local.json`（或 compose `JWT_SECRET`）一致。

#### （3）`OnlyOfficeConfigVO.java` —— 编辑器配置
- 输出结构：`documentType` / `document`（fileType/key/title/url/permissions）/ `editorConfig`（callbackUrl/lang/mode/user/customization）/ `token` / `docServiceUrl`。
- 提供 `preview()` 和 `edit()` 工厂方法（含带 JWT 重载）。
- `documentTypeOf()` 按扩展名映射 word/cell/slide。
- 关键：payload 签名时**排除 token 字段本身**，避免自引用导致 JWT 校验失败。

#### （4）`OnlyOfficeCallbackDTO.java` —— 回调 DTO
- 字段：`status`(0~7)、`key`、`url`、`actions`、`history`、`error`、`userid`。
- `isSaveStatus()`：仅 status=2（需要保存）/6（强制保存）才落盘。

#### （5）`OnlyOfficeCallbackController.java` —— 回调接口
- `POST /document/onlyoffice/callback`，**无登录态**（服务端到服务端）。
- 安全：若配置了 `jwtSecret`，则校验请求头 `Authorization` 与配置一致；未配置则降级（依赖内网隔离）。
- 逻辑：status 3/7 记错误日志；非保存状态直接返回 0（避免重试）；保存状态调 `handleCallbackSave`。

#### （6）`DocumentFileServiceImpl` —— OnlyOffice 两个核心方法
- `getOnlyOfficeConfig(id, mode)`：校验文件存在 → 校验服务地址已配置 → 取当前登录用户 → 按 `view/edit` 构建配置并返回前端。
- `handleCallbackSave(key, url)`：根据 key（文件ID）定位 → 从 OnlyOffice 下载地址拉取编辑后内容（HttpUtil）→ `fileApi.createFile()` 重新写入统一存储 → 更新 filePath/fileSize/version 递增。

#### （7）`DocumentFileController.java` —— OnlyOffice 入口
- `GET /document/file/onlyoffice-config?id=&mode=`：返回编辑器配置（`@PreAuthorize('document:file:query')`）。
- 其余为文件的增删改查（继承自文档中心，可按需裁剪）。

### 2.3 关键实现参考（getOnlyOfficeConfig 伪代码）

```java
public OnlyOfficeConfigVO getOnlyOfficeConfig(Long id, String mode) {
    DocumentFileDO file = validateFileExists(id);                 // 1. 校验存在
    if (StrUtil.isBlank(docServiceUrl) || StrUtil.isBlank(callbackUrl))
        throw exception(ONLYOFFICE_CONFIG_ERROR);                 // 2. 校验配置
    boolean editable = "edit".equalsIgnoreCase(mode);            // 3. view/edit
    String username = ...;                                        // 4. 取登录用户
    // 5. 构建配置（带 JWT）
    return editable
        ? OnlyOfficeConfigVO.edit(file.getFileExt(), id, file.getName(), file.getFilePath(),
            callbackUrl, userId, username, docServiceUrl, jwtSecret)
        : OnlyOfficeConfigVO.preview(...);
}
```

---

## 三、前端新增/改动（增量）

### 3.1 新增文件

| 文件 | 功能说明 |
|---|---|
| `src/views/document/file/editor.vue` | OnlyOffice 编辑器页面（加载 JS API + 初始化编辑器） |
| `src/views/document/file/index.vue` | 文档文件列表页（含「预览/编辑」按钮触发跳转） |

### 3.2 改动文件

| 文件 | 改动 |
|---|---|
| `src/api/document/index.ts` | 新增 `OnlyOfficeConfigVO` 接口 + `DocumentFileApi.getOnlyOfficeConfig(id, mode)` |
| `src/router/modules/remaining.ts` | 新增隐藏路由 `/document/file/editor`（hidden 路由） |

### 3.3 editor.vue 核心逻辑

```ts
// 1. 获取后端配置
const config = await DocumentFileApi.getOnlyOfficeConfig(id, mode)
// 2. 动态加载 OnlyOffice JS API（由 docServiceUrl 拼接，内网无外网依赖）
//    {docServiceUrl}/web-apps/apps/api/documents/api.js
await loadOnlyOfficeScript(config)
// 3. 初始化编辑器
docEditor = new (window).DocsAPI.DocEditor('onlyoffice-editor', {
  ...config,
  height: window.innerHeight - 96 + 'px',   // 撑满视口
  width: '100%',
  type: 'desktop'
})
```

### 3.4 前端 API

```ts
export interface OnlyOfficeConfigVO {
  documentType: string
  document: any
  editorConfig: any
  token?: string
  docServiceUrl?: string
}
// ...
getOnlyOfficeConfig: async (id, mode = 'view') =>
  request.get({ url: `/document/file/onlyoffice-config`, params: { id, mode } })
```

### 3.5 路由（hidden 编辑页）

```ts
{
  path: '/document',
  component: Layout,
  name: 'Document',
  meta: { hidden: true },
  children: [{
    path: 'file/editor',
    component: () => import('@/views/document/file/editor.vue'),
    name: 'DocumentFileEditor',
    meta: { noCache: true, hidden: true, canTo: true, title: '文档预览/编辑', activeMenu: '/document/file' }
  }]
}
```

---

## 四、后端应用配置（增量到 application-dev.yaml / application.yaml）

```yaml
yudao:
  onlyoffice:
    # ① 前端浏览器加载 JS API 用的 OnlyOffice 地址（需浏览器可达，一般为公网/内网办公网）
    doc-service-url: http://<onlyoffice-host>:8080
    # ② OnlyOffice 服务回调后端保存的地址（需 OnlyOffice 服务可达）
    callback-url: http://<backend-host>:48080/admin-api/document/onlyoffice/callback
    # ③ 与 OnlyOffice 服务端 JWT_SECRET 一致；未启用 JWT 则留空 ''
    jwt-secret: '<与OnlyOffice服务端一致的secret>'

  security:
    permit-all_urls:
      - /admin-api/mp/open/**                       # 原有项，合并时保留
      - /admin-api/document/onlyoffice/callback     # 新增：OnlyOffice 回调免登录
  tenant:
    ignore-urls:
      - /jmreport/*                                 # 原有项，合并时保留
      - /admin-api/document/onlyoffice/callback     # 新增：回调无 tenant-id
```

> ⚠️ **注意**：`permit-all_urls` 和 `tenant.ignore-urls` 在芋道里是**整体替换**语义。合并时务必把原有项完整保留 + 追加新增项，否则会误伤原有免登录/租户忽略配置。

---

## 五、数据库（增量）

> 若只需 OnlyOffice 预览/编辑能力，可复用现有文件表；以下为文档模块建表，按需采用。

```sql
CREATE TABLE `document_file` (
  `id`          BIGINT       NOT NULL AUTO_INCREMENT COMMENT '文件编号',
  `doc_no`      VARCHAR(64)           DEFAULT '' COMMENT 'CNCBI 文档编号',
  `dir_id`      BIGINT       NOT NULL DEFAULT 0 COMMENT '所属目录编号，0=根目录',
  `name`        VARCHAR(255) NOT NULL COMMENT '文件名称（含扩展名）',
  `file_path`   VARCHAR(511) NOT NULL COMMENT '文件存储访问路径（infra 返回的完整 URL）',
  `file_size`   BIGINT       NOT NULL DEFAULT 0 COMMENT '文件大小（字节）',
  `file_ext`    VARCHAR(16)  NOT NULL DEFAULT '' COMMENT '扩展名 docx/xlsx/pptx/pdf',
  `file_type`   VARCHAR(128)          DEFAULT '' COMMENT 'MIME 类型',
  `permission_type` TINYINT  NOT NULL DEFAULT 1 COMMENT '权限类型（预留）',
  `version`     INT          NOT NULL DEFAULT 1 COMMENT '版本号',
  `audit_time`  DATETIME              DEFAULT NULL COMMENT '审核日期',
  `remark`      VARCHAR(255)          DEFAULT NULL COMMENT '备注',
  `creator`     VARCHAR(64)           DEFAULT '' COMMENT '创建者',
  `create_time` DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updater`     VARCHAR(64)           DEFAULT '' COMMENT '更新者',
  `update_time` DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `deleted`     BIT(1)       NOT NULL DEFAULT b'0' COMMENT '逻辑删除',
  `tenant_id`   BIGINT       NOT NULL DEFAULT 0 COMMENT '租户编号',
  PRIMARY KEY (`id`),
  KEY `idx_dir_id` (`dir_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='文档文件表';
```

---

## 六、文件存储配置（关键前置）

OnlyOffice 需要从 `filePath`（一个完整 URL）拉取文档内容，因此文件访问接口必须**免登录可读**。芋道 infra 模块已内置：

```java
// infra FileController
@GetMapping("/{configId}/get/**")
@PermitAll        // 免登录
@TenantIgnore     // 免租户
public void getFile(...) { ... }   // 从本地磁盘/DB 读文件流
```

- 因此 `filePath` 格式形如：`http://<前端域名>:8088/admin-api/infra/file/{configId}/get/{存储路径}`。
- 该链路由 nginx `/admin-api/` 反代到后端 48080，OnlyOffice 和浏览器都能免登录拉取。

---

## 七、前端构建与环境

- `VITE_BASE_URL=''`：前端 axios 走同源 `/admin-api`，由 nginx 反代到后端，浏览器只暴露 8088 一个端口。
- `VITE_API_URL=/admin-api`：接口前缀。
- 构建：`pnpm build:local` → 产物在 `dist/`，由 nginx 托管。

---

## 八、OnlyOffice Document Server 部署（容器）

docker-compose.yml（已验证，容器名 `onlyoffice`，端口 8080→80，JWT 开启）：

```yaml
version: "3"
services:
  onlyoffice:
    image: onlyoffice/documentserver:8.2.2
    container_name: onlyoffice
    restart: always
    ports:
      - "8080:80"
    environment:
      - JWT_ENABLED=true
      - JWT_SECRET=<与后端 yudao.onlyoffice.jwt-secret 一致的密钥>
      - JWT_HEADER=Authorization
      - JWT_IN_BODY=true
    volumes:
      - ./data:/var/www/onlyoffice/Data
      - ./logs:/var/log/onlyoffice
      - ./lib:/var/lib/onlyoffice
```

> JWT_SECRET 必须与后端 `yudao.onlyoffice.jwt-secret` 完全一致，否则编辑会话会被 OnlyOffice 拒绝（报「文档安全令牌格式不正确」）。

---

## 九、集成步骤清单（增量给公司）

### 后端
1. **复制模块**：把 `cncbi-module-document` 整个目录复制到公司项目（注意 parent `artifactId` 改公司版，或调整模块坐标）。
2. **父 pom 注册**：在根 `pom.xml` 的 `<modules>` 加入 `cncbi-module-document`。
3. **carnival-server 引入**：在最终启动模块（如 `yudao-server`/`cncbi-server`）的 `pom.xml` 增加 `<dependency>` 引用 `cncbi-module-document`，并确保 `cncbi-module-infra`（含 FileApi）已依赖。
4. **配置注入**：在 `application.yaml`（或 `-dev.yaml`）追加第二节 3 个 `yudao.onlyoffice.*` 配置 + 合并 `security.permit-all_urls`、`tenant.ignore-urls`（**保留原项**）。
5. **建表/加字段**：执行上文 SQL（若复用现有表则只需加 `doc_no`、`audit_time` 字段）。
6. **文件存储确认**：确认主存储可免登录读（infra `/{configId}/get/**` 已 `@PermitAll`）。

### 前端
1. 复制 `src/views/document/file/{index,editor}.vue`。
2. `src/api/document/index.ts` 增加 `getOnlyOfficeConfig`。
3. `remaining.ts` 增加 `/document/file/editor` 隐藏路由。
4. `pnpm install`（如缺依赖）→ `pnpm build:local`。

### OnlyOffice 服务
1. 按第八节 docker-compose 部署，确保 `8080` 对外可达。
2. 确保后端 `callback-url` 是 OnlyOffice 服务能访问到的地址。

### 联调验证
1. 上传一个 docx → 列表出现 → 点「预览」→ 浏览器能打开 OnlyOffice 只读视图。
2. 点「编辑」→ 修改内容 → 保存 → 回调触发 → 刷新后内容已更新（version 递增）。
3. 用假密钥或错误地址验证失败保护（配置漏配时报 `ONLYOFFICE_CONFIG_ERROR`）。

---

## 十、常见问题排查

| 现象 | 原因 | 解决 |
|---|---|---|
| 预览 `ERR_CONNECTION_TIMED_OUT` | `docServiceUrl` 用了浏览器不可达的内网地址 | 改为公网/办公网可达地址 |
| `ERR_CONNECTION_REFUSED`（编辑器内） | `filePath` 文档 URL 浏览器拉不到 | 确认 nginx/后端文件 get 接口可达且免登录 |
| 「文档安全令牌格式不正确」 | JWT_SECRET 前后端不一致 或 未签发 token | 对齐两个 secret；启用 JWT 时确保 `token` 已生成 |
| 保存后内容未更新 | `callback-url` 不被 OnlyOffice 访问到 | 用内网可达地址；确认 permit-all + tenant.ignore |
| `OnlyOffice 服务地址未配置` | 漏配 `yudao.onlyoffice.*` | 补全配置 |
| 大文件上传失败 413 | nginx 默认 1m | nginx 加 `client_max_body_size 50m;` |

---

## 十一、交付物清单

- 后端模块：`cncbi-module-document/`（含全部 Java + pom）
- 前端页面：`editor.vue`、`index.vue`、`api/document/index.ts`、`remaining.ts` 改动
- 配置片段：`application-dev.yaml` 的 onlyoffice/security/tenant 段
- 数据库脚本：`sql/mysql/document.sql`
- OnlyOffice 部署：`docker-compose.yml` 模板
