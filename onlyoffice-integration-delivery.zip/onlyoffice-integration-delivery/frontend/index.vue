<template>
  <ContentWrap>
    <el-row :gutter="16">
      <!-- 右侧：文件列表（无目录树，占满整行） -->
      <el-col :span="24">
        <el-card shadow="never">
          <template #header>
            <div class="flex items-center justify-between">
              <span>文件列表</span>
              <div>
                <el-button type="primary" size="small" @click="triggerUpload">
                  <Icon icon="ep:upload" class="mr-5px" /> 上传文件
                </el-button>
              </div>
            </div>
          </template>

          <!-- 文件表格 -->
          <el-table :data="fileList" v-loading="loading" @row-dblclick="handleOpenDoc">
            <el-table-column label="CNCBI文档编号" prop="docNo" min-width="140" align="center">
              <template #default="{ row }">{{ row.docNo || '-' }}</template>
            </el-table-column>
            <el-table-column label="文档名" min-width="200">
              <template #default="{ row }">
                <Icon icon="ep:document" class="mr-5px" />
                <span>{{ row.name }}</span>
              </template>
            </el-table-column>
            <el-table-column label="所有者" min-width="100" align="center">
              <template #default="{ row }">{{ row.creator || '-' }}</template>
            </el-table-column>
            <el-table-column label="版本" width="120" align="center">
              <template #default="{ row }">{{ formatYmd(row.createTime) }}</template>
            </el-table-column>
            <el-table-column label="创建日期" width="120" align="center">
              <template #default="{ row }">{{ formatYmd(row.createTime) }}</template>
            </el-table-column>
            <el-table-column label="审核日期" width="120" align="center">
              <template #default="{ row }">{{ row.auditTime ? formatYmd(row.auditTime) : '-' }}</template>
            </el-table-column>
            <el-table-column label="大小" width="90" align="center">
              <template #default="{ row }">{{ formatFileSize(row.fileSize) }}</template>
            </el-table-column>
            <el-table-column label="操作" width="220" align="center">
              <template #default="{ row }">
                <el-button link type="primary" @click="handleOpenDoc(row, 'view')">预览</el-button>
                <el-button link type="primary" @click="handleOpenDoc(row, 'edit')">编辑</el-button>
                <el-button link type="danger" @click="handleDeleteFile(row)">删除</el-button>
              </template>
            </el-table-column>
          </el-table>

          <el-empty v-if="!loading && fileList.length === 0" description="暂无文件" />
        </el-card>
      </el-col>
    </el-row>

    <!-- 上传文件：用隐藏 input 手动触发，避免依赖 el-upload 不存在的 open() -->
    <input
      ref="fileInputRef"
      type="file"
      style="display: none"
      accept=".docx,.doc,.xlsx,.xls,.pptx,.ppt,.pdf,.txt,.csv,.odt,.ods,.odp"
      @change="handleFileSelect"
    />
  </ContentWrap>
</template>

<script setup lang="ts">
import { ref, onMounted } from 'vue'
import { useRouter } from 'vue-router'
import { ElMessage, ElMessageBox } from 'element-plus'
import { DocumentFileApi, DocumentFileVO } from '@/api/document'
import { updateFile } from '@/api/infra/file'
import { formatFileSize } from '@/utils/file'

const router = useRouter()

// 无目录树，所有文件归属根目录（dirId=0）
const currentDirId = ref(0)

// 日期格式化为年月日（YYYY-MM-DD），兼容时间戳/字符串/Date
const formatYmd = (val: any): string => {
  if (!val) return '-'
  const d = new Date(val)
  if (isNaN(d.getTime())) return '-'
  const y = d.getFullYear()
  const m = String(d.getMonth() + 1).padStart(2, '0')
  const day = String(d.getDate()).padStart(2, '0')
  return `${y}-${m}-${day}`
}

// ========== 文件列表 ==========
const loading = ref(false)
const fileList = ref<DocumentFileVO[]>([])

const loadFileList = async () => {
  loading.value = true
  try {
    const res = await DocumentFileApi.getFilePage({ dirId: currentDirId.value, pageNo: 1, pageSize: 100 })
    fileList.value = res.list
  } finally {
    loading.value = false
  }
}

// ========== 文件上传 ==========
const fileInputRef = ref()

const triggerUpload = () => {
  fileInputRef.value?.click()
}

const handleFileSelect = async (e: any) => {
  const file = e.target.files?.[0]
  if (!file) return
  await uploadDocumentFile(file)
  // 清空 input，允许重复选择同一文件
  e.target.value = ''
}

const uploadDocumentFile = async (file: File) => {
  const formData = new FormData()
  formData.append('file', file)
  formData.append('directory', `document/dir_${currentDirId.value}`)
  // 复用 infra 统一文件上传接口，返回 { code, data: url, msg }
  const res: any = await updateFile(formData)
  const url = res.data || res
  // 上传成功后记录文件元信息
  await DocumentFileApi.createFile({
    dirId: currentDirId.value,
    docNo: genDocNo(),
    name: file.name,
    filePath: url,
    fileSize: file.size,
    fileExt: getExt(file.name),
    fileType: file.type,
    permissionType: 1
  })
  ElMessage.success('上传成功')
  loadFileList()
}

// 自动生成 CNCBI 文档编号：CIP-yyyyMMdd-序号
let docSeq = 0
const genDocNo = (): string => {
  const now = new Date()
  const y = now.getFullYear()
  const m = String(now.getMonth() + 1).padStart(2, '0')
  const d = String(now.getDate()).padStart(2, '0')
  docSeq++
  return `CIP-${y}${m}${d}-${String(docSeq).padStart(4, '0')}`
}

const getExt = (name: string) => {
  const idx = name.lastIndexOf('.')
  return idx === -1 ? '' : name.substring(idx + 1).toLowerCase()
}

// ========== 打开文档（预览/编辑） ==========
const handleOpenDoc = (row: DocumentFileVO, mode: 'view' | 'edit' = 'view') => {
  router.push({ path: '/document/file/editor', query: { id: row.id, mode } })
}

const handleDeleteFile = async (row: DocumentFileVO) => {
  await ElMessageBox.confirm(`确认删除文件「${row.name}」？`, '提示', { type: 'warning' })
  await DocumentFileApi.deleteFile(row.id)
  ElMessage.success('删除成功')
  loadFileList()
}

onMounted(() => {
  loadFileList()
})
</script>
