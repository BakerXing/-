<template>
  <div class="onlyoffice-wrapper">
    <div id="onlyoffice-editor" ref="editorRef" class="onlyoffice-editor" />
  </div>
</template>

<script setup lang="ts">
import { ref, onMounted, onBeforeUnmount } from 'vue'
import { useRoute, useRouter } from 'vue-router'
import { ElMessage } from 'element-plus'
import { DocumentFileApi } from '@/api/document'

const route = useRoute()
const router = useRouter()
const editorRef = ref<HTMLDivElement>()

let docEditor: any = null

/**
 * 页面加载流程：
 * 1. 从后端获取 OnlyOffice 编辑器配置（含文档 URL、回调地址、模式等）；
 * 2. 动态加载 OnlyOffice JavaScript API（由 OnlyOffice 服务自身提供，内网无外网依赖）；
 * 3. 调用 DocsAPI.DocEditor 在占位符中初始化编辑器。
 */
onMounted(async () => {
  const id = Number(route.query.id)
  const mode = (route.query.mode as string) === 'edit' ? 'edit' : 'view'
  if (!id) {
    ElMessage.error('缺少文档参数')
    router.back()
    return
  }

  try {
    // 1. 获取编辑器配置
    const res: any = await DocumentFileApi.getOnlyOfficeConfig(id, mode)
    const config = res.data || res

    // 2. 加载 OnlyOffice JS API（脚本地址由后端配置的 doc-service-url 拼接）
    await loadOnlyOfficeScript(config)

    // 3. 初始化编辑器（用像素高度确保撑满视口，避免 100% 塌缩）
    docEditor = new (window as any).DocsAPI.DocEditor('onlyoffice-editor', {
      ...config,
      height: window.innerHeight - 96 + 'px',
      width: '100%',
      type: 'desktop'
    })
  } catch (e: any) {
    ElMessage.error('文档打开失败：' + (e?.message || e))
  }
})

/**
 * 动态加载 OnlyOffice 前端脚本。
 * 脚本地址规则（Document Server 默认部署）：
 *   {doc-service-url}/web-apps/apps/api/documents/api.js
 */
const loadOnlyOfficeScript = (config: any): Promise<void> => {
  return new Promise((resolve, reject) => {
    // 后端返回的配置需携带 docServiceUrl，用于拼接脚本地址
    const base = config.docServiceUrl || (window as any).__ONLYOFFICE_BASE__ || ''
    const scriptId = 'onlyoffice-api-script'
    // 若已加载，直接返回
    if (document.getElementById(scriptId)) {
      resolve()
      return
    }
    const script = document.createElement('script')
    script.id = scriptId
    script.src = `${base.replace(/\/$/, '')}/web-apps/apps/api/documents/api.js`
    script.async = true
    script.onload = () => resolve()
    script.onerror = () => reject(new Error('OnlyOffice JS API 加载失败，请检查 OnlyOffice 服务地址与网络连通性'))
    document.head.appendChild(script)
  })
}

onBeforeUnmount(() => {
  if (docEditor) {
    docEditor.destroyEditor()
    docEditor = null
  }
})
</script>

<style scoped>
.onlyoffice-wrapper {
  position: relative;
  width: 100%;
  height: calc(100vh - 96px);
  min-height: 600px;
}
.onlyoffice-editor {
  width: 100%;
  height: 100%;
}
</style>
