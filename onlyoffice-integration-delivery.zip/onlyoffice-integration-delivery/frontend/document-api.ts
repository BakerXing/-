import request from '@/config/axios'

/** 文档目录信息 */
export interface DocumentDirVO {
  id: number // 目录编号
  name: string // 目录名称
  parentId: number // 父目录编号
  sort: number // 排序序号
  remark: string // 备注
}

/** 文档文件信息 */
export interface DocumentFileVO {
  id: number // 文件编号
  docNo: string // CNCBI 文档编号
  dirId: number // 所属目录编号
  name: string // 文件名称
  fileSize: number // 文件大小
  fileExt: string // 文件扩展名
  fileType: string // 文件 MIME 类型
  permissionType: number // 权限类型
  version: number // 版本号
  auditTime: Date // 审核日期
  remark: string // 备注
  createTime: Date // 创建时间
  creator?: string // 创建人（所有者）
}

/** OnlyOffice 编辑器配置（由后端构建，前端直接透传给 DocsAPI） */
export interface OnlyOfficeConfigVO {
  documentType: string
  document: any
  editorConfig: any
  token?: string
}

// ========== 目录相关 ==========
export const DocumentDirApi = {
  // 创建目录
  createDir: async (data: DocumentDirVO) => {
    return await request.post({ url: `/document/dir/create`, data })
  },
  // 更新目录
  updateDir: async (data: DocumentDirVO) => {
    return await request.put({ url: `/document/dir/update`, data })
  },
  // 删除目录
  deleteDir: async (id: number) => {
    return await request.delete({ url: `/document/dir/delete?id=${id}` })
  },
  // 获得目录
  getDir: async (id: number) => {
    return await request.get({ url: `/document/dir/get?id=${id}` })
  },
  // 获得子目录列表
  getDirList: async (parentId?: number) => {
    return await request.get({ url: `/document/dir/list`, params: { parentId } })
  }
}

// ========== 文件相关 ==========
export const DocumentFileApi = {
  // 创建文件元信息
  createFile: async (data: DocumentFileVO) => {
    return await request.post({ url: `/document/file/create`, data })
  },
  // 更新文件元信息
  updateFile: async (data: DocumentFileVO) => {
    return await request.put({ url: `/document/file/update`, data })
  },
  // 删除文件
  deleteFile: async (id: number) => {
    return await request.delete({ url: `/document/file/delete?id=${id}` })
  },
  // 获得文件
  getFile: async (id: number) => {
    return await request.get({ url: `/document/file/get?id=${id}` })
  },
  // 获得文件分页
  getFilePage: async (params: any) => {
    return await request.get({ url: `/document/file/page`, params })
  },
  // 获取 OnlyOffice 编辑器配置
  getOnlyOfficeConfig: async (id: number, mode: 'view' | 'edit' = 'view') => {
    return await request.get({ url: `/document/file/onlyoffice-config`, params: { id, mode } })
  }
}
