package com.ruoyi.web.service.tool.impl;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.ruoyi.common.utils.SecurityUtils;
import com.ruoyi.common.utils.StringUtils;
import com.ruoyi.web.service.tool.OnlyOfficeService;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import org.apache.commons.io.FilenameUtils;
import org.apache.commons.io.IOUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import javax.crypto.Mac;
import javax.crypto.spec.SecretKeySpec;
import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.URL;
import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.text.SimpleDateFormat;
import java.util.*;

@Service
public class OnlyOfficeServiceImpl implements OnlyOfficeService {

    private static final Logger log = LoggerFactory.getLogger(OnlyOfficeServiceImpl.class);

    private static final String[] ALLOWED_EXTENSION = {
            "doc", "docx", "txt", "rtf", "odt", "pdf",
            "xls", "xlsx", "csv", "ods",
            "ppt", "pptx", "odp"
    };

    private static final String RESOURCE_PREFIX = "/profile/onlyoffice";
    private static final ObjectMapper OBJECT_MAPPER = new ObjectMapper();

    @Value("${onlyoffice.document-server-url}")
    private String documentServerUrl;

    @Value("${onlyoffice.jwt-secret:}")
    private String jwtSecret;

    @Value("${onlyoffice.file-host:}")
    private String fileHost;

    @Value("${onlyoffice.storage-path:}")
    private String storagePath;

    private File getStorageDir() {
        String path = storagePath;
        if (StringUtils.isEmpty(path)) {
            path = System.getProperty("user.home") + File.separator + "onlyoffice-files";
        }
        File dir = new File(path);
        if (!dir.exists()) {
            dir.mkdirs();
        }
        return dir;
    }

    @Override
    public List<Map<String, Object>> list() {
        List<Map<String, Object>> result = new ArrayList<>();
        File baseDir = getStorageDir();
        if (baseDir.exists()) {
            collectFiles(baseDir, baseDir, result);
        }
        return result;
    }

    private void collectFiles(File baseDir, File current, List<Map<String, Object>> result) {
        File[] files = current.listFiles();
        if (files == null) {
            return;
        }
        for (File file : files) {
            if (file.isDirectory()) {
                collectFiles(baseDir, file, result);
            } else {
                String name = file.getName();
                if (name.endsWith(".meta")) {
                    continue;
                }
                String relative = baseDir.toPath().relativize(file.toPath()).toString().replace('\\', '/');
                String fileName = RESOURCE_PREFIX + "/" + relative;
                Map<String, Object> item = new HashMap<>();
                item.put("fileName", fileName);
                item.put("name", readOriginalName(file));
                item.put("size", file.length());
                item.put("sizeText", formatSize(file.length()));
                item.put("lastModified", file.lastModified());
                item.put("extension", FilenameUtils.getExtension(name).toLowerCase());
                result.add(item);
            }
        }
    }

    private String readOriginalName(File file) {
        File metaFile = new File(file.getAbsolutePath() + ".meta");
        if (metaFile.exists()) {
            try {
                Map<?, ?> meta = OBJECT_MAPPER.readValue(metaFile, Map.class);
                Object originalName = meta.get("originalName");
                if (originalName != null && StringUtils.isNotEmpty(originalName.toString())) {
                    return originalName.toString();
                }
            } catch (Exception e) {
                log.warn("读取文件元数据失败: {}", metaFile.getAbsolutePath(), e);
            }
        }
        return file.getName();
    }

    @Override
    public Map<String, Object> upload(MultipartFile file) {
        try {
            String originalName = file.getOriginalFilename();
            if (originalName == null) {
                throw new RuntimeException("文件名不能为空");
            }
            String extension = FilenameUtils.getExtension(originalName).toLowerCase();
            if (!isAllowedExtension(extension)) {
                throw new RuntimeException("不支持的文件类型");
            }

            String dateDir = new SimpleDateFormat("yyyy/MM/dd").format(new Date());
            File targetDir = new File(getStorageDir(), dateDir);
            if (!targetDir.exists() && !targetDir.mkdirs()) {
                throw new RuntimeException("创建上传目录失败: " + targetDir.getAbsolutePath());
            }
            String fileName = UUID.randomUUID().toString().replace("-", "") + "." + extension;
            File targetFile = new File(targetDir, fileName);
            file.transferTo(targetFile);

            File metaFile = new File(targetDir, fileName + ".meta");
            try {
                Map<String, Object> meta = new HashMap<>();
                meta.put("originalName", originalName);
                OBJECT_MAPPER.writeValue(metaFile, meta);
            } catch (Exception e) {
                log.warn("保存文件元数据失败: {}", metaFile.getAbsolutePath(), e);
            }

            String relativePath = dateDir + "/" + fileName;
            String savedFileName = RESOURCE_PREFIX + "/" + relativePath;
            String encodedSavedFileName = URLEncoder.encode(savedFileName, StandardCharsets.UTF_8);
            String url = getHost(null) + "/tool/onlyoffice/download?fileName=" + encodedSavedFileName;

            Map<String, Object> data = new HashMap<>();
            data.put("url", url);
            data.put("fileName", savedFileName);
            data.put("name", originalName);
            data.put("extension", extension);
            return data;
        } catch (RuntimeException e) {
            throw e;
        } catch (Exception e) {
            log.error("OnlyOffice 文件上传失败", e);
            throw new RuntimeException(e.getMessage(), e);
        }
    }

    @Override
    public void remove(String fileName) {
        if (!fileName.startsWith(RESOURCE_PREFIX + "/")) {
            throw new RuntimeException("非法的文件路径");
        }
        String relativePath = fileName.substring(RESOURCE_PREFIX.length() + 1);
        File file = new File(getStorageDir(), relativePath);
        File metaFile = new File(file.getAbsolutePath() + ".meta");
        if (file.exists() && file.delete()) {
            if (metaFile.exists()) {
                metaFile.delete();
            }
            return;
        }
        throw new RuntimeException("文件删除失败");
    }

    @Override
    public Map<String, Object> config(String fileName, String mode, HttpServletRequest request) {
        try {
            if (!fileName.startsWith(RESOURCE_PREFIX + "/")) {
                throw new RuntimeException("非法的文件路径");
            }
            String relativePath = fileName.substring(RESOURCE_PREFIX.length() + 1);
            File file = new File(getStorageDir(), relativePath);
            if (!file.exists()) {
                throw new RuntimeException("文件不存在");
            }

            String extension = FilenameUtils.getExtension(fileName).toLowerCase();
            String documentType = resolveDocumentType(extension);
            String backendHost = getHost(request);
            String encodedFileName = URLEncoder.encode(fileName, StandardCharsets.UTF_8);
            String fileUrl = backendHost + "/tool/onlyoffice/download?fileName=" + encodedFileName;
            String callbackUrl = backendHost + "/tool/onlyoffice/callback";
            String key = Base64.getUrlEncoder().withoutPadding().encodeToString(fileName.getBytes(StandardCharsets.UTF_8)) + "_" + file.lastModified();

            Map<String, Object> permissions = new HashMap<>();
            boolean viewMode = isViewMode(mode);
            permissions.put("edit", !viewMode);
            permissions.put("download", true);
            permissions.put("print", true);
            permissions.put("review", !viewMode);

            Map<String, Object> document = new HashMap<>();
            document.put("fileType", extension);
            document.put("key", key);
            document.put("title", readOriginalName(file));
            document.put("url", fileUrl);
            document.put("permissions", permissions);

            Map<String, Object> editorConfig = new HashMap<>();
            editorConfig.put("mode", viewMode ? "view" : "edit");
            editorConfig.put("lang", "zh-CN");
            editorConfig.put("callbackUrl", callbackUrl);
            Map<String, Object> user = new HashMap<>();
            String username = SecurityUtils.getUsername();
            user.put("id", username == null ? "anonymous" : username);
            user.put("name", username == null ? "匿名用户" : username);
            editorConfig.put("user", user);
            Map<String, Object> customization = new HashMap<>();
            customization.put("forcesave", true);
            customization.put("compactHeader", true);
            editorConfig.put("customization", customization);

            // 构建 OnlyOffice 编辑器配置（仅这些字段参与 JWT 签名）
            Map<String, Object> editorConfigJson = new HashMap<>();
            editorConfigJson.put("documentType", documentType);
            editorConfigJson.put("document", document);
            editorConfigJson.put("editorConfig", editorConfig);
            editorConfigJson.put("token", createJwtToken(editorConfigJson));

            // 将 documentServerUrl 作为外层独立字段返回，不放入被签名的 config 中
            // 某些 OnlyOffice 版本会拒绝 JWT 签名范围外的额外字段
            Map<String, Object> result = new HashMap<>();
            result.put("config", editorConfigJson);
            result.put("documentServerUrl", documentServerUrl);

            return result;
        } catch (RuntimeException e) {
            throw e;
        } catch (Exception e) {
            log.error("生成 OnlyOffice 配置失败", e);
            throw new RuntimeException(e.getMessage(), e);
        }
    }

    @Override
    public void download(String fileName, HttpServletResponse response) {
        try {
            if (!fileName.startsWith(RESOURCE_PREFIX + "/")) {
                response.sendError(HttpServletResponse.SC_BAD_REQUEST, "非法的文件路径");
                return;
            }
            String relativePath = fileName.substring(RESOURCE_PREFIX.length() + 1);
            File file = new File(getStorageDir(), relativePath);
            if (!file.exists()) {
                response.sendError(HttpServletResponse.SC_NOT_FOUND, "文件不存在");
                return;
            }
            String extension = FilenameUtils.getExtension(fileName).toLowerCase();
            response.setContentType(getContentType(extension));
            String rawName = readOriginalName(file);
            // RFC 5987/6266: 同时提供 ASCII fallback + UTF-8 编码文件名，避免 Tomcat 非 ASCII header 告警
            String asciiName = "attachment";
            try {
                String utf8Encoded = URLEncoder.encode(rawName, StandardCharsets.UTF_8).replace("+", "%20");
                asciiName = rawName.replaceAll("[^\\x20-\\x7E]", "_");
                response.setHeader("Content-Disposition", "attachment; filename=\"" + asciiName + "\"; filename*=UTF-8''" + utf8Encoded);
            } catch (Exception ignore) {
                response.setHeader("Content-Disposition", "attachment; filename=\"" + file.getName() + "\"");
            }
            response.setContentLengthLong(file.length());
            try (InputStream in = Files.newInputStream(file.toPath()); OutputStream out = response.getOutputStream()) {
                IOUtils.copy(in, out);
                out.flush();
            }
        } catch (Exception e) {
            log.error("OnlyOffice 文件下载失败: {}", fileName, e);
            try {
                response.sendError(HttpServletResponse.SC_INTERNAL_SERVER_ERROR, "文件下载失败");
            } catch (IOException ignored) {
            }
        }
    }

    private String getContentType(String extension) {
        return switch (extension) {
            case "doc" -> "application/msword";
            case "docx" -> "application/vnd.openxmlformats-officedocument.wordprocessingml.document";
            case "xls" -> "application/vnd.ms-excel";
            case "xlsx" -> "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet";
            case "ppt" -> "application/vnd.ms-powerpoint";
            case "pptx" -> "application/vnd.openxmlformats-officedocument.presentationml.presentation";
            case "pdf" -> "application/pdf";
            case "txt" -> "text/plain";
            case "csv" -> "text/csv";
            default -> "application/octet-stream";
        };
    }

    @Override
    public Map<String, Object> callback(Map<String, Object> body) {
        try {
            Integer status = body.get("status") == null ? null : ((Number) body.get("status")).intValue();
            String key = body.get("key") == null ? null : body.get("key").toString();
            String downloadUrl = body.get("url") == null ? null : body.get("url").toString();

            if (status != null && (status == 2 || status == 6) && StringUtils.isNotEmpty(downloadUrl)) {
                String fileName = restoreFileNameFromKey(key);
                if (fileName != null) {
                    saveFileFromUrl(downloadUrl, fileName);
                }
            }
            Map<String, Object> result = new HashMap<>();
            result.put("error", 0);
            return result;
        } catch (Exception e) {
            log.error("OnlyOffice 回调处理失败", e);
            Map<String, Object> result = new HashMap<>();
            result.put("error", 1);
            return result;
        }
    }

    private String restoreFileNameFromKey(String key) {
        if (StringUtils.isEmpty(key)) {
            return null;
        }
        int lastUnderline = key.lastIndexOf('_');
        if (lastUnderline <= 0) {
            return null;
        }
        String encoded = key.substring(0, lastUnderline);
        try {
            return new String(Base64.getUrlDecoder().decode(encoded), StandardCharsets.UTF_8);
        } catch (Exception e) {
            log.warn("解码文档 key 失败: {}", key, e);
            return null;
        }
    }

    private void saveFileFromUrl(String downloadUrl, String fileName) throws IOException {
        String relativePath = fileName.substring(RESOURCE_PREFIX.length() + 1);
        Path target = Paths.get(getStorageDir().getAbsolutePath(), relativePath);
        Files.createDirectories(target.getParent());

        // 先写入 .tmp 文件，再原子替换目标文件，避免：
        // 1) 目标文件已存在只读属性导致 AccessDeniedException
        // 2) OnlyOffice 端可能还持有句柄
        Path tmpFile = target.resolveSibling(target.getFileName() + ".tmp." + System.currentTimeMillis());
        try (InputStream in = new URL(downloadUrl).openStream()) {
            Files.copy(in, tmpFile, java.nio.file.StandardCopyOption.REPLACE_EXISTING);
        }
        try {
            // 尝试解除只读属性后再替换
            if (Files.exists(target)) {
                File tf = target.toFile();
                if (!tf.canWrite()) tf.setWritable(true);
            }
            Files.move(tmpFile, target,
                    java.nio.file.StandardCopyOption.REPLACE_EXISTING,
                    java.nio.file.StandardCopyOption.ATOMIC_MOVE);
        } catch (IOException atomicFail) {
            // ATOMIC_MOVE 在 Windows 跨卷/特殊路径可能失败，退回普通替换
            Files.move(tmpFile, target, java.nio.file.StandardCopyOption.REPLACE_EXISTING);
        }
        log.info("OnlyOffice 文档已保存: {} ({} bytes)", target, Files.size(target));
    }

    private boolean isViewMode(String mode) {
        return "view".equals(mode) || "preview".equals(mode);
    }

    private String resolveDocumentType(String extension) {
        switch (extension) {
            case "doc":
            case "docx":
            case "txt":
            case "rtf":
            case "odt":
            case "pdf":
                return "word";
            case "xls":
            case "xlsx":
            case "csv":
            case "ods":
                return "cell";
            case "ppt":
            case "pptx":
            case "odp":
                return "slide";
            default:
                return "word";
        }
    }

    private String getHost(HttpServletRequest request) {
        if (StringUtils.isNotEmpty(fileHost)) {
            return fileHost.replaceAll("/$", "");
        }
        if (request != null) {
            return request.getScheme() + "://" + request.getServerName() + ":" + request.getServerPort();
        }
        return "http://localhost:8080";
    }

    private boolean isAllowedExtension(String extension) {
        for (String ext : ALLOWED_EXTENSION) {
            if (ext.equalsIgnoreCase(extension)) {
                return true;
            }
        }
        return false;
    }

    private String createJwtToken(Map<String, Object> payload) {
        String secret = jwtSecret;
        if (StringUtils.isEmpty(secret)) {
            log.warn("OnlyOffice jwt-secret 未配置，跳过 JWT 签名");
            return null;
        }
        try {
            String header = "{\"alg\":\"HS256\",\"typ\":\"JWT\"}";
            String headerBase64 = base64UrlEncode(header.getBytes(StandardCharsets.UTF_8));
            // 使用 Jackson 序列化，避免手写 toJson 的各种边界问题
            String payloadJson = OBJECT_MAPPER.writeValueAsString(payload);
            String payloadBase64 = base64UrlEncode(payloadJson.getBytes(StandardCharsets.UTF_8));
            String signingInput = headerBase64 + "." + payloadBase64;
            String signature = base64UrlEncode(hmacSha256(signingInput, secret));
            String token = signingInput + "." + signature;
            log.debug("OnlyOffice JWT payload JSON: {}", payloadJson);
            log.debug("OnlyOffice JWT token: {}", token);
            return token;
        } catch (Exception e) {
            log.error("生成 OnlyOffice JWT 失败", e);
            return null;
        }
    }

    private byte[] hmacSha256(String data, String secret) throws Exception {
        Mac mac = Mac.getInstance("HmacSHA256");
        mac.init(new SecretKeySpec(secret.getBytes(StandardCharsets.UTF_8), "HmacSHA256"));
        return mac.doFinal(data.getBytes(StandardCharsets.UTF_8));
    }

    private String base64UrlEncode(byte[] bytes) {
        return Base64.getUrlEncoder().withoutPadding().encodeToString(bytes);
    }

    private String formatSize(long size) {
        if (size < 1024) {
            return size + " B";
        }
        if (size < 1024 * 1024) {
            return String.format("%.1f KB", size / 1024.0);
        }
        return String.format("%.1f MB", size / (1024.0 * 1024));
    }
}
