package com.ruoyi.system.mapper;

import java.util.List;
import com.ruoyi.system.domain.AiMessage;

public interface AiMessageMapper
{
    public AiMessage selectMessageById(Long messageId);

    public List<AiMessage> selectMessageList(AiMessage message);

    public List<AiMessage> selectMessagesByConversationId(Long conversationId);

    public int insertMessage(AiMessage message);

    public int updateMessage(AiMessage message);

    public int deleteMessageById(Long messageId);

    public int deleteMessageByIds(Long[] messageIds);

    public int deleteMessagesByConversationId(Long conversationId);
}
