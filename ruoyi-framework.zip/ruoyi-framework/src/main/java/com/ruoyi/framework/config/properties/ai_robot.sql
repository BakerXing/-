-- ----------------------------
-- AI智能问答机器人表
-- ----------------------------

-- 会话表
DROP TABLE IF EXISTS `ai_conversation`;
CREATE TABLE `ai_conversation` (
  `conversation_id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '会话ID',
  `title` varchar(200) DEFAULT '' COMMENT '会话标题',
  `conversation_type` char(1) DEFAULT '1' COMMENT '会话类型（1智聊 2翻译 3会议纪要 4辅助写作）',
  `user_id` bigint(20) DEFAULT NULL COMMENT '用户ID',
  `is_pinned` char(1) DEFAULT '0' COMMENT '是否钉住（0否 1是）',
  `pinned_time` datetime DEFAULT NULL COMMENT '钉住时间',
  `last_message` varchar(500) DEFAULT '' COMMENT '最后一条消息',
  `last_message_time` datetime DEFAULT NULL COMMENT '最后消息时间',
  `status` char(1) DEFAULT '0' COMMENT '状态（0正常 1删除）',
  `create_by` varchar(64) DEFAULT '' COMMENT '创建者',
  `create_time` datetime DEFAULT NULL COMMENT '创建时间',
  `update_by` varchar(64) DEFAULT '' COMMENT '更新者',
  `update_time` datetime DEFAULT NULL COMMENT '更新时间',
  `remark` varchar(500) DEFAULT NULL COMMENT '备注',
  PRIMARY KEY (`conversation_id`),
  KEY `idx_user_id` (`user_id`),
  KEY `idx_update_time` (`update_time`)
) ENGINE=InnoDB AUTO_INCREMENT=1 DEFAULT CHARSET=utf8mb4 COMMENT='AI会话表';

-- 消息表
DROP TABLE IF EXISTS `ai_message`;
CREATE TABLE `ai_message` (
  `message_id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '消息ID',
  `conversation_id` bigint(20) NOT NULL COMMENT '会话ID',
  `role` varchar(20) NOT NULL COMMENT '角色（user用户 assistant助手）',
  `content` text COMMENT '消息内容',
  `message_type` char(1) DEFAULT '1' COMMENT '消息类型（1文本）',
  `status` char(1) DEFAULT '0' COMMENT '状态（0正常 1删除）',
  `create_by` varchar(64) DEFAULT '' COMMENT '创建者',
  `create_time` datetime DEFAULT NULL COMMENT '创建时间',
  `update_by` varchar(64) DEFAULT '' COMMENT '更新者',
  `update_time` datetime DEFAULT NULL COMMENT '更新时间',
  `remark` varchar(500) DEFAULT NULL COMMENT '备注',
  PRIMARY KEY (`message_id`),
  KEY `idx_conversation_id` (`conversation_id`)
) ENGINE=InnoDB AUTO_INCREMENT=1 DEFAULT CHARSET=utf8mb4 COMMENT='AI消息表';
