package com.ruoyi.system.service.impl;

import java.util.Date;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.ruoyi.system.domain.AiMessage;
import com.ruoyi.system.mapper.AiMessageMapper;
import com.ruoyi.system.service.IAiMessageService;

@Service
public class AiMessageServiceImpl implements IAiMessageService
{
    @Autowired
    private AiMessageMapper messageMapper;

    @Override
    public AiMessage selectMessageById(Long messageId)
    {
        return messageMapper.selectMessageById(messageId);
    }

    @Override
    public List<AiMessage> selectMessageList(AiMessage message)
    {
        return messageMapper.selectMessageList(message);
    }

    @Override
    public List<AiMessage> selectMessagesByConversationId(Long conversationId)
    {
        return messageMapper.selectMessagesByConversationId(conversationId);
    }

    @Override
    public Long insertMessage(AiMessage message)
    {
        message.setCreateTime(new Date());
        message.setUpdateTime(new Date());
        message.setStatus("0");
        message.setMessageType("1");
        messageMapper.insertMessage(message);
        return message.getMessageId();
    }

    @Override
    public int updateMessage(AiMessage message)
    {
        message.setUpdateTime(new Date());
        return messageMapper.updateMessage(message);
    }

    @Override
    public int deleteMessageById(Long messageId)
    {
        return messageMapper.deleteMessageById(messageId);
    }

    @Override
    public int deleteMessageByIds(Long[] messageIds)
    {
        return messageMapper.deleteMessageByIds(messageIds);
    }

    @Override
    public int deleteMessagesByConversationId(Long conversationId)
    {
        return messageMapper.deleteMessagesByConversationId(conversationId);
    }
}
