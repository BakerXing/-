package com.ruoyi.system.domain;

import java.util.Date;
import com.fasterxml.jackson.annotation.JsonFormat;
import org.apache.commons.lang3.builder.ToStringBuilder;
import org.apache.commons.lang3.builder.ToStringStyle;
import com.ruoyi.common.core.domain.BaseEntity;

public class AiConversation extends BaseEntity
{
    private static final long serialVersionUID = 1L;

    private Long conversationId;

    private String title;

    private String conversationType;

    private Long userId;

    private String isPinned;

    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    private Date pinnedTime;

    private String lastMessage;

    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    private Date lastMessageTime;

    private String status;

    public void setConversationId(Long conversationId)
    {
        this.conversationId = conversationId;
    }

    public Long getConversationId()
    {
        return conversationId;
    }

    public void setTitle(String title)
    {
        this.title = title;
    }

    public String getTitle()
    {
        return title;
    }

    public void setConversationType(String conversationType)
    {
        this.conversationType = conversationType;
    }

    public String getConversationType()
    {
        return conversationType;
    }

    public void setUserId(Long userId)
    {
        this.userId = userId;
    }

    public Long getUserId()
    {
        return userId;
    }

    public void setIsPinned(String isPinned)
    {
        this.isPinned = isPinned;
    }

    public String getIsPinned()
    {
        return isPinned;
    }

    public void setPinnedTime(Date pinnedTime)
    {
        this.pinnedTime = pinnedTime;
    }

    public Date getPinnedTime()
    {
        return pinnedTime;
    }

    public void setLastMessage(String lastMessage)
    {
        this.lastMessage = lastMessage;
    }

    public String getLastMessage()
    {
        return lastMessage;
    }

    public void setLastMessageTime(Date lastMessageTime)
    {
        this.lastMessageTime = lastMessageTime;
    }

    public Date getLastMessageTime()
    {
        return lastMessageTime;
    }

    public void setStatus(String status)
    {
        this.status = status;
    }

    public String getStatus()
    {
        return status;
    }

    @Override
    public String toString() {
        return new ToStringBuilder(this,ToStringStyle.MULTI_LINE_STYLE)
            .append("conversationId", getConversationId())
            .append("title", getTitle())
            .append("conversationType", getConversationType())
            .append("userId", getUserId())
            .append("isPinned", getIsPinned())
            .append("pinnedTime", getPinnedTime())
            .append("lastMessage", getLastMessage())
            .append("lastMessageTime", getLastMessageTime())
            .append("status", getStatus())
            .append("createBy", getCreateBy())
            .append("createTime", getCreateTime())
            .append("updateBy", getUpdateBy())
            .append("updateTime", getUpdateTime())
            .append("remark", getRemark())
            .toString();
    }
}
