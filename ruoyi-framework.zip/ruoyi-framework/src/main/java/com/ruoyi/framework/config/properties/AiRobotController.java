package com.ruoyi.web.controller.ai;

import java.util.List;
import jakarta.servlet.http.HttpServletResponse;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.mvc.method.annotation.SseEmitter;
import com.ruoyi.common.core.controller.BaseController;
import com.ruoyi.common.core.domain.AjaxResult;
import com.ruoyi.common.core.page.TableDataInfo;
import com.ruoyi.framework.web.service.IAiChatService;
import com.ruoyi.system.domain.AiConversation;
import com.ruoyi.system.domain.AiMessage;
import com.ruoyi.system.service.IAiConversationService;
import com.ruoyi.system.service.IAiMessageService;

@RestController
@RequestMapping("/ai/robot")
public class AiRobotController extends BaseController
{
    private static final Long DEFAULT_USER_ID = 1L;
    private static final String DEFAULT_USERNAME = "admin";

    private Long safeGetUserId()
    {
        try
        {
            return getUserId();
        }
        catch (Exception e)
        {
            return DEFAULT_USER_ID;
        }
    }

    private String safeGetUsername()
    {
        try
        {
            return getUsername();
        }
        catch (Exception e)
        {
            return DEFAULT_USERNAME;
        }
    }

    @Autowired
    private IAiConversationService conversationService;

    @Autowired
    private IAiMessageService messageService;

    @Autowired
    private IAiChatService aiChatService;

    @GetMapping("/conversation/list")
    public TableDataInfo conversationList(AiConversation conversation)
    {
        startPage();
        conversation.setUserId(safeGetUserId());
        List<AiConversation> list = conversationService.selectConversationList(conversation);
        return getDataTable(list);
    }

    @GetMapping("/conversation/myList")
    public AjaxResult myConversationList()
    {
        List<AiConversation> list = conversationService.selectConversationListByUserId(safeGetUserId());
        return success(list);
    }

    @GetMapping("/conversation/{conversationId}")
    public AjaxResult getConversationInfo(@PathVariable Long conversationId)
    {
        return success(conversationService.selectConversationById(conversationId));
    }

    @PostMapping("/conversation")
    public AjaxResult addConversation(@Validated @RequestBody AiConversation conversation)
    {
        conversation.setUserId(safeGetUserId());
        conversation.setCreateBy(safeGetUsername());
        Long id = conversationService.insertConversation(conversation);
        return success(id);
    }

    @PutMapping("/conversation")
    public AjaxResult editConversation(@Validated @RequestBody AiConversation conversation)
    {
        conversation.setUpdateBy(safeGetUsername());
        return toAjax(conversationService.updateConversation(conversation));
    }

    @PostMapping("/conversation/togglePinned/{conversationId}")
    public AjaxResult togglePinned(@PathVariable Long conversationId)
    {
        int result = conversationService.togglePinned(conversationId, safeGetUserId());
        if (result == -1)
        {
            return error("钉住的会话已达上限（最多15个）");
        }
        return toAjax(result);
    }

    @DeleteMapping("/conversation/{conversationIds}")
    public AjaxResult removeConversation(@PathVariable Long[] conversationIds)
    {
        return toAjax(conversationService.deleteConversationByIds(conversationIds));
    }

    @GetMapping("/message/list/{conversationId}")
    public AjaxResult messageList(@PathVariable Long conversationId)
    {
        List<AiMessage> list = messageService.selectMessagesByConversationId(conversationId);
        return success(list);
    }

    @PostMapping("/message")
    public AjaxResult addMessage(@Validated @RequestBody AiMessage message)
    {
        message.setCreateBy(safeGetUsername());
        Long id = messageService.insertMessage(message);
        if ("user".equals(message.getRole()))
        {
            conversationService.updateLastMessage(message.getConversationId(),
                message.getContent().length() > 50 ? message.getContent().substring(0, 50) : message.getContent());
        }
        return success(id);
    }

    @DeleteMapping("/message/{messageIds}")
    public AjaxResult removeMessage(@PathVariable Long[] messageIds)
    {
        return toAjax(messageService.deleteMessageByIds(messageIds));
    }

    @PostMapping(value = "/chat/stream", produces = MediaType.TEXT_EVENT_STREAM_VALUE)
    public SseEmitter chatStream(@RequestBody AiMessage message)
    {
        message.setCreateBy(safeGetUsername());
        Long userMsgId = messageService.insertMessage(message);
        conversationService.updateLastMessage(message.getConversationId(),
            message.getContent().length() > 50 ? message.getContent().substring(0, 50) : message.getContent());

        AiMessage aiMsg = new AiMessage();
        aiMsg.setConversationId(message.getConversationId());
        aiMsg.setRole("assistant");
        aiMsg.setCreateBy(safeGetUsername());
        Long aiMsgId = messageService.insertMessage(aiMsg);

        List<AiMessage> historyMessages = messageService.selectMessagesByConversationId(message.getConversationId());
        historyMessages.removeIf(m -> m.getMessageId().equals(aiMsgId));

        return aiChatService.chatStream(message, historyMessages, aiMsgId);
    }
}
