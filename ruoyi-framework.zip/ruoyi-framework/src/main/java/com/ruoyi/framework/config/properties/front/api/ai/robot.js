import request from '@/utils/request'

export function listConversation(query) {
  return request({
    url: '/ai/robot/conversation/list',
    method: 'get',
    params: query
  })
}

export function myConversationList() {
  return request({
    url: '/ai/robot/conversation/myList',
    method: 'get'
  })
}

export function getConversation(conversationId) {
  return request({
    url: '/ai/robot/conversation/' + conversationId,
    method: 'get'
  })
}

export function addConversation(data) {
  return request({
    url: '/ai/robot/conversation',
    method: 'post',
    data: data
  })
}

export function updateConversation(data) {
  return request({
    url: '/ai/robot/conversation',
    method: 'put',
    data: data
  })
}

export function togglePinned(conversationId) {
  return request({
    url: '/ai/robot/conversation/togglePinned/' + conversationId,
    method: 'post'
  })
}

export function delConversation(conversationIds) {
  return request({
    url: '/ai/robot/conversation/' + conversationIds,
    method: 'delete'
  })
}

export function listMessage(conversationId) {
  return request({
    url: '/ai/robot/message/list/' + conversationId,
    method: 'get'
  })
}

export function addMessage(data) {
  return request({
    url: '/ai/robot/message',
    method: 'post',
    data: data
  })
}

export function delMessage(messageIds) {
  return request({
    url: '/ai/robot/message/' + messageIds,
    method: 'delete'
  })
}
