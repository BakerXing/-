<template>
  <div class="ai-robot-page">
    <div :class="['ai-sidebar', sidebarCollapsed ? 'collapsed' : '']">
      <div class="ai-sidebar-header">
        <div class="ai-sidebar-title">
          <span class="ai-sidebar-logo">🤖</span>
          <h3 v-if="!sidebarCollapsed">AI 智能助手</h3>
        </div>
        <button v-if="!sidebarCollapsed" class="ai-new-btn" @click="createNewConversation">
          <svg viewBox="0 0 24 24" width="16" height="16" fill="currentColor">
            <path d="M19 13h-6v6h-2v-6H5v-2h6V5h2v6h6v2z"/>
          </svg>
          新建对话
        </button>
        <button v-if="sidebarCollapsed" class="ai-new-btn ai-new-btn-icon" @click="createNewConversation" title="新建对话">
          <svg viewBox="0 0 24 24" width="18" height="18" fill="currentColor">
            <path d="M19 13h-6v6h-2v-6H5v-2h6V5h2v6h6v2z"/>
          </svg>
        </button>
      </div>
      <div v-if="!sidebarCollapsed" class="ai-search-box">
        <svg viewBox="0 0 24 24" width="18" height="18" fill="#94a3b8">
          <path d="M15.5 14h-.79l-.28-.27C15.41 12.59 16 11.11 16 9.5 16 5.91 13.09 3 9.5 3S3 5.91 3 9.5 5.91 16 9.5 16c1.61 0 3.09-.59 4.23-1.57l.27.28v.79l5 4.99L20.49 19l-4.99-5zm-6 0C7.01 14 5 11.99 5 9.5S7.01 5 9.5 5 14 7.01 14 9.5 11.99 14 9.5 14z"/>
        </svg>
        <input v-model="searchKeyword" type="text" placeholder="搜索会话..." @input="handleSearch" />
      </div>
      <div class="ai-conversation-list">
        <div
          v-for="conv in conversationList"
          :key="conv.conversationId"
          :class="['ai-conv-item', activeConversationId === conv.conversationId ? 'active' : '']"
          :title="conv.title || '新对话'"
          @click="selectConversation(conv)"
        >
          <div class="ai-conv-icon-wrap">
            <svg v-if="conv.isPinned === '1'" class="ai-pin-left-icon" viewBox="0 0 24 24" width="14" height="14" fill="#f59e0b">
              <path d="M16 9V4h1c.55 0 1-.45 1-1s-.45-1-1-1H7c-.55 0-1 .45-1 1s.45 1 1 1h1v5c0 1.66-1.34 3-3 3v2h5.97v7l1 1 1-1v-7H19v-2c-1.66 0-3-1.34-3-3z"/>
            </svg>
            <span v-else class="ai-pin-placeholder"></span>
            <span class="ai-conv-icon">{{ getTypeIcon(conv.conversationType) }}</span>
          </div>
          <div v-if="!sidebarCollapsed" class="ai-conv-info">
            <div class="ai-conv-title">{{ conv.title || '新对话' }}</div>
            <div class="ai-conv-preview">{{ conv.lastMessage || '暂无消息' }}</div>
          </div>
          <div v-if="!sidebarCollapsed" class="ai-conv-actions">
            <button
              :class="['ai-pin-btn', conv.isPinned === '1' ? 'pinned' : '']"
              :title="conv.isPinned === '1' ? '取消钉住' : '钉住'"
              @click.stop="togglePin(conv)"
            >
              <svg v-if="conv.isPinned !== '1'" viewBox="0 0 24 24" width="16" height="16" fill="currentColor">
                <path d="M16 9V4h1c.55 0 1-.45 1-1s-.45-1-1-1H7c-.55 0-1 .45-1 1s.45 1 1 1h1v5c0 1.66-1.34 3-3 3v2h5.97v7l1 1 1-1v-7H19v-2c-1.66 0-3-1.34-3-3z"/>
              </svg>
              <template v-else>
                <svg viewBox="0 0 24 24" width="16" height="16" fill="#f59e0b">
                  <path d="M16 9V4h1c.55 0 1-.45 1-1s-.45-1-1-1H7c-.55 0-1 .45-1 1s.45 1 1 1h1v5c0 1.66-1.34 3-3 3v2h5.97v7l1 1 1-1v-7H19v-2c-1.66 0-3-1.34-3-3z"/>
                </svg>
                <span class="ai-pin-text">取消钉住</span>
              </template>
            </button>
            <button class="ai-del-btn" title="删除" @click.stop="deleteConversation(conv)">
              <svg viewBox="0 0 24 24" width="16" height="16" fill="currentColor">
                <path d="M6 19c0 1.1.9 2 2 2h8c1.1 0 2-.9 2-2V7H6v12zM19 4h-3.5l-1-1h-5l-1 1H5v2h14V4z"/>
              </svg>
            </button>
          </div>
        </div>
        <div v-if="conversationList.length === 0 && !sidebarCollapsed" class="ai-empty-conv">
          暂无会话，开始新对话吧
        </div>
      </div>
      <div class="ai-sidebar-footer">
        <button class="ai-collapse-btn" @click="toggleSidebar" :title="sidebarCollapsed ? '展开侧边栏' : '折叠侧边栏'">
          <svg v-if="!sidebarCollapsed" viewBox="0 0 24 24" width="18" height="18" fill="currentColor">
            <path d="M15.41 7.41L14 6l-6 6 6 6 1.41-1.41L10.83 12z"/>
          </svg>
          <svg v-else viewBox="0 0 24 24" width="18" height="18" fill="currentColor">
            <path d="M10 6L8.59 7.41 13.17 12l-4.58 4.59L10 18l6-6z"/>
          </svg>
        </button>
      </div>
    </div>

    <div class="ai-main">
      <div class="ai-main-header">
        <div class="ai-main-tabs">
          <div class="ai-tab-row">
            <div
              :class="['ai-tab', 'ai-tab-large', activeTab === '1' ? 'active' : '']"
              @click="switchTab('1')"
            >
              <span class="ai-tab-icon">💬</span>
              <span class="ai-tab-text">智聊</span>
            </div>
          </div>
          <div class="ai-tab-divider"></div>
          <div class="ai-tab-row ai-tab-row-small">
            <div
              :class="['ai-tab', 'ai-tab-small', activeTab === '2' ? 'active' : '']"
              @click="switchTab('2')"
            >
              <span>🌐</span>
              <span class="ai-tab-text">翻译</span>
            </div>
            <div
              :class="['ai-tab', 'ai-tab-small', activeTab === '3' ? 'active' : '']"
              @click="switchTab('3')"
            >
              <span>📝</span>
              <span class="ai-tab-text">会议纪要</span>
            </div>
            <div
              :class="['ai-tab', 'ai-tab-small', activeTab === '4' ? 'active' : '']"
              @click="switchTab('4')"
            >
              <span>✍️</span>
              <span class="ai-tab-text">辅助写作</span>
            </div>
          </div>
        </div>
      </div>

      <div class="ai-messages" ref="messagesContainer">
        <div v-if="messages.length === 0" class="ai-empty-state">
          <div class="ai-empty-icon">{{ getTypeIcon(activeTab) }}</div>
          <div class="ai-empty-title">{{ tabName }}助手</div>
          <div class="ai-empty-text">你好，有什么可以帮您？</div>
          <div class="ai-suggestions">
            <div
              v-for="(item, idx) in currentSuggestions"
              :key="idx"
              class="ai-suggestion-item"
              @click="applySuggestion(item)"
            >
              <span class="ai-suggestion-icon">{{ item.icon }}</span>
              <span class="ai-suggestion-text">{{ item.text }}</span>
            </div>
          </div>
        </div>
        <div v-for="msg in messages" :key="msg.messageId || msg.tempId" :class="['ai-msg', msg.role]">
          <div class="ai-msg-avatar">{{ msg.role === 'user' ? '我' : 'AI' }}</div>
          <div class="ai-msg-content">
            <div v-if="msg.role === 'user'" class="ai-msg-bubble">{{ msg.content }}</div>
            <div v-else class="ai-msg-bubble ai-msg-assistant">{{ msg.content || '正在思考...' }}</div>
          </div>
        </div>
      </div>

      <div class="ai-input-area">
        <div class="ai-input-toolbar">
          <button class="ai-upload-btn" @click="triggerUpload">
            <svg viewBox="0 0 24 24" width="16" height="16" fill="currentColor">
              <path d="M19.35 10.04C18.67 6.59 15.64 4 12 4 9.11 4 6.6 5.64 5.35 8.04 2.34 8.36 0 10.91 0 14c0 3.31 2.69 6 6 6h13c2.76 0 5-2.24 5-5 0-2.64-2.05-4.78-4.65-4.96zM14 13v4h-4v-4H7l5-5 5 5h-3z"/>
            </svg>
            上传文件
          </button>
          <input ref="fileInput" type="file" style="display: none" @change="handleFileUpload" multiple />
        </div>
        <textarea
          ref="inputArea"
          v-model="inputText"
          :placeholder="'请输入内容，与' + tabName + '对话...'"
          @keydown="handleKeydown"
          :disabled="isStreaming"
          rows="3"
        ></textarea>
        <div class="ai-input-actions">
          <span class="ai-input-hint">Enter 发送，Shift + Enter 换行</span>
          <button :disabled="!inputText.trim() || isStreaming" @click="sendMessage" class="ai-send-btn">
            <svg viewBox="0 0 24 24" width="18" height="18" fill="currentColor">
              <path d="M2.01 21L23 12 2.01 3 2 10l15 2-15 2z"/>
            </svg>
            发送
          </button>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
import { getToken } from '@/utils/auth'
import {
  myConversationList, addConversation, addMessage, delConversation,
  togglePinned, listMessage
} from '@/api/ai/robot'

export default {
  name: 'AiRobotPage',
  data() {
    return {
      activeTab: '1',
      activeConversationId: null,
      sidebarCollapsed: false,
      conversationList: [],
      allConversations: [],
      messages: [],
      inputText: '',
      searchKeyword: '',
      isStreaming: false,
      tabMap: {
        '1': { name: '智聊', icon: '💬' },
        '2': { name: '翻译', icon: '🌐' },
        '3': { name: '会议纪要', icon: '📝' },
        '4': { name: '辅助写作', icon: '✍️' }
      },
      suggestionsMap: {
        '1': [
          { icon: '💡', text: '帮我解释一下什么是微服务架构' },
          { icon: '📚', text: '推荐几本学习Java的好书' },
          { icon: '🎯', text: '如何提高代码质量和可维护性' }
        ],
        '2': [
          { icon: '📄', text: '翻译以下内容为英文：欢迎使用我们的产品' },
          { icon: '🇯🇵', text: '翻译以下内容为日文：今天天气真好' },
          { icon: '🇨🇳', text: '翻译成中文：Artificial intelligence is changing the world' }
        ],
        '3': [
          { icon: '📋', text: '帮我整理产品需求评审的会议纪要' },
          { icon: '👥', text: '生成一份项目周会纪要模板' },
          { icon: '🎯', text: '帮我把这段讨论整理成会议要点和待办' }
        ],
        '4': [
          { icon: '📧', text: '帮我写一封正式的商务邮件' },
          { icon: '📝', text: '写一篇关于人工智能的科普文章' },
          { icon: '📢', text: '帮我写一份产品发布会演讲稿' }
        ]
      }
    }
  },
  computed: {
    tabName() {
      return this.tabMap[this.activeTab]?.name || '智聊'
    },
    currentSuggestions() {
      return this.suggestionsMap[this.activeTab] || []
    }
  },
  mounted() {
    this.loadConversations()
  },
  methods: {
    toggleSidebar() {
      this.sidebarCollapsed = !this.sidebarCollapsed
    },
    getTypeIcon(type) {
      return this.tabMap[type]?.icon || '💬'
    },
    applySuggestion(item) {
      this.inputText = item.text
      this.$nextTick(() => {
        this.$refs.inputArea.focus()
      })
    },
    handleKeydown(e) {
      if (e.key === 'Enter' && !e.shiftKey) {
        e.preventDefault()
        this.sendMessage()
      }
    },
    triggerUpload() {
      this.$refs.fileInput.click()
    },
    handleFileUpload(e) {
      const files = e.target.files
      if (files && files.length > 0) {
        const names = Array.from(files).map(f => f.name).join(', ')
        this.$message.success('已选择文件：' + names)
      }
      e.target.value = ''
    },
    async loadConversations() {
      try {
        const res = await myConversationList()
        this.allConversations = res.data || []
        this.conversationList = [...this.allConversations]
      } catch (e) {
        console.error(e)
      }
    },
    handleSearch() {
      const kw = this.searchKeyword.trim().toLowerCase()
      if (!kw) {
        this.conversationList = [...this.allConversations]
        return
      }
      this.conversationList = this.allConversations.filter(c =>
        (c.title && c.title.toLowerCase().includes(kw)) ||
        (c.lastMessage && c.lastMessage.toLowerCase().includes(kw))
      )
    },
    createNewConversation() {
      this.activeConversationId = null
      this.messages = []
      this.inputText = ''
    },
    async selectConversation(conv) {
      this.activeConversationId = conv.conversationId
      this.activeTab = conv.conversationType || '1'
      try {
        const res = await listMessage(conv.conversationId)
        const list = res.data || []
        this.messages = this.deduplicateMessages(list)
      } catch (e) {
        this.messages = []
      }
      this.$nextTick(() => this.scrollToBottom())
    },
    deduplicateMessages(list) {
      const seen = new Set()
      const result = []
      for (const msg of list) {
        const key = msg.messageId || msg.tempId || (msg.role + '_' + msg.content + '_' + msg.createTime)
        if (!seen.has(key)) {
          seen.add(key)
          result.push(msg)
        }
      }
      return result
    },
    switchTab(tab) {
      this.activeTab = tab
      this.activeConversationId = null
      this.messages = []
      this.inputText = ''
    },
    async togglePin(conv) {
      try {
        const res = await togglePinned(conv.conversationId)
        if (res.code === 500) {
          this.$message.warning(res.msg)
          return
        }
        conv.isPinned = conv.isPinned === '1' ? '0' : '1'
        this.sortConversations()
      } catch (e) {
        this.$message.error(e.msg || '操作失败')
      }
    },
    sortConversations() {
      this.allConversations.sort((a, b) => {
        const aTime = a.lastMessageTime || a.updateTime || a.createTime
        const bTime = b.lastMessageTime || b.updateTime || b.createTime
        return new Date(bTime) - new Date(aTime)
      })
      this.handleSearch()
    },
    async deleteConversation(conv) {
      this.$confirm('确定要删除这个会话吗？', '提示', {
        confirmButtonText: '确定',
        cancelButtonText: '取消',
        type: 'warning'
      }).then(async () => {
        try {
          await delConversation([conv.conversationId])
          this.allConversations = this.allConversations.filter(c => c.conversationId !== conv.conversationId)
          this.handleSearch()
          if (this.activeConversationId === conv.conversationId) {
            this.activeConversationId = null
            this.messages = []
          }
          this.$message.success('删除成功')
        } catch (e) {
          this.$message.error('删除失败')
        }
      }).catch(() => {})
    },
    async sendMessage() {
      const text = this.inputText.trim()
      if (!text || this.isStreaming) return
      this.isStreaming = true
      const userMsg = {
        tempId: Date.now(),
        role: 'user',
        content: text
      }
      this.messages.push(userMsg)
      this.inputText = ''
      this.$nextTick(() => this.scrollToBottom())

      try {
        if (!this.activeConversationId) {
          const convRes = await addConversation({
            title: text.length > 20 ? text.substring(0, 20) : text,
            conversationType: this.activeTab
          })
          this.activeConversationId = convRes.data
          await this.loadConversations()
        }

        await addMessage({
          conversationId: this.activeConversationId,
          role: 'user',
          content: text
        })

        const aiTempId = Date.now() + 1
        this.messages.push({
          tempId: aiTempId,
          role: 'assistant',
          content: ''
        })

        this.streamChat(text, aiTempId)
      } catch (e) {
        this.isStreaming = false
        this.$message.error('发送失败：' + (e.msg || e.message))
      }
    },
    streamChat(userText, aiTempId) {
      const token = getToken()
      const url = process.env.VUE_APP_BASE_API + '/ai/robot/chat/stream'

      const xhr = new XMLHttpRequest()
      xhr.open('POST', url, true)
      xhr.setRequestHeader('Content-Type', 'application/json')
      if (token) {
        xhr.setRequestHeader('Authorization', 'Bearer ' + token)
      }

      let received = ''
      xhr.onprogress = () => {
        const newData = xhr.responseText.substring(received.length)
        received = xhr.responseText
        const lines = newData.split('\n')
        for (const line of lines) {
          if (line.startsWith('data:')) {
            const data = line.substring(5).trim()
            if (data === '[DONE]') {
              this.isStreaming = false
              this.loadConversations()
              return
            }
            if (data) {
              const msg = this.messages.find(m => m.tempId === aiTempId)
              if (msg) {
                msg.content += data
                this.$nextTick(() => this.scrollToBottom())
              }
            }
          }
        }
      }

      xhr.onload = () => {
        this.isStreaming = false
        this.loadConversations()
      }

      xhr.onerror = () => {
        this.isStreaming = false
        const msg = this.messages.find(m => m.tempId === aiTempId)
        if (msg && !msg.content) {
          msg.content = '连接失败，请重试'
        }
      }

      xhr.send(JSON.stringify({
        conversationId: this.activeConversationId,
        role: 'user',
        content: userText
      }))
    },
    scrollToBottom() {
      const container = this.$refs.messagesContainer
      if (container) {
        container.scrollTop = container.scrollHeight
      }
    }
  }
}
</script>

<style scoped>
.ai-robot-page {
  display: flex;
  height: calc(100vh - 84px);
  background: #f1f5f9;
}
.ai-sidebar {
  width: 300px;
  background: #fff;
  border-right: 1px solid #e2e8f0;
  display: flex;
  flex-direction: column;
  transition: width 0.3s ease;
  flex-shrink: 0;
}
.ai-sidebar.collapsed {
  width: 64px;
}
.ai-sidebar-title {
  display: flex;
  align-items: center;
  gap: 8px;
  margin-bottom: 12px;
}
.ai-sidebar.collapsed .ai-sidebar-title {
  justify-content: center;
  margin-bottom: 8px;
}
.ai-sidebar-logo {
  font-size: 24px;
}
.ai-sidebar-header {
  padding: 20px;
  border-bottom: 1px solid #e2e8f0;
}
.ai-sidebar.collapsed .ai-sidebar-header {
  padding: 16px 10px;
}
.ai-sidebar-header h3 {
  margin: 0;
  font-size: 18px;
  color: #1e293b;
}
.ai-new-btn-icon {
  width: 100%;
  padding: 10px;
  justify-content: center;
}
.ai-sidebar-footer {
  padding: 8px;
  border-top: 1px solid #e2e8f0;
  background: #f8fafc;
}
.ai-collapse-btn {
  width: 100%;
  padding: 8px;
  border: none;
  background: transparent;
  border-radius: 6px;
  cursor: pointer;
  color: #64748b;
  display: flex;
  align-items: center;
  justify-content: center;
  transition: all 0.2s;
}
.ai-collapse-btn:hover {
  background: #e2e8f0;
  color: #1e293b;
}
.ai-new-btn {
  width: 100%;
  padding: 10px;
  border: none;
  border-radius: 8px;
  background: linear-gradient(135deg, #1e3a8a 0%, #2563eb 100%);
  color: #fff;
  font-size: 14px;
  cursor: pointer;
  display: flex;
  align-items: center;
  justify-content: center;
  gap: 6px;
  transition: opacity 0.2s;
}
.ai-new-btn:hover { opacity: 0.9; }
.ai-search-box {
  padding: 12px 16px;
  display: flex;
  align-items: center;
  gap: 8px;
  border-bottom: 1px solid #f1f5f9;
}
.ai-search-box input {
  flex: 1;
  border: none;
  outline: none;
  font-size: 13px;
  background: transparent;
}
.ai-conversation-list {
  flex: 1;
  overflow-y: auto;
  padding: 8px;
}
.ai-sidebar.collapsed .ai-conversation-list {
  padding: 6px 4px;
}
.ai-conv-item {
  display: flex;
  align-items: center;
  gap: 10px;
  padding: 12px;
  border-radius: 8px;
  cursor: pointer;
  transition: background 0.2s;
  margin-bottom: 4px;
}
.ai-sidebar.collapsed .ai-conv-item {
  padding: 10px 6px;
  justify-content: center;
  gap: 0;
}
.ai-conv-item:hover { background: #f8fafc; }
.ai-conv-item.active { background: #eff6ff; }
.ai-conv-icon { font-size: 20px; flex-shrink: 0; }
.ai-conv-icon-wrap {
  display: flex;
  align-items: center;
  gap: 4px;
  flex-shrink: 0;
  width: 40px;
}
.ai-sidebar.collapsed .ai-conv-icon-wrap {
  width: auto;
  flex-direction: column;
  gap: 2px;
}
.ai-pin-left-icon {
  flex-shrink: 0;
}
.ai-pin-placeholder {
  width: 14px;
  flex-shrink: 0;
}
.ai-conv-info { flex: 1; min-width: 0; }
.ai-conv-title {
  font-size: 13px;
  font-weight: 500;
  color: #1e293b;
  white-space: nowrap;
  overflow: hidden;
  text-overflow: ellipsis;
}
.ai-conv-preview {
  font-size: 12px;
  color: #94a3b8;
  white-space: nowrap;
  overflow: hidden;
  text-overflow: ellipsis;
  margin-top: 2px;
}
.ai-conv-actions {
  display: flex;
  gap: 2px;
  opacity: 0;
  transition: opacity 0.2s;
}
.ai-conv-item:hover .ai-conv-actions { opacity: 1; }
.ai-pin-btn, .ai-del-btn {
  height: 24px;
  padding: 0 6px;
  border: none;
  background: transparent;
  border-radius: 4px;
  cursor: pointer;
  color: #94a3b8;
  display: flex;
  align-items: center;
  justify-content: center;
  gap: 4px;
  white-space: nowrap;
}
.ai-pin-btn:hover { color: #f59e0b; background: #fef3c7; }
.ai-pin-btn.pinned { color: #f59e0b; width: auto; }
.ai-pin-text {
  font-size: 12px;
  color: #f59e0b;
}
.ai-del-btn:hover { color: #ef4444; background: #fee2e2; }
.ai-empty-conv {
  text-align: center;
  color: #94a3b8;
  font-size: 13px;
  padding: 40px 20px;
}
.ai-main {
  flex: 1;
  display: flex;
  flex-direction: column;
  background: #fff;
}
.ai-main-header {
  padding: 16px 24px;
  border-bottom: 1px solid #e2e8f0;
  background: #f8fafc;
}
.ai-main-tabs {
  display: flex;
  flex-direction: column;
  gap: 8px;
}
.ai-tab-row { display: flex; gap: 8px; }
.ai-tab-divider { height: 1px; background: #e2e8f0; margin: 2px 0; }
.ai-tab {
  display: flex;
  align-items: center;
  gap: 6px;
  padding: 8px 16px;
  border-radius: 8px;
  cursor: pointer;
  transition: all 0.2s;
  font-size: 13px;
  color: #64748b;
  background: #f1f5f9;
}
.ai-tab-large {
  padding: 10px 20px;
  font-size: 14px;
  font-weight: 500;
  background: #dbeafe;
  color: #1e40af;
}
.ai-tab-large.active {
  background: linear-gradient(135deg, #1e3a8a 0%, #2563eb 100%);
  color: #fff;
  box-shadow: 0 2px 8px rgba(30, 58, 138, 0.3);
}
.ai-tab-small {
  padding: 6px 12px;
  font-size: 12px;
}
.ai-tab-small.active { background: #bfdbfe; color: #1d4ed8; }
.ai-messages {
  flex: 1;
  overflow-y: auto;
  padding: 24px;
  background: #fafafa;
}
.ai-empty-state {
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: center;
  height: 100%;
  color: #94a3b8;
}
.ai-empty-icon { font-size: 64px; margin-bottom: 16px; }
.ai-empty-title { font-size: 20px; font-weight: 500; color: #475569; margin-bottom: 8px; }
.ai-empty-text { font-size: 14px; }
.ai-suggestions {
  display: flex;
  flex-direction: column;
  gap: 10px;
  margin-top: 24px;
  width: 100%;
  max-width: 480px;
}
.ai-suggestion-item {
  display: flex;
  align-items: center;
  gap: 10px;
  padding: 12px 16px;
  background: #fff;
  border: 1px solid #e2e8f0;
  border-radius: 10px;
  cursor: pointer;
  transition: all 0.2s;
  text-align: left;
}
.ai-suggestion-item:hover {
  background: #eff6ff;
  border-color: #bfdbfe;
}
.ai-suggestion-icon { font-size: 18px; }
.ai-suggestion-text { font-size: 13px; color: #475569; }
.ai-msg {
  display: flex;
  gap: 12px;
  margin-bottom: 20px;
}
.ai-msg.user { flex-direction: row-reverse; }
.ai-msg-avatar {
  width: 36px;
  height: 36px;
  border-radius: 50%;
  display: flex;
  align-items: center;
  justify-content: center;
  font-size: 13px;
  font-weight: 500;
  flex-shrink: 0;
}
.ai-msg.user .ai-msg-avatar { background: #2563eb; color: #fff; }
.ai-msg.assistant .ai-msg-avatar { background: #1e3a8a; color: #fff; }
.ai-msg-content { max-width: 70%; }
.ai-msg-bubble {
  padding: 12px 16px;
  border-radius: 12px;
  font-size: 14px;
  line-height: 1.7;
  word-break: break-word;
  white-space: pre-wrap;
}
.ai-msg.user .ai-msg-bubble {
  background: #2563eb;
  color: #fff;
  border-top-right-radius: 4px;
}
.ai-msg-assistant {
  background: #fff;
  color: #1e293b;
  border: 1px solid #e2e8f0;
  border-top-left-radius: 4px;
}
.ai-input-area {
  padding: 16px 24px 20px;
  border-top: 1px solid #e2e8f0;
  background: #fff;
}
.ai-input-toolbar {
  display: flex;
  margin-bottom: 8px;
}
.ai-upload-btn {
  display: flex;
  align-items: center;
  gap: 6px;
  padding: 6px 12px;
  border: 1px solid #e2e8f0;
  background: #fff;
  border-radius: 6px;
  cursor: pointer;
  font-size: 12px;
  color: #64748b;
  transition: all 0.2s;
}
.ai-upload-btn:hover {
  background: #f8fafc;
  border-color: #cbd5e1;
  color: #475569;
}
.ai-input-area textarea {
  width: 100%;
  padding: 12px 16px;
  border: 1px solid #e2e8f0;
  border-radius: 8px;
  font-size: 14px;
  font-family: inherit;
  resize: none;
  outline: none;
  transition: border-color 0.2s;
}
.ai-input-area textarea:focus { border-color: #2563eb; }
.ai-input-actions {
  display: flex;
  justify-content: space-between;
  align-items: center;
  margin-top: 8px;
}
.ai-input-hint { font-size: 12px; color: #94a3b8; }
.ai-send-btn {
  padding: 8px 20px;
  border: none;
  border-radius: 8px;
  background: linear-gradient(135deg, #1e3a8a 0%, #2563eb 100%);
  color: #fff;
  font-size: 14px;
  cursor: pointer;
  display: flex;
  align-items: center;
  gap: 6px;
  transition: opacity 0.2s;
}
.ai-send-btn:disabled { opacity: 0.5; cursor: not-allowed; }
</style>
