package com.ruoyi.system.service.impl;

import java.util.Date;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.ruoyi.system.domain.AiConversation;
import com.ruoyi.system.mapper.AiConversationMapper;
import com.ruoyi.system.service.IAiConversationService;

@Service
public class AiConversationServiceImpl implements IAiConversationService
{
    @Autowired
    private AiConversationMapper conversationMapper;

    @Override
    public AiConversation selectConversationById(Long conversationId)
    {
        return conversationMapper.selectConversationById(conversationId);
    }

    @Override
    public List<AiConversation> selectConversationList(AiConversation conversation)
    {
        return conversationMapper.selectConversationList(conversation);
    }

    @Override
    public List<AiConversation> selectConversationListByUserId(Long userId)
    {
        return conversationMapper.selectConversationListByUserId(userId);
    }

    @Override
    public int countPinnedByUserId(Long userId)
    {
        return conversationMapper.countPinnedByUserId(userId);
    }

    @Override
    public Long insertConversation(AiConversation conversation)
    {
        conversation.setCreateTime(new Date());
        conversation.setUpdateTime(new Date());
        conversation.setStatus("0");
        conversation.setIsPinned("0");
        conversationMapper.insertConversation(conversation);
        return conversation.getConversationId();
    }

    @Override
    public int updateConversation(AiConversation conversation)
    {
        conversation.setUpdateTime(new Date());
        return conversationMapper.updateConversation(conversation);
    }

    @Override
    public int updateLastMessage(Long conversationId, String lastMessage)
    {
        AiConversation conversation = new AiConversation();
        conversation.setConversationId(conversationId);
        conversation.setLastMessage(lastMessage);
        conversation.setLastMessageTime(new Date());
        conversation.setUpdateTime(new Date());
        return conversationMapper.updateLastMessage(conversation);
    }

    @Override
    public int togglePinned(Long conversationId, Long userId)
    {
        AiConversation conversation = conversationMapper.selectConversationById(conversationId);
        if (conversation == null)
        {
            return 0;
        }
        String currentPinned = conversation.getIsPinned();
        if ("1".equals(currentPinned))
        {
            return conversationMapper.updatePinned(conversationId, "0");
        }
        else
        {
            int pinnedCount = conversationMapper.countPinnedByUserId(userId);
            if (pinnedCount >= 15)
            {
                return -1;
            }
            return conversationMapper.updatePinned(conversationId, "1");
        }
    }

    @Override
    public int deleteConversationById(Long conversationId)
    {
        return conversationMapper.deleteConversationById(conversationId);
    }

    @Override
    public int deleteConversationByIds(Long[] conversationIds)
    {
        return conversationMapper.deleteConversationByIds(conversationIds);
    }
}
