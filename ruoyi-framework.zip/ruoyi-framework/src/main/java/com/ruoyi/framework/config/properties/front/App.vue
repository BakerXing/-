<template>
  <div id="app">
    <router-view />
    <theme-picker />
    <ai-chat-widget />
  </div>
</template>

<script>
import ThemePicker from "@/components/ThemePicker"
import AiChatWidget from "@/components/AiChatWidget"

export default {
  name: "App",
  components: { ThemePicker, AiChatWidget }
}
</script>
<style scoped>
#app .theme-picker {
  display: none;
}
</style>
