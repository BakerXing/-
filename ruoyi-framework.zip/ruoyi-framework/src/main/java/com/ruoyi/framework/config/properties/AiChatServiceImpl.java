package com.ruoyi.framework.web.service.impl;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.servlet.mvc.method.annotation.SseEmitter;
import com.alibaba.fastjson2.JSON;
import com.ruoyi.common.utils.StringUtils;
import com.ruoyi.framework.config.properties.AiRobotProperties;
import com.ruoyi.framework.web.service.IAiChatService;
import com.ruoyi.system.domain.AiConversation;
import com.ruoyi.system.domain.AiMessage;
import com.ruoyi.system.service.IAiConversationService;
import com.ruoyi.system.service.IAiMessageService;

@Service
public class AiChatServiceImpl implements IAiChatService
{
    private static final Logger log = LoggerFactory.getLogger(AiChatServiceImpl.class);

    @Autowired
    private AiRobotProperties aiRobotProperties;

    @Autowired
    private IAiConversationService conversationService;

    @Autowired
    private IAiMessageService messageService;

    @Override
    public SseEmitter chatStream(AiMessage userMessage, List<AiMessage> historyMessages, Long aiMessageId)
    {
        SseEmitter emitter = new SseEmitter(0L);
        StringBuilder fullContent = new StringBuilder();

        emitter.onCompletion(() -> {
            if (aiMessageId != null && fullContent.length() > 0)
            {
                try
                {
                    AiMessage updateMsg = new AiMessage();
                    updateMsg.setMessageId(aiMessageId);
                    updateMsg.setContent(fullContent.toString());
                    messageService.updateMessage(updateMsg);

                    conversationService.updateLastMessage(userMessage.getConversationId(),
                        fullContent.length() > 50 ? fullContent.substring(0, 50) : fullContent.toString());
                }
                catch (Exception e)
                {
                    log.error("更新AI消息失败", e);
                }
            }
        });

        new Thread(() -> {
            try
            {
                if (isMockMode())
                {
                    streamMockResponse(userMessage, emitter, fullContent);
                    emitter.send(SseEmitter.event().data("[DONE]"));
                    emitter.complete();
                    return;
                }

                streamRealApiResponse(userMessage, historyMessages, emitter, fullContent);
            }
            catch (Exception e)
            {
                log.error("AI流式响应异常", e);
                emitter.completeWithError(e);
            }
        }).start();

        return emitter;
    }

    @Override
    public String chat(AiMessage userMessage, List<AiMessage> historyMessages)
    {
        if (isMockMode())
        {
            return getMockContent(userMessage);
        }

        try
        {
            return callRealApi(userMessage, historyMessages, false);
        }
        catch (Exception e)
        {
            log.error("AI响应异常", e);
            return "抱歉，AI服务暂时不可用，请稍后再试。";
        }
    }

    private boolean isMockMode()
    {
        String apiKey = aiRobotProperties.getApiKey();
        String apiUrl = aiRobotProperties.getApiUrl();
        return StringUtils.isEmpty(apiKey)
            || "your-api-key-here".equals(apiKey)
            || "your-deepseek-api-key-here".equals(apiKey)
            || StringUtils.isEmpty(apiUrl)
            || "https://api.example.com/v1/chat/completions".equals(apiUrl);
    }

    private void streamRealApiResponse(AiMessage userMessage, List<AiMessage> historyMessages,
        SseEmitter emitter, StringBuilder fullContent) throws Exception
    {
        String requestBody = buildRequestBody(userMessage, historyMessages, true);

        URL url = new URL(aiRobotProperties.getApiUrl());
        HttpURLConnection conn = (HttpURLConnection) url.openConnection();
        conn.setRequestMethod("POST");
        conn.setRequestProperty("Content-Type", "application/json");
        conn.setRequestProperty("Authorization", "Bearer " + aiRobotProperties.getApiKey());
        conn.setRequestProperty("Accept", "text/event-stream");
        conn.setDoOutput(true);
        conn.setDoInput(true);
        conn.setConnectTimeout(aiRobotProperties.getConnectTimeout() * 1000);
        conn.setReadTimeout(aiRobotProperties.getReadTimeout() * 1000);

        try (OutputStream os = conn.getOutputStream())
        {
            byte[] input = requestBody.getBytes(StandardCharsets.UTF_8);
            os.write(input, 0, input.length);
        }

        int responseCode = conn.getResponseCode();
        if (responseCode != HttpURLConnection.HTTP_OK)
        {
            String errorMsg = readErrorResponse(conn);
            log.error("AI API调用失败，状态码：{}，响应：{}", responseCode, errorMsg);
            emitter.send(SseEmitter.event().data("AI服务调用失败：" + errorMsg));
            emitter.send(SseEmitter.event().data("[DONE]"));
            emitter.complete();
            return;
        }

        try (BufferedReader reader = new BufferedReader(
            new InputStreamReader(conn.getInputStream(), StandardCharsets.UTF_8)))
        {
            String line;

            while ((line = reader.readLine()) != null)
            {
                if (line.startsWith("data: "))
                {
                    String data = line.substring(6);
                    if ("[DONE]".equals(data))
                    {
                        break;
                    }

                    String content = parseContentFromSse(data);
                    if (content != null && !content.isEmpty())
                    {
                        fullContent.append(content);
                        emitter.send(SseEmitter.event().data(content));
                    }
                }
            }

            emitter.send(SseEmitter.event().data("[DONE]"));
            emitter.complete();
        }
    }

    private String callRealApi(AiMessage userMessage, List<AiMessage> historyMessages, boolean stream)
        throws Exception
    {
        String requestBody = buildRequestBody(userMessage, historyMessages, stream);

        URL url = new URL(aiRobotProperties.getApiUrl());
        HttpURLConnection conn = (HttpURLConnection) url.openConnection();
        conn.setRequestMethod("POST");
        conn.setRequestProperty("Content-Type", "application/json");
        conn.setRequestProperty("Authorization", "Bearer " + aiRobotProperties.getApiKey());
        conn.setDoOutput(true);
        conn.setDoInput(true);
        conn.setConnectTimeout(aiRobotProperties.getConnectTimeout() * 1000);
        conn.setReadTimeout(aiRobotProperties.getReadTimeout() * 1000);

        try (OutputStream os = conn.getOutputStream())
        {
            byte[] input = requestBody.getBytes(StandardCharsets.UTF_8);
            os.write(input, 0, input.length);
        }

        int responseCode = conn.getResponseCode();
        if (responseCode != HttpURLConnection.HTTP_OK)
        {
            String errorMsg = readErrorResponse(conn);
            throw new RuntimeException("AI API调用失败，状态码：" + responseCode + "，响应：" + errorMsg);
        }

        StringBuilder response = new StringBuilder();
        try (BufferedReader reader = new BufferedReader(
            new InputStreamReader(conn.getInputStream(), StandardCharsets.UTF_8)))
        {
            String line;
            while ((line = reader.readLine()) != null)
            {
                response.append(line);
            }
        }

        return parseContentFromResponse(response.toString());
    }

    private String buildRequestBody(AiMessage userMessage, List<AiMessage> historyMessages, boolean stream)
    {
        Map<String, Object> requestBody = new HashMap<>();
        requestBody.put("model", aiRobotProperties.getModel());
        requestBody.put("stream", stream);
        requestBody.put("max_tokens", aiRobotProperties.getMaxTokens());
        requestBody.put("temperature", aiRobotProperties.getTemperature());

        List<Map<String, String>> messages = new ArrayList<>();

        messages.add(buildSystemMessage(userMessage));

        if (historyMessages != null && !historyMessages.isEmpty())
        {
            for (AiMessage msg : historyMessages)
            {
                if (msg.getContent() == null || msg.getContent().isEmpty())
                {
                    continue;
                }
                Map<String, String> historyMsg = new HashMap<>();
                historyMsg.put("role", msg.getRole());
                historyMsg.put("content", msg.getContent());
                messages.add(historyMsg);
            }
        }

        Map<String, String> userMsg = new HashMap<>();
        userMsg.put("role", "user");
        userMsg.put("content", userMessage.getContent());
        messages.add(userMsg);

        requestBody.put("messages", messages);

        return JSON.toJSONString(requestBody);
    }

    private Map<String, String> buildSystemMessage(AiMessage userMessage)
    {
        Map<String, String> systemMsg = new HashMap<>();
        systemMsg.put("role", "system");

        String conversationType = "1";
        if (userMessage.getConversationId() != null)
        {
            conversationType = resolveConversationType(userMessage.getConversationId());
        }

        String systemPrompt = switch (conversationType)
        {
            case "2" -> "你是一个专业的翻译助手。请将用户输入的内容翻译成英文和日文。先给出英文翻译，再给出日文翻译。保持原文的语气和风格。";
            case "3" -> "你是一个会议纪要助手。请根据用户提供的会议内容或主题，生成一份结构化的会议纪要。包含：会议主题、参会人员、会议时间、讨论内容、决议事项、待办事项。";
            case "4" -> "你是一个专业的写作助手。请根据用户的需求，帮助撰写、润色或优化文章内容。提供高质量、结构清晰的文字。";
            default -> "你是一个友好、专业的AI助手。请用简洁、准确的语言回答用户的问题。如果不确定答案，请诚实告知。";
        };

        systemMsg.put("content", systemPrompt);
        return systemMsg;
    }

    private String resolveConversationType(Long conversationId)
    {
        try
        {
            if (conversationService != null)
            {
                AiConversation conv = conversationService.selectConversationById(conversationId);
                if (conv != null && conv.getConversationType() != null)
                {
                    return conv.getConversationType();
                }
            }
        }
        catch (Exception e)
        {
            log.warn("获取会话类型失败，使用默认类型", e);
        }
        return "1";
    }

    private String parseContentFromSse(String data)
    {
        try
        {
            Map<String, Object> json = JSON.parseObject(data);
            List<Map<String, Object>> choices = (List<Map<String, Object>>) json.get("choices");
            if (choices != null && !choices.isEmpty())
            {
                Map<String, Object> choice = choices.get(0);
                Map<String, Object> delta = (Map<String, Object>) choice.get("delta");
                if (delta != null && delta.get("content") != null)
                {
                    return (String) delta.get("content");
                }
            }
        }
        catch (Exception e)
        {
            log.debug("解析SSE数据失败: {}", data);
        }
        return null;
    }

    private String parseContentFromResponse(String response)
    {
        try
        {
            Map<String, Object> json = JSON.parseObject(response);
            List<Map<String, Object>> choices = (List<Map<String, Object>>) json.get("choices");
            if (choices != null && !choices.isEmpty())
            {
                Map<String, Object> choice = choices.get(0);
                Map<String, Object> message = (Map<String, Object>) choice.get("message");
                if (message != null && message.get("content") != null)
                {
                    return (String) message.get("content");
                }
            }
        }
        catch (Exception e)
        {
            log.error("解析响应失败: {}", response, e);
        }
        return "";
    }

    private String readErrorResponse(HttpURLConnection conn)
    {
        try (BufferedReader reader = new BufferedReader(
            new InputStreamReader(conn.getErrorStream(), StandardCharsets.UTF_8)))
        {
            StringBuilder response = new StringBuilder();
            String line;
            while ((line = reader.readLine()) != null)
            {
                response.append(line);
            }
            return response.toString();
        }
        catch (Exception e)
        {
            return "无法读取错误响应";
        }
    }

    private void streamMockResponse(AiMessage userMessage, SseEmitter emitter, StringBuilder fullContent)
        throws Exception
    {
        String mockContent = getMockContent(userMessage);
        for (int i = 0; i < mockContent.length(); i++)
        {
            String token = String.valueOf(mockContent.charAt(i));
            fullContent.append(token);
            emitter.send(SseEmitter.event().data(token));
            Thread.sleep(30);
        }
    }

    private String getMockContent(AiMessage userMessage)
    {
        String response = "";
        String userContent = userMessage.getContent();
        String conversationType = resolveConversationType(userMessage.getConversationId());

        switch (conversationType)
        {
            case "1":
                response = String.format(
                    "你好！我是智聊助手 🤖\n\n" +
                    "关于你提到的「%s」，我来详细聊聊：\n\n" +
                    "📌 这是一个非常好的问题！让我从几个方面来分析：\n\n" +
                    "1️⃣ **背景介绍**：这个话题涉及到多个方面的知识，需要综合考虑。\n\n" +
                    "2️⃣ **核心要点**：关键在于理解本质问题，而非表面现象。\n\n" +
                    "3️⃣ **实践建议**：建议从简单场景开始，逐步深入。\n\n" +
                    "💡 **总结**：希望以上分析对你有帮助！如果还有其他问题，随时问我～",
                    userContent);
                break;
            case "2":
                response = String.format(
                    "🌐 翻译结果如下：\n\n" +
                    "【原文】\n%s\n\n" +
                    "【英文翻译】\nThis is the English translation of your text. The translation maintains the original meaning and tone while ensuring natural fluency in the target language.\n\n" +
                    "【日文翻译】\nこれはあなたのテキストの日本語訳です。元の意味とニュアンスを保ちつつ、自然な流れになるように翻訳しています。\n\n" +
                    "📝 备注：以上翻译为演示数据，对接真实API后将提供准确翻译。",
                    userContent);
                break;
            case "3":
                response = String.format(
                    "📝 会议纪要生成中...\n\n" +
                    "═══════════════════════════════\n" +
                    "              会 议 纪 要\n" +
                    "═══════════════════════════════\n\n" +
                    "📅 会议主题：%s\n\n" +
                    "👥 参会人员：产品经理、开发负责人、测试负责人\n\n" +
                    "🕐 会议时间：2026-07-28 14:00-15:30\n\n" +
                    "【讨论内容】\n" +
                    "1. 项目进度回顾 — 整体进度符合预期\n" +
                    "2. 技术方案确认 — 采用微服务架构\n" +
                    "3. 风险点梳理 — 识别3个关键风险\n\n" +
                    "【决议事项】\n" +
                    "✅ 事项一：下周三前完成技术评审\n" +
                    "✅ 事项二：测试团队提前介入\n" +
                    "✅ 事项三：每日站会同步进度\n\n" +
                    "【待办事项】\n" +
                    "⏳ 张三 — 完成接口文档\n" +
                    "⏳ 李四 — 准备测试用例\n" +
                    "⏳ 王五 — 跟进依赖方\n\n" +
                    "═══════════════════════════════",
                    userContent);
                break;
            case "4":
                response = String.format(
                    "✍️ 辅助写作 — 为您生成内容\n\n" +
                    "基于您的需求「%s」，我为您撰写了以下内容：\n\n" +
                    "━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n\n" +
                    "在当今快速发展的时代，这个话题变得越来越重要。\n\n" +
                    "首先，我们需要认识到问题的核心所在。只有深入理解本质，才能找到真正有效的解决方案。无数实践证明，那些能够取得突破的人，往往是能够从多角度思考问题的人。\n\n" +
                    "其次，行动是关键。理论固然重要，但没有实践的支撑，一切都只是空谈。建议您从以下几个方面入手：\n\n" +
                    "• 制定清晰的目标和计划\n" +
                    "• 分解任务，逐步推进\n" +
                    "• 定期复盘，持续优化\n\n" +
                    "最后，请记住：每一个伟大的成就，都始于一个勇敢的开始。只要坚持下去，就一定能够看到成果。\n\n" +
                    "━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n\n" +
                    "💡 如需调整风格（正式/轻松/专业/文艺）或继续扩写，请告诉我！",
                    userContent);
                break;
            default:
                response = "你好！我是AI助手，有什么可以帮您？";
                break;
        }
        return response;
    }
}
