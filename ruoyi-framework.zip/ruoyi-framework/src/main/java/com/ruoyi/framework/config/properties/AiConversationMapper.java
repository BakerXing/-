package com.ruoyi.system.mapper;

import java.util.List;
import org.apache.ibatis.annotations.Param;
import com.ruoyi.system.domain.AiConversation;

public interface AiConversationMapper
{
    public AiConversation selectConversationById(Long conversationId);

    public List<AiConversation> selectConversationList(AiConversation conversation);

    public List<AiConversation> selectConversationListByUserId(Long userId);

    public int countPinnedByUserId(Long userId);

    public int insertConversation(AiConversation conversation);

    public int updateConversation(AiConversation conversation);

    public int updateLastMessage(AiConversation conversation);

    public int updatePinned(@Param("conversationId") Long conversationId, @Param("isPinned") String isPinned, @Param("pinnedTime") java.util.Date pinnedTime);

    public int deleteConversationById(Long conversationId);

    public int deleteConversationByIds(Long[] conversationIds);
}
