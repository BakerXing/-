package com.ruoyi.framework.web.service;

import java.util.List;
import org.springframework.web.servlet.mvc.method.annotation.SseEmitter;
import com.ruoyi.system.domain.AiMessage;

public interface IAiChatService
{
    SseEmitter chatStream(AiMessage userMessage, List<AiMessage> historyMessages, Long aiMessageId);

    String chat(AiMessage userMessage, List<AiMessage> historyMessages);
}
