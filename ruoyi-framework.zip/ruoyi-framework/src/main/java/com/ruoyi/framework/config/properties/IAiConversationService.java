package com.ruoyi.system.service;

import java.util.List;
import com.ruoyi.system.domain.AiConversation;

public interface IAiConversationService
{
    public AiConversation selectConversationById(Long conversationId);

    public List<AiConversation> selectConversationList(AiConversation conversation);

    public List<AiConversation> selectConversationListByUserId(Long userId);

    public int countPinnedByUserId(Long userId);

    public Long insertConversation(AiConversation conversation);

    public int updateConversation(AiConversation conversation);

    public int updateLastMessage(Long conversationId, String lastMessage);

    public int togglePinned(Long conversationId, Long userId);

    public int deleteConversationById(Long conversationId);

    public int deleteConversationByIds(Long[] conversationIds);
}
