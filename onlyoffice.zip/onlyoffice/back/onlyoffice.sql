-- ----------------------------
-- OnlyOffice 文档编辑菜单
-- 父级菜单：系统工具(menu_id=3)
-- 可重复执行，不会因主键冲突报错
-- ----------------------------

-- 1. 先清理旧数据（避免重复执行时主键冲突）
delete from sys_role_menu where menu_id in (118, 1061, 1062);
delete from sys_menu where menu_id in (118, 1061, 1062);

-- 2. 插入菜单（系统工具下的第4个子菜单）
insert into sys_menu values('118', '文档编辑', '3', '4', 'onlyoffice', 'tool/onlyoffice/index', '', '', 1, 0, 'C', '0', '0', 'tool:onlyoffice:list', 'documentation', 'admin', sysdate(), '', null, 'OnlyOffice文档编辑菜单');

-- 3. 插入按钮权限
insert into sys_menu values('1061', '文档上传', '118', '1', '#', '', '', '', 1, 0, 'F', '0', '0', 'tool:onlyoffice:upload', '#', 'admin', sysdate(), '', null, '');
insert into sys_menu values('1062', '文档删除', '118', '2', '#', '', '', '', 1, 0, 'F', '0', '0', 'tool:onlyoffice:remove', '#', 'admin', sysdate(), '', null, '');

-- 4. 给所有角色授权（确保每个角色都能看到此菜单）
insert into sys_role_menu (role_id, menu_id)
select role_id, 118 from sys_role;

insert into sys_role_menu (role_id, menu_id)
select role_id, 1061 from sys_role;

insert into sys_role_menu (role_id, menu_id)
select role_id, 1062 from sys_role;
