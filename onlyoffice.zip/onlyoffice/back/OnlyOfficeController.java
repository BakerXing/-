package com.ruoyi.web.controller.tool;

import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.Base64;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import javax.crypto.Mac;
import javax.crypto.spec.SecretKeySpec;
import org.apache.commons.io.FilenameUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;
import com.alibaba.fastjson2.JSON;
import com.ruoyi.common.annotation.Anonymous;
import com.ruoyi.common.config.RuoYiConfig;
import com.ruoyi.common.constant.Constants;
import com.ruoyi.common.core.controller.BaseController;
import com.ruoyi.common.core.domain.AjaxResult;
import com.ruoyi.common.utils.StringUtils;
import com.ruoyi.common.utils.file.FileUploadUtils;
import com.ruoyi.framework.config.ServerConfig;
import com.ruoyi.framework.config.properties.OnlyOfficeProperties;

/**
 * OnlyOffice 文档编辑
 *
 * @author ruoyi
 */
@RestController
@RequestMapping("/tool/onlyoffice")
public class OnlyOfficeController extends BaseController
{
    private static final Logger log = LoggerFactory.getLogger(OnlyOfficeController.class);

    /** OnlyOffice 允许的文档类型 */
    private static final String[] ALLOWED_EXTENSION = {
        "doc", "docx", "txt", "rtf", "odt", "pdf",
        "xls", "xlsx", "csv", "ods",
        "ppt", "pptx", "odp"
    };

    /** OnlyOffice 文件存放子目录 */
    private static final String ONLYOFFICE_DIR = "onlyoffice";

    @Autowired
    private OnlyOfficeProperties onlyOfficeProperties;

    @Autowired
    private ServerConfig serverConfig;

    /**
     * 获取文档列表
     */
    @PreAuthorize("@ss.hasPermi('tool:onlyoffice:list')")
    @GetMapping("/list")
    public AjaxResult list()
    {
        List<Map<String, Object>> result = new ArrayList<>();
        File baseDir = new File(RuoYiConfig.getProfile() + File.separator + ONLYOFFICE_DIR);
        if (baseDir.exists())
        {
            collectFiles(baseDir, baseDir, result);
        }
        return AjaxResult.success(result);
    }

    /**
     * 递归收集文件信息
     */
    private void collectFiles(File baseDir, File current, List<Map<String, Object>> result)
    {
        File[] files = current.listFiles();
        if (files == null)
        {
            return;
        }
        for (File file : files)
        {
            if (file.isDirectory())
            {
                collectFiles(baseDir, file, result);
            }
            else
            {
                String relative = baseDir.toPath().relativize(file.toPath()).toString().replace('\\', '/');
                String fileName = Constants.RESOURCE_PREFIX + "/" + ONLYOFFICE_DIR + "/" + relative;
                Map<String, Object> item = new HashMap<>();
                item.put("fileName", fileName);
                item.put("name", file.getName());
                item.put("size", file.length());
                item.put("sizeText", formatSize(file.length()));
                item.put("lastModified", file.lastModified());
                item.put("extension", FilenameUtils.getExtension(file.getName()).toLowerCase());
                result.add(item);
            }
        }
    }

    /**
     * 上传文档
     */
    @PreAuthorize("@ss.hasPermi('tool:onlyoffice:upload')")
    @PostMapping("/upload")
    public AjaxResult upload(@RequestParam("file") MultipartFile file)
    {
        try
        {
            String filePath = RuoYiConfig.getProfile() + File.separator + ONLYOFFICE_DIR;
            String fileName = FileUploadUtils.upload(filePath, file, ALLOWED_EXTENSION);
            String url = getHost() + fileName;
            AjaxResult ajax = AjaxResult.success();
            ajax.put("url", url);
            ajax.put("fileName", fileName);
            ajax.put("name", file.getOriginalFilename());
            ajax.put("extension", FilenameUtils.getExtension(file.getOriginalFilename()).toLowerCase());
            return ajax;
        }
        catch (Exception e)
        {
            log.error("OnlyOffice 文件上传失败", e);
            return AjaxResult.error(e.getMessage());
        }
    }

    /**
     * 删除文档
     */
    @PreAuthorize("@ss.hasPermi('tool:onlyoffice:remove')")
    @DeleteMapping
    public AjaxResult remove(@RequestParam("fileName") String fileName)
    {
        try
        {
            if (!fileName.startsWith(Constants.RESOURCE_PREFIX + "/" + ONLYOFFICE_DIR + "/"))
            {
                return AjaxResult.error("非法的文件路径");
            }
            String localPath = RuoYiConfig.getProfile()
                + fileName.substring(Constants.RESOURCE_PREFIX.length());
            File file = new File(localPath);
            if (file.exists() && file.delete())
            {
                return AjaxResult.success();
            }
            return AjaxResult.error("文件删除失败");
        }
        catch (Exception e)
        {
            return AjaxResult.error(e.getMessage());
        }
    }

    /**
     * 获取编辑器配置
     *
     * @param fileName 文件相对路径，如 /profile/onlyoffice/2026/08/13/xxx.docx
     * @param mode 编辑模式：edit / view
     */
    @PreAuthorize("@ss.hasPermi('tool:onlyoffice:list')")
    @GetMapping("/config")
    public AjaxResult config(@RequestParam("fileName") String fileName,
            @RequestParam(value = "mode", defaultValue = "edit") String mode)
    {
        try
        {
            if (!fileName.startsWith(Constants.RESOURCE_PREFIX + "/" + ONLYOFFICE_DIR + "/"))
            {
                return AjaxResult.error("非法的文件路径");
            }
            String localPath = RuoYiConfig.getProfile()
                + fileName.substring(Constants.RESOURCE_PREFIX.length());
            File file = new File(localPath);
            if (!file.exists())
            {
                return AjaxResult.error("文件不存在");
            }

            String extension = FilenameUtils.getExtension(fileName).toLowerCase();
            String documentType = resolveDocumentType(extension);
            String host = getHost();
            String fileUrl = host + fileName;
            String callbackUrl = host + "/tool/onlyoffice/callback";
            String key = fileName + "_" + file.lastModified();

            Map<String, Object> permissions = new HashMap<>();
            permissions.put("edit", "view".equals(mode) ? false : true);
            permissions.put("download", true);
            permissions.put("print", true);
            permissions.put("review", "view".equals(mode) ? false : true);

            Map<String, Object> document = new HashMap<>();
            document.put("fileType", extension);
            document.put("key", key);
            document.put("title", file.getName());
            document.put("url", fileUrl);
            document.put("permissions", permissions);

            Map<String, Object> editorConfig = new HashMap<>();
            editorConfig.put("mode", "view".equals(mode) ? "view" : "edit");
            editorConfig.put("lang", "zh-CN");
            editorConfig.put("callbackUrl", callbackUrl);
            Map<String, Object> user = new HashMap<>();
            user.put("id", getUserId() == null ? "anonymous" : String.valueOf(getUserId()));
            user.put("name", getUsername() == null ? "匿名用户" : getUsername());
            editorConfig.put("user", user);
            Map<String, Object> customization = new HashMap<>();
            customization.put("forcesave", true);
            customization.put("compactHeader", true);
            editorConfig.put("customization", customization);

            Map<String, Object> config = new HashMap<>();
            config.put("documentType", documentType);
            config.put("document", document);
            config.put("editorConfig", editorConfig);
            config.put("documentServerUrl", onlyOfficeProperties.getDocumentServerUrl());
            config.put("token", createJwtToken(config));

            return AjaxResult.success(config);
        }
        catch (Exception e)
        {
            log.error("生成OnlyOffice配置失败", e);
            return AjaxResult.error(e.getMessage());
        }
    }

    /**
     * OnlyOffice 文档保存回调（匿名访问，由文档服务器调用）
     *
     * status: 1=编辑中 2=准备保存 3=保存出错 4=关闭无变更 6=强制保存 7=强制保存出错
     */
    @Anonymous
    @PostMapping("/callback")
    public Object callback(@RequestBody Map<String, Object> body)
    {
        try
        {
            Integer status = body.get("status") == null ? null : ((Number) body.get("status")).intValue();
            String key = body.get("key") == null ? null : body.get("key").toString();
            String downloadUrl = body.get("url") == null ? null : body.get("url").toString();

            // status=2(准备保存) 或 6(强制保存) 时，下载文件并覆盖原文件
            if (status != null && (status == 2 || status == 6) && StringUtils.isNotEmpty(downloadUrl))
            {
                String fileName = restoreFileNameFromKey(key);
                if (fileName != null)
                {
                    saveFileFromUrl(downloadUrl, fileName);
                }
            }
            Map<String, Object> result = new HashMap<>();
            result.put("error", 0);
            return result;
        }
        catch (Exception e)
        {
            log.error("OnlyOffice 回调处理失败", e);
            Map<String, Object> result = new HashMap<>();
            result.put("error", 1);
            return result;
        }
    }

    /**
     * 从 key 还原文件相对路径
     * key 格式: /profile/onlyoffice/.../xxx.docx_最后修改时间
     */
    private String restoreFileNameFromKey(String key)
    {
        if (StringUtils.isEmpty(key))
        {
            return null;
        }
        int lastUnderline = key.lastIndexOf('_');
        if (lastUnderline > 0)
        {
            return key.substring(0, lastUnderline);
        }
        return key;
    }

    /**
     * 从 OnlyOffice 下载文件并覆盖本地原文件
     */
    private void saveFileFromUrl(String downloadUrl, String fileName) throws IOException
    {
        String localPath = RuoYiConfig.getProfile()
            + fileName.substring(Constants.RESOURCE_PREFIX.length());
        Path target = Paths.get(localPath);
        Files.createDirectories(target.getParent());
        try (InputStream in = new URL(downloadUrl).openStream();
                OutputStream out = Files.newOutputStream(target))
        {
            in.transferTo(out);
        }
        log.info("OnlyOffice 文档已保存: {}", localPath);
    }

    /**
     * 根据扩展名解析文档类型
     */
    private String resolveDocumentType(String extension)
    {
        switch (extension)
        {
            case "doc":
            case "docx":
            case "txt":
            case "rtf":
            case "odt":
            case "pdf":
                return "word";
            case "xls":
            case "xlsx":
            case "csv":
            case "ods":
                return "cell";
            case "ppt":
            case "pptx":
            case "odp":
                return "slide";
            default:
                return "word";
        }
    }

    /**
     * 获取文件访问主机
     */
    private String getHost()
    {
        if (StringUtils.isNotEmpty(onlyOfficeProperties.getFileHost()))
        {
            return onlyOfficeProperties.getFileHost();
        }
        return serverConfig.getUrl();
    }

    /**
     * 生成 JWT Token（若配置了密钥）
     */
    private String createJwtToken(Map<String, Object> payload)
    {
        String secret = onlyOfficeProperties.getJwtSecret();
        if (StringUtils.isEmpty(secret))
        {
            return null;
        }
        try
        {
            String header = "{\"alg\":\"HS256\",\"typ\":\"JWT\"}";
            String headerBase64 = base64UrlEncode(header.getBytes(StandardCharsets.UTF_8));
            String payloadBase64 = base64UrlEncode(JSON.toJSONString(payload).getBytes(StandardCharsets.UTF_8));
            String signingInput = headerBase64 + "." + payloadBase64;
            String signature = base64UrlEncode(hmacSha256(signingInput, secret));
            return signingInput + "." + signature;
        }
        catch (Exception e)
        {
            log.error("生成OnlyOffice JWT失败", e);
            return null;
        }
    }

    private byte[] hmacSha256(String data, String secret) throws Exception
    {
        Mac mac = Mac.getInstance("HmacSHA256");
        mac.init(new SecretKeySpec(secret.getBytes(StandardCharsets.UTF_8), "HmacSHA256"));
        return mac.doFinal(data.getBytes(StandardCharsets.UTF_8));
    }

    private String base64UrlEncode(byte[] bytes)
    {
        return Base64.getUrlEncoder().withoutPadding().encodeToString(bytes);
    }

    private String formatSize(long size)
    {
        if (size < 1024)
        {
            return size + " B";
        }
        if (size < 1024 * 1024)
        {
            return String.format("%.1f KB", size / 1024.0);
        }
        return String.format("%.1f MB", size / (1024.0 * 1024));
    }
}
