package com.ruoyi.web.service.tool.impl;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.ruoyi.common.utils.SecurityUtils;
import com.ruoyi.common.utils.StringUtils;
import com.ruoyi.web.service.tool.OnlyOfficeService;
import jakarta.servlet.http.HttpServletRequest;
import org.apache.commons.io.FilenameUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import javax.crypto.Mac;
import javax.crypto.spec.SecretKeySpec;
import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.text.SimpleDateFormat;
import java.util.*;

/**
 * OnlyOffice 文档编辑服务实现
 */
@Service
public class OnlyOfficeServiceImpl implements OnlyOfficeService {

    private static final Logger log = LoggerFactory.getLogger(OnlyOfficeServiceImpl.class);

    /** 允许的文档类型 */
    private static final String[] ALLOWED_EXTENSION = {
            "doc", "docx", "txt", "rtf", "odt", "pdf",
            "xls", "xlsx", "csv", "ods",
            "ppt", "pptx", "odp"
    };

    /** URL 资源前缀 */
    private static final String RESOURCE_PREFIX = "/profile/onlyoffice";

    private static final ObjectMapper OBJECT_MAPPER = new ObjectMapper();

    @Value("${onlyoffice.document-server-url}")
    private String documentServerUrl;

    @Value("${onlyoffice.jwt-secret:}")
    private String jwtSecret;

    @Value("${onlyoffice.file-host:}")
    private String fileHost;

    @Value("${onlyoffice.storage-path:}")
    private String storagePath;

    /**
     * 获取本地存储根目录
     */
    private File getStorageDir() {
        String path = storagePath;
        if (StringUtils.isEmpty(path)) {
            path = System.getProperty("user.home") + File.separator + "onlyoffice-files";
        }
        File dir = new File(path);
        if (!dir.exists()) {
            dir.mkdirs();
        }
        return dir;
    }

    @Override
    public List<Map<String, Object>> list() {
        List<Map<String, Object>> result = new ArrayList<>();
        File baseDir = getStorageDir();
        if (baseDir.exists()) {
            collectFiles(baseDir, baseDir, result);
        }
        return result;
    }

    private void collectFiles(File baseDir, File current, List<Map<String, Object>> result) {
        File[] files = current.listFiles();
        if (files == null) {
            return;
        }
        for (File file : files) {
            if (file.isDirectory()) {
                collectFiles(baseDir, file, result);
            } else {
                String name = file.getName();
                if (name.endsWith(".meta")) {
                    continue;
                }
                String relative = baseDir.toPath().relativize(file.toPath()).toString().replace('\\', '/');
                String fileName = RESOURCE_PREFIX + "/" + relative;
                Map<String, Object> item = new HashMap<>();
                item.put("fileName", fileName);
                item.put("name", readOriginalName(file));
                item.put("size", file.length());
                item.put("sizeText", formatSize(file.length()));
                item.put("lastModified", file.lastModified());
                item.put("extension", FilenameUtils.getExtension(name).toLowerCase());
                result.add(item);
            }
        }
    }

    private String readOriginalName(File file) {
        File metaFile = new File(file.getAbsolutePath() + ".meta");
        if (metaFile.exists()) {
            try {
                Map<?, ?> meta = OBJECT_MAPPER.readValue(metaFile, Map.class);
                Object originalName = meta.get("originalName");
                if (originalName != null && StringUtils.isNotEmpty(originalName.toString())) {
                    return originalName.toString();
                }
            } catch (Exception e) {
                log.warn("读取文件元数据失败: {}", metaFile.getAbsolutePath(), e);
            }
        }
        return file.getName();
    }

    @Override
    public Map<String, Object> upload(MultipartFile file) {
        try {
            String originalName = file.getOriginalFilename();
            if (originalName == null) {
                throw new RuntimeException("文件名不能为空");
            }
            String extension = FilenameUtils.getExtension(originalName).toLowerCase();
            if (!isAllowedExtension(extension)) {
                throw new RuntimeException("不支持的文件类型");
            }

            String dateDir = new SimpleDateFormat("yyyy/MM/dd").format(new Date());
            File targetDir = new File(getStorageDir(), dateDir);
            if (!targetDir.exists() && !targetDir.mkdirs()) {
                throw new RuntimeException("创建上传目录失败: " + targetDir.getAbsolutePath());
            }
            String fileName = UUID.randomUUID().toString().replace("-", "") + "." + extension;
            File targetFile = new File(targetDir, fileName);
            file.transferTo(targetFile);

            // 保存原始文件名元数据
            File metaFile = new File(targetDir, fileName + ".meta");
            try {
                Map<String, Object> meta = new HashMap<>();
                meta.put("originalName", originalName);
                OBJECT_MAPPER.writeValue(metaFile, meta);
            } catch (Exception e) {
                log.warn("保存文件元数据失败: {}", metaFile.getAbsolutePath(), e);
            }

            String relativePath = dateDir + "/" + fileName;
            String savedFileName = RESOURCE_PREFIX + "/" + relativePath;
            String url = getHost(null) + savedFileName;

            Map<String, Object> data = new HashMap<>();
            data.put("url", url);
            data.put("fileName", savedFileName);
            data.put("name", originalName);
            data.put("extension", extension);
            return data;
        } catch (RuntimeException e) {
            throw e;
        } catch (Exception e) {
            log.error("OnlyOffice 文件上传失败", e);
            throw new RuntimeException(e.getMessage(), e);
        }
    }

    @Override
    public void remove(String fileName) {
        if (!fileName.startsWith(RESOURCE_PREFIX + "/")) {
            throw new RuntimeException("非法的文件路径");
        }
        String relativePath = fileName.substring(RESOURCE_PREFIX.length() + 1);
        File file = new File(getStorageDir(), relativePath);
        File metaFile = new File(file.getAbsolutePath() + ".meta");
        if (file.exists() && file.delete()) {
            if (metaFile.exists()) {
                metaFile.delete();
            }
            return;
        }
        throw new RuntimeException("文件删除失败");
    }

    @Override
    public Map<String, Object> config(String fileName, String mode, HttpServletRequest request) {
        try {
            if (!fileName.startsWith(RESOURCE_PREFIX + "/")) {
                throw new RuntimeException("非法的文件路径");
            }
            String relativePath = fileName.substring(RESOURCE_PREFIX.length() + 1);
            File file = new File(getStorageDir(), relativePath);
            if (!file.exists()) {
                throw new RuntimeException("文件不存在");
            }

            String extension = FilenameUtils.getExtension(fileName).toLowerCase();
            String documentType = resolveDocumentType(extension);
            String host = getHost(request);
            String fileUrl = host + fileName;
            String callbackUrl = host + "/tool/onlyoffice/callback";
            String key = Base64.getUrlEncoder().withoutPadding().encodeToString(fileName.getBytes(StandardCharsets.UTF_8)) + "_" + file.lastModified();

            Map<String, Object> permissions = new HashMap<>();
            boolean viewMode = isViewMode(mode);
            permissions.put("edit", !viewMode);
            permissions.put("download", true);
            permissions.put("print", true);
            permissions.put("review", !viewMode);

            Map<String, Object> document = new HashMap<>();
            document.put("fileType", extension);
            document.put("key", key);
            document.put("title", readOriginalName(file));
            document.put("url", fileUrl);
            document.put("permissions", permissions);

            Map<String, Object> editorConfig = new HashMap<>();
            editorConfig.put("mode", viewMode ? "view" : "edit");
            editorConfig.put("lang", "zh-CN");
            editorConfig.put("callbackUrl", callbackUrl);
            Map<String, Object> user = new HashMap<>();
            String username = SecurityUtils.getUsername();
            user.put("id", username == null ? "anonymous" : username);
            user.put("name", username == null ? "匿名用户" : username);
            editorConfig.put("user", user);
            Map<String, Object> customization = new HashMap<>();
            customization.put("forcesave", true);
            customization.put("compactHeader", true);
            editorConfig.put("customization", customization);

            Map<String, Object> config = new HashMap<>();
            config.put("documentType", documentType);
            config.put("document", document);
            config.put("editorConfig", editorConfig);
            config.put("documentServerUrl", documentServerUrl);
            config.put("token", createJwtToken(config));

            return config;
        } catch (RuntimeException e) {
            throw e;
        } catch (Exception e) {
            log.error("生成 OnlyOffice 配置失败", e);
            throw new RuntimeException(e.getMessage(), e);
        }
    }

    @Override
    public Map<String, Object> callback(Map<String, Object> body) {
        try {
            Integer status = body.get("status") == null ? null : ((Number) body.get("status")).intValue();
            String key = body.get("key") == null ? null : body.get("key").toString();
            String downloadUrl = body.get("url") == null ? null : body.get("url").toString();

            if (status != null && (status == 2 || status == 6) && StringUtils.isNotEmpty(downloadUrl)) {
                String fileName = restoreFileNameFromKey(key);
                if (fileName != null) {
                    saveFileFromUrl(downloadUrl, fileName);
                }
            }
            Map<String, Object> result = new HashMap<>();
            result.put("error", 0);
            return result;
        } catch (Exception e) {
            log.error("OnlyOffice 回调处理失败", e);
            Map<String, Object> result = new HashMap<>();
            result.put("error", 1);
            return result;
        }
    }

    private String restoreFileNameFromKey(String key) {
        if (StringUtils.isEmpty(key)) {
            return null;
        }
        int lastUnderline = key.lastIndexOf('_');
        if (lastUnderline <= 0) {
            return null;
        }
        String encoded = key.substring(0, lastUnderline);
        try {
            return new String(Base64.getUrlDecoder().decode(encoded), StandardCharsets.UTF_8);
        } catch (Exception e) {
            log.warn("解码文档 key 失败: {}", key, e);
            return null;
        }
    }

    private void saveFileFromUrl(String downloadUrl, String fileName) throws IOException {
        String relativePath = fileName.substring(RESOURCE_PREFIX.length() + 1);
        Path target = Paths.get(getStorageDir().getAbsolutePath(), relativePath);
        Files.createDirectories(target.getParent());
        try (InputStream in = new URL(downloadUrl).openStream();
             OutputStream out = Files.newOutputStream(target)) {
            in.transferTo(out);
        }
        log.info("OnlyOffice 文档已保存: {}", target);
    }

    private boolean isViewMode(String mode) {
        return "view".equals(mode) || "preview".equals(mode);
    }

    private String resolveDocumentType(String extension) {
        switch (extension) {
            case "doc":
            case "docx":
            case "txt":
            case "rtf":
            case "odt":
            case "pdf":
                return "word";
            case "xls":
            case "xlsx":
            case "csv":
            case "ods":
                return "cell";
            case "ppt":
            case "pptx":
            case "odp":
                return "slide";
            default:
                return "word";
        }
    }

    private String getHost(HttpServletRequest request) {
        if (StringUtils.isNotEmpty(fileHost)) {
            return fileHost.replaceAll("/$", "");
        }
        if (request != null) {
            return request.getScheme() + "://" + request.getServerName() + ":" + request.getServerPort();
        }
        return "http://localhost:8080";
    }

    private boolean isAllowedExtension(String extension) {
        for (String ext : ALLOWED_EXTENSION) {
            if (ext.equalsIgnoreCase(extension)) {
                return true;
            }
        }
        return false;
    }

    private String createJwtToken(Map<String, Object> payload) {
        String secret = jwtSecret;
        if (StringUtils.isEmpty(secret)) {
            return null;
        }
        try {
            String header = "{\"alg\":\"HS256\",\"typ\":\"JWT\"}";
            String headerBase64 = base64UrlEncode(header.getBytes(StandardCharsets.UTF_8));
            String payloadBase64 = base64UrlEncode(toJson(payload).getBytes(StandardCharsets.UTF_8));
            String signingInput = headerBase64 + "." + payloadBase64;
            String signature = base64UrlEncode(hmacSha256(signingInput, secret));
            return signingInput + "." + signature;
        } catch (Exception e) {
            log.error("生成 OnlyOffice JWT 失败", e);
            return null;
        }
    }

    private String toJson(Map<String, Object> map) {
        StringBuilder sb = new StringBuilder("{");
        boolean first = true;
        for (Map.Entry<String, Object> entry : map.entrySet()) {
            if (!first) sb.append(",");
            first = false;
            sb.append("\"").append(escapeJson(entry.getKey())).append("\":");
            Object value = entry.getValue();
            if (value instanceof Boolean) {
                sb.append(value);
            } else if (value instanceof Number) {
                sb.append(value);
            } else if (value instanceof Map) {
                sb.append(toJson((Map<String, Object>) value));
            } else {
                sb.append("\"").append(escapeJson(value == null ? "" : value.toString())).append("\"");
            }
        }
        sb.append("}");
        return sb.toString();
    }

    private String escapeJson(String s) {
        return s.replace("\\", "\\\\")
                .replace("\"", "\\\"")
                .replace("\b", "\\b")
                .replace("\f", "\\f")
                .replace("\n", "\\n")
                .replace("\r", "\\r")
                .replace("\t", "\\t");
    }

    private byte[] hmacSha256(String data, String secret) throws Exception {
        Mac mac = Mac.getInstance("HmacSHA256");
        mac.init(new SecretKeySpec(secret.getBytes(StandardCharsets.UTF_8), "HmacSHA256"));
        return mac.doFinal(data.getBytes(StandardCharsets.UTF_8));
    }

    private String base64UrlEncode(byte[] bytes) {
        return Base64.getUrlEncoder().withoutPadding().encodeToString(bytes);
    }

    private String formatSize(long size) {
        if (size < 1024) {
            return size + " B";
        }
        if (size < 1024 * 1024) {
            return String.format("%.1f KB", size / 1024.0);
        }
        return String.format("%.1f MB", size / (1024.0 * 1024));
    }
}
