import request from '@/utils/request'

// 获取文档列表
export function listDocument() {
  return request({
    url: '/tool/onlyoffice/list',
    method: 'get'
  })
}

// 上传文档
export function uploadDocument(data) {
  return request({
    url: '/tool/onlyoffice/upload',
    method: 'post',
    headers: { 'Content-Type': 'multipart/form-data' },
    data
  })
}

// 获取编辑器配置
export function getEditorConfig(fileName, mode) {
  return request({
    url: '/tool/onlyoffice/config',
    method: 'get',
    params: { fileName, mode }
  })
}

// 删除文档
export function deleteDocument(fileName) {
  return request({
    url: '/tool/onlyoffice',
    method: 'delete',
    params: { fileName }
  })
}
