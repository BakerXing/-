<template>
  <div class="app-container">
    <el-row :gutter="10" class="mb8">
      <el-col :span="1.5">
        <el-upload
          ref="uploadRef"
          :show-file-list="false"
          :auto-upload="true"
          :http-request="handleUpload"
          accept=".doc,.docx,.txt,.rtf,.odt,.pdf,.xls,.xlsx,.csv,.ods,.ppt,.pptx,.odp"
        >
          <el-button type="primary" icon="el-icon-upload2" v-hasPermi="['tool:onlyoffice:upload']">上传文件</el-button>
        </el-upload>
      </el-col>
      <el-col :span="1.5">
        <el-button icon="el-icon-refresh" @click="getList">刷新</el-button>
      </el-col>
    </el-row>

    <el-table v-loading="loading" :data="documentList" border>
      <el-table-column label="文件名" prop="name" min-width="240" show-overflow-tooltip>
        <template slot-scope="scope">
          <span class="doc-icon">{{ getIcon(scope.row.extension) }}</span>
          <span>{{ scope.row.name }}</span>
        </template>
      </el-table-column>
      <el-table-column label="类型" prop="extension" width="90" align="center">
        <template slot-scope="scope">
          <el-tag :type="getTypeTag(scope.row.extension)" size="small">{{ scope.row.extension || '-' }}</el-tag>
        </template>
      </el-table-column>
      <el-table-column label="大小" prop="sizeText" width="110" align="center" />
      <el-table-column label="修改时间" width="180" align="center">
        <template slot-scope="scope">
          <span>{{ parseTime(scope.row.lastModified) }}</span>
        </template>
      </el-table-column>
      <el-table-column label="操作" width="240" align="center">
        <template slot-scope="scope">
          <el-button type="text" icon="el-icon-edit" @click="openEditor(scope.row, 'edit')">编辑</el-button>
          <el-button type="text" icon="el-icon-view" @click="openEditor(scope.row, 'preview')">预览</el-button>
          <el-button type="text" icon="el-icon-delete" style="color: #f56c6c" @click="handleDelete(scope.row)">删除</el-button>
        </template>
      </el-table-column>
    </el-table>

    <!-- 编辑器弹窗 -->
    <el-dialog
      :title="editorTitle"
      :visible.sync="editorVisible"
      :fullscreen="true"
      :before-close="handleCloseEditor"
      append-to-body
      custom-class="onlyoffice-dialog"
    >
      <div v-loading="editorLoading" element-loading-text="正在加载编辑器...">
        <div id="onlyoffice-editor" class="onlyoffice-container"></div>
        <div v-if="editorError" class="editor-error">
          <i class="el-icon-warning"></i>
          <p>{{ editorError }}</p>
          <p class="editor-error-tip" v-if="isConfigError">
            请确认 OnlyOffice 文档服务器已启动，且 <code>application.yml</code> 中 <code>onlyoffice.document-server-url</code> 配置正确。
          </p>
        </div>
      </div>
    </el-dialog>
  </div>
</template>

<script>
import { listDocument, uploadDocument, getEditorConfig, deleteDocument } from '@/api/tool/onlyoffice'

let scriptLoadPromise = null

export default {
  name: 'OnlyOffice',
  data() {
    return {
      loading: false,
      documentList: [],
      editorVisible: false,
      editorLoading: false,
      editorError: '',
      isConfigError: false,
      editorTitle: '文档编辑',
      editor: null,
      currentDocumentServerUrl: ''
    }
  },
  created() {
    this.getList()
  },
  methods: {
    getList() {
      this.loading = true
      listDocument().then(res => {
        this.documentList = res.data || []
      }).finally(() => {
        this.loading = false
      })
    },
    handleUpload(option) {
      const formData = new FormData()
      formData.append('file', option.file)
      uploadDocument(formData).then(res => {
        this.$modal.msgSuccess('上传成功')
        this.getList()
      }).catch(() => {})
    },
    openEditor(row, mode) {
      this.editorVisible = true
      this.editorLoading = true
      this.editorError = ''
      this.isConfigError = false
      this.editorTitle = mode === 'edit' ? `编辑 - ${row.name}` : `预览 - ${row.name}`
      // 等待弹窗 DOM 渲染完成
      this.$nextTick(() => {
        this.initEditor(row, mode)
      })
    },
    initEditor(row, mode) {
      getEditorConfig(row.fileName, mode).then(async res => {
        const cfg = res.data
        const documentServerUrl = cfg.documentServerUrl
        if (!documentServerUrl) {
          this.editorLoading = false
          this.editorError = '未配置 OnlyOffice 文档服务器地址'
          this.isConfigError = true
          return
        }
        try {
          await this.loadOnlyOfficeScript(documentServerUrl)
        } catch (e) {
          this.editorLoading = false
          this.editorError = '无法连接 OnlyOffice 文档服务器，请检查服务是否启动及地址配置。'
          this.isConfigError = true
          return
        }
        this.currentDocumentServerUrl = documentServerUrl
        const editorConfig = {
          documentType: cfg.documentType,
          document: cfg.document,
          editorConfig: cfg.editorConfig,
          width: '100%',
          height: '100%',
          events: {
            onError: (e) => {
              console.error('OnlyOffice 错误', e)
            }
          }
        }
        if (cfg.token) {
          editorConfig.token = cfg.token
        }
        // 清空容器
        document.getElementById('onlyoffice-editor').innerHTML = ''
        this.editor = new window.DocsAPI.DocEditor('onlyoffice-editor', editorConfig)
        this.editorLoading = false
      }).catch(() => {
        this.editorLoading = false
        this.editorError = '获取编辑器配置失败'
      })
    },
    loadOnlyOfficeScript(documentServerUrl) {
      const url = documentServerUrl.replace(/\/$/, '') + '/web-apps/apps/api/documents/api.js'
      if (window.DocsAPI) {
        return Promise.resolve()
      }
      if (scriptLoadPromise) {
        return scriptLoadPromise
      }
      scriptLoadPromise = new Promise((resolve, reject) => {
        const script = document.createElement('script')
        script.src = url
        script.async = true
        script.onload = () => {
          if (window.DocsAPI) {
            resolve()
          } else {
            scriptLoadPromise = null
            reject(new Error('DocsAPI 未加载'))
          }
        }
        script.onerror = () => {
          scriptLoadPromise = null
          reject(new Error('脚本加载失败'))
        }
        document.head.appendChild(script)
      })
      return scriptLoadPromise
    },
    handleCloseEditor(done) {
      this.destroyEditor()
      done && done()
    },
    destroyEditor() {
      if (this.editor) {
        try {
          this.editor.destroyEditor()
        } catch (e) {
          // ignore
        }
        this.editor = null
      }
      this.editorError = ''
      this.isConfigError = false
    },
    handleDelete(row) {
      this.$modal.confirm(`是否确认删除文件 "${row.name}"？`).then(() => {
        return deleteDocument(row.fileName)
      }).then(() => {
        this.$modal.msgSuccess('删除成功')
        this.getList()
      }).catch(() => {})
    },
    getIcon(ext) {
      const map = {
        doc: '📄', docx: '📄', txt: '📄', rtf: '📄', odt: '📄', pdf: '📕',
        xls: '📊', xlsx: '📊', csv: '📊', ods: '📊',
        ppt: '📽️', pptx: '📽️', odp: '📽️'
      }
      return map[ext] || '📄'
    },
    getTypeTag(ext) {
      if (['doc', 'docx', 'txt', 'rtf', 'odt', 'pdf'].includes(ext)) return ''
      if (['xls', 'xlsx', 'csv', 'ods'].includes(ext)) return 'success'
      if (['ppt', 'pptx', 'odp'].includes(ext)) return 'warning'
      return 'info'
    }
  }
}
</script>

<style scoped>
.doc-icon {
  margin-right: 6px;
}
.onlyoffice-container {
  width: 100%;
  height: calc(100vh - 160px);
  min-height: 500px;
}
.editor-error {
  text-align: center;
  padding: 60px 20px;
  color: #f56c6c;
}
.editor-error i {
  font-size: 48px;
}
.editor-error p {
  margin-top: 16px;
  font-size: 15px;
}
.editor-error .editor-error-tip {
  color: #909399;
  font-size: 13px;
}
.editor-error code {
  background: #f5f5f5;
  padding: 2px 6px;
  border-radius: 3px;
  color: #e6a23c;
}
</style>
