package com.ruoyi.web.service.tool;

import jakarta.servlet.http.HttpServletRequest;
import org.springframework.web.multipart.MultipartFile;

import java.util.List;
import java.util.Map;

/**
 * OnlyOffice 文档编辑服务
 */
public interface OnlyOfficeService {

    /**
     * 获取文档列表
     */
    List<Map<String, Object>> list();

    /**
     * 上传文档
     */
    Map<String, Object> upload(MultipartFile file);

    /**
     * 删除文档
     */
    void remove(String fileName);

    /**
     * 获取编辑器配置
     */
    Map<String, Object> config(String fileName, String mode, HttpServletRequest request);

    /**
     * OnlyOffice 文档保存回调
     */
    Map<String, Object> callback(Map<String, Object> body);
}
