package com.ruoyi.web.controller.tool;

import com.ruoyi.common.core.controller.BaseController;
import com.ruoyi.common.core.domain.CommonResult;
import com.ruoyi.web.service.tool.OnlyOfficeService;
import jakarta.servlet.http.HttpServletRequest;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import java.util.List;
import java.util.Map;

/**
 * OnlyOffice 文档编辑
 */
@RestController
@RequestMapping("/tool/onlyoffice")
public class OnlyOfficeController extends BaseController {

    private static final Logger log = LoggerFactory.getLogger(OnlyOfficeController.class);

    private final OnlyOfficeService onlyOfficeService;

    @Autowired
    public OnlyOfficeController(OnlyOfficeService onlyOfficeService) {
        this.onlyOfficeService = onlyOfficeService;
    }

    /**
     * 获取文档列表
     */
    @PreAuthorize("@ss.hasPermi('tool:onlyoffice:list')")
    @GetMapping("/list")
    public CommonResult<List<Map<String, Object>>> list() {
        return CommonResult.success(onlyOfficeService.list());
    }

    /**
     * 上传文档
     */
    @PreAuthorize("@ss.hasPermi('tool:onlyoffice:upload')")
    @PostMapping("/upload")
    public CommonResult<Map<String, Object>> upload(@RequestParam("file") MultipartFile file) {
        try {
            return CommonResult.success(onlyOfficeService.upload(file));
        } catch (Exception e) {
            log.error("OnlyOffice 文件上传失败", e);
            return CommonResult.error(e.getMessage());
        }
    }

    /**
     * 删除文档
     */
    @PreAuthorize("@ss.hasPermi('tool:onlyoffice:remove')")
    @DeleteMapping
    public CommonResult<Void> remove(@RequestParam("fileName") String fileName) {
        try {
            onlyOfficeService.remove(fileName);
            return CommonResult.success();
        } catch (Exception e) {
            log.error("OnlyOffice 文件删除失败", e);
            return CommonResult.error(e.getMessage());
        }
    }

    /**
     * 获取编辑器配置
     */
    @PreAuthorize("@ss.hasPermi('tool:onlyoffice:config')")
    @GetMapping("/config")
    public CommonResult<Map<String, Object>> config(@RequestParam("fileName") String fileName,
                                                    @RequestParam(value = "mode", defaultValue = "edit") String mode,
                                                    HttpServletRequest request) {
        try {
            return CommonResult.success(onlyOfficeService.config(fileName, mode, request));
        } catch (Exception e) {
            log.error("生成 OnlyOffice 配置失败", e);
            return CommonResult.error(e.getMessage());
        }
    }

    /**
     * OnlyOffice 文档保存回调（匿名访问，由文档服务器调用）
     */
    @PostMapping("/callback")
    public Object callback(@RequestBody Map<String, Object> body) {
        return onlyOfficeService.callback(body);
    }
}
