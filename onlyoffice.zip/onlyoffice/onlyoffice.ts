import request from '@/utils/request'

// 获取文档列表
export const listDocument = () => {
  return request.get('/tool/onlyoffice/list')
}

// 上传文档
export const uploadDocument = (data: FormData) => {
  return request.post('/tool/onlyoffice/upload', data, {
    headers: { 'Content-Type': 'multipart/form-data' }
  })
}

// 获取编辑器配置
export const getEditorConfig = (fileName: string, mode: string) => {
  return request.get('/tool/onlyoffice/config', { params: { fileName, mode } })
}

// 删除文档
export const deleteDocument = (fileName: string) => {
  return request.delete('/tool/onlyoffice', { params: { fileName } })
}
